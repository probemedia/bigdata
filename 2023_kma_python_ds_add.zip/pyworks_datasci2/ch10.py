# -*- coding: utf-8 -*-
"""
Created on Mon Oct  8 19:50:53 2018

@author: KEO
"""

import numpy as np
import scipy as sp
import pandas as pd
from matplotlib import pyplot as plt
import sklearn.datasets
import sklearn
import sklearn.datasets as datasets
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, adjusted_rand_score
from sklearn import metrics

from matplotlib import font_manager, rc
import platform

# matplotlib 한글꺠짐 처리
plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font', family=font_name)
else:
    print("Unknown System OS")
# %%
'''10.1'''
d = 2  # 2차원
data = np.random.uniform(size=d*1000).reshape((1000, d))
distances = sp.spatial.distance.cdist(data, data)
pd.Series(distances.reshape(1000000)).hist(bins=50)
plt.title("Dist. between points in R%i" % d)
plt.show()
# %%

d = 500  # 500차원
data = np.random.uniform(size=d*1000).reshape((1000, d))
distances = sp.spatial.distance.cdist(data, data)
pd.Series(distances.reshape(1000000)).hist(bins=50)
plt.title("Dist. between points in R%i" % d)
plt.show()

# %%
'''10.2'''
import sklearn
import sklearn.datasets as datasets
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, adjusted_rand_score
from sklearn import metrics

# Get data and format it
faces_data = datasets.fetch_olivetti_faces()
person_ids, image_array = faces_data['target'], faces_data.images
# unroll each 64x64 image -> (64*64) element vector
X = image_array.reshape((len(person_ids), 64*64))

# Cluster raw data and compare
print("** Results from raw data")
model = KMeans(n_clusters=40)
model.fit(X)
print("cluster goodness: ", silhouette_score(X, model.labels_))
print("match to faces: ", metrics.adjusted_rand_score(
    model.labels_, person_ids))  # 0.15338

# Use PCA to
print("** Now using PCA")
pca = PCA(25)  # pass in number of components to fit
pca.fit(X)
X_reduced = pca.transform(X)
model_reduced = KMeans(n_clusters=40)
model_reduced.fit(X_reduced)
labels_reduced = model_reduced.labels_
print("cluster goodness: ",
      silhouette_score(X_reduced, model_reduced.labels_))
print("match to faces: ", metrics.adjusted_rand_score(
    model_reduced.labels_, person_ids))

# Display a random face, to get a feel for the data
sample_face = image_array[0, :, :]
plt.imshow(sample_face)
plt.title("Sample face")
plt.show()
# Show eigenface 0
eigenface0 = pca.components_[0, :].reshape((64, 64))
plt.imshow(eigenface0)
plt.title("Eigenface 0")
plt.show()
eigenface1 = pca.components_[1, :].reshape((64, 64))
plt.imshow(eigenface1)
plt.title("Eigenface 1")
plt.show()
# Skree plot
pd.Series(
    pca.explained_variance_ratio_).plot()
plt.title("Skree Plot of Eigenface Importance")
plt.show()
