import numpy as np
import cv2
import matplotlib.pyplot as plt

img = cv2.imread("my_letter2.jpg")
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
img_blur = cv2.GaussianBlur(img_gray, (5, 5), 0)
plt.figure(figsize=(15,10))
plt.imshow(img)

ret, img_th = cv2.threshold(img_blur, 100, 230, cv2.THRESH_BINARY_INV)

contours, hierarchy= cv2.findContours(img_th.copy(), 
   cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

rects = [cv2.boundingRect(each) for each in contours]
rects
'''
tmp = [w*h for (x,y,w,h) in rects]
tmp.sort(reverse=True)
tmp
'''
rects = [(x,y,w,h) for (x,y,w,h) in rects if ((w*h>1000))]
rects

for rect in rects:
    # Draw the rectangles
    cv2.rectangle(img, (rect[0], rect[1]), 
                  (rect[0] + rect[2], rect[1] + rect[3]), (0, 255, 0), 5) 

plt.figure(figsize=(15,12))
plt.imshow(img);

img_result = []
img_for_class = img.copy()

margin_pixel = 60

for rect in rects:
    #[y:y+h, x:x+w]
    img_result.append(
        img_for_class[rect[1]-margin_pixel : rect[1]+rect[3]+margin_pixel, 
                      rect[0]-margin_pixel : rect[0]+rect[2]+margin_pixel])
    
    # Draw the rectangles
    cv2.rectangle(img, (rect[0], rect[1]), 
                  (rect[0] + rect[2], rect[1] + rect[3]), (0, 255, 0), 5) 

plt.figure(figsize=(15,12))
plt.imshow(img)
plt.figure(figsize=(8,6))
plt.imshow(img_result[0])

plt.figure(figsize=(4,4))
plt.imshow(cv2.resize(img_result[0], (32,32)));

count = 0
nrows = 2
ncols = 5

plt.figure(figsize=(12,8))

for n in img_result:
    count += 1
    plt.subplot(nrows, ncols, count)
    plt.imshow(cv2.resize(n,(28,28)), cmap='Greys', interpolation='nearest')

plt.tight_layout()
plt.show()
# %%
from scipy.stats import mode
from keras.models import load_model
model = load_model("keras_minist_model.h5")
model.summary()

test_num = cv2.resize(img_result[2], (784,784))[:,:,1]
test_num = (test_num < 70) * test_num
test_num = test_num.astype('float32') / 255.

plt.imshow(test_num, cmap='Greys', interpolation='nearest');

test_num = test_num.reshape((784, 784))
result = model.predict_classes(test_num)
print('The Answer is ', mode(result)[0].item())



count = 0
nrows = 2
ncols = 5

plt.figure(figsize=(12,8))

for n in img_result:
    count += 1
    plt.subplot(nrows, ncols, count)
    
    test_num = cv2.resize(n, (784,784))[:,:,1]
    test_num = (test_num < 70) * test_num
    test_num = test_num.astype('float32') / 255.
    
    plt.imshow(test_num, cmap='Greys', interpolation='nearest');
    
    test_num = test_num.reshape((784, 784))
    result = model.predict_classes(test_num)
    plt.title(mode(result)[0].item())
    
plt.tight_layout()
plt.show()
