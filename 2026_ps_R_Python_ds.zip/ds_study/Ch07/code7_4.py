import pandas as pd
import numpy as np
from scipy import stats

df = pd.read_csv('d:/data/iris.csv')
sw = df.Sepal_Width

# Z-score 이용
z = np.abs(stats.zscore(sw))
outliers = sw[z > 2]
print(outliers)

# IQR 이용
Q1 = sw.quantile(0.25)
Q3 = sw.quantile(0.75)
IQR = Q3 - Q1

outliers = sw[(sw < Q1 - IQR*1.5) | (sw > Q3 + IQR*1.5)]
print(outliers)

# 특잇값 제거
clean = sw.loc[~sw.isin(outliers)]
len(clean)
