import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv('d:/data/seoul_temp.csv')
df.head()
df['month'] = (df.날짜 - 20230000) // 100  # 월 컬럼 생성
df.head()

# 그래프 테마 설정
sns.set_theme(style="white", rc={"figure.figsize": (7, 4)})

# 월별 평균 기온에 의한 순위 계산
tmp = df.groupby('month').mean()
rank = tmp['평균기온'].rank() - 1
rank = rank.astype(int).to_list()
rank

# 팔레트 색 선택 및 순서 변경
mycolor = sns.color_palette('bwr', 12)
mycolor = pd.Series(mycolor)[rank].to_list()

# 월별 기온 분포를 상자그림으로 작성
plt.rcParams['font.family'] = 'Malgun Gothic'  # 한글 폰트 설정
plt.rcParams['axes.unicode_minus'] = False  # 마이너스 부호 깨짐 방지

sns.boxplot(data=df,  # df 이름
            x='month',  # x축 컬럼
            y='평균기온',  # y축 컬럼
            hue='month',  # 그룹 지정
            legend=None,  # 범례 표시 안 함
            palette=mycolor  # 팔레트 지정
            ).set(title='월별 기온 분포')

plt.ylabel('기온')  # y축 레이블
plt.subplots_adjust(bottom=0.2)  # 하단 여백
plt.show()
