# -*- coding: utf-8 -*-
"""
Created on Sat May  9 13:46:36 2020

@author: KEO
"""

# 1. numpy
# (1) numpy 사용방법
import numpy as np

# (2) ndarray 작성 방법
arry1 = np.array([[1, 3, 5], [2, 5, 9], [4, 8, 7]])

alist = [[1, 3, 5], [2, 5, 9], [4, 8, 7]]
arry2 = np.array(alist)

np.zeros((2, 4))
np.zeros((2, 4, 2))  # (면, 행, 열)

np.ones((3, 3))
np.ones((3, 3, 2))

np.arange(10, 30, 5)
np.arange(10)

np.linspace(0, 10, num=30)
np.linspace(0, 10, num=30, endpoint=True)
np.linspace(0, 10, num=30, endpoint=False)

# (3) 주요메소드와 슬라이스
nda1 = np.arange(12).reshape(3, 4)

nda1
nda1[:, :]
nda1[1, 2]
nda1[:, :2]

# (4) ndarray 타입의 연산
# 1) 리스트 연산
list_a = [1, 2, 3]
list_b = [4, 5, 6]

list_a + list_b

list_a * 2

# 2) ndarray 연산
ndarray_a = np.array(list_a)
ndarray_b = np.array(list_b)

ndarray_a + ndarray_b

ndarray_a * 2
# %%
# 2.scipy
import numpy as np
from scipy.interpolate import interp1d

x = np.linspace(0, 10, num=11)
y = np.cos(x)
f1 = interp1d(x, y, kind='linear')

# %%
# 3.matplotlib
# 그래프 한글처리
import matplotlib as mpl
import matplotlib.pyplot as plt
import platform

plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    mpl.rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = mpl.font_manager.FontProperties(fname=path).get_name()
    mpl.rc('font', family=font_name)
else:
    print("Unknown System OS")

# %%
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d

x = np.linspace(0, 10, num=11)
y = np.cos(x)
in_kinds = ['linear', 'nearest', 'zero', 'slinear', 'quadratic', 'cubic']
line_kinds = ['*', '-.',  ':', ',', 's', '-']

plt.figure(1, figsize=(9, 6))
plt.plot(x, y, 'o')

x2 = np.linspace(0, 10, num=30)

for k1, k2 in zip(in_kinds, line_kinds):
    f2 = interp1d(x, y, kind=k1)
    plt.plot(x2, f2(x2), k2)

plt.legend(['data'] + in_kinds)
plt.title("데이터 보간")
plt.xlabel("x값")
plt.ylabel("y값", rotation=0)
plt.savefig("plots/interp1d.png")
plt.show()
