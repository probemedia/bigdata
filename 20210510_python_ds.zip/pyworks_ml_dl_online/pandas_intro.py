# -*- coding: utf-8 -*-
"""
Created on Tue May 12 09:43:11 2020

@author: KEO
"""

import pandas as pd
# %%
# (1)  데이터프레임타입, 시리즈 타입
data_dic = {'번호': [1, 2, 3, 4, 5],
            '이름': ['김씨', '이씨', '박씨', '정씨', '홍씨'],
            '점수': [90, 100, 95, 90, 100]}

data_df = pd.DataFrame(data_dic)
print(type(data_df))
print(type(data_df['번호']))

# %%
# (3) 데이터 프레임 생성
df_direct = pd.DataFrame({'id': ('admin', 'root', 'dba'),
                          'pass': ('1111', '2222', '3333'),
                          'roll': (1, 2, 3)})
print(df_direct)
# %%
# csv파일 읽기
df_ozone = pd.read_csv("data/ozone_data.csv", encoding='cp949')
print(df_ozone)
# %%
df_bd = pd.read_csv("data/20190309_very_big.csv")
print(df_bd)
# %%
# csv한글파일명의 경우 파일을 읽을 때  engine="python"추가
df = pd.read_csv("data/20200511_1999-2018년_월간_온실가스1.csv",
                 encoding='cp949', engine="python")

print(df)
# %%
# 엑셀파일 읽기
df_ol = pd.read_excel('data/20180217_2017년서울시구별노령화지수.xlsx')
print(df_ol)
# %%
df1 = pd.read_excel('data/20200426_excel_test.xlsx', sheet_name=0)
print(df1)
# %%
df2 = pd.read_excel('data/20200426_excel_test.xlsx',
                    sheet_name='유형별해양사고현황2002-2012')
print(df2)
# %%
# 변수의 내용을 파일로 저장
df2.to_csv("data/유형별해양사고현황2002-2012.csv")

# %%
# 토이데이터(toy data)
from sklearn.datasets import load_iris
iris_d = load_iris()
df_iris = pd.DataFrame(iris_d.data, columns=iris_d.feature_names)
print(df_iris)
# %%
# (4)데이터프레임과 시리즈 타입확인
# type()함수
print(type(df_ol))
print(type(df_ol['자치구']))
# %%
# 타입확인
print(df_ol.dtypes)

print(df_ozone.dtypes)
# %%
# 그래프 한글처리
import matplotlib as mpl
import matplotlib.pyplot as plt
import platform

plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    mpl.rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = mpl.font_manager.FontProperties(fname=path).get_name()
    mpl.rc('font', family=font_name)
else:
    print("Unknown System OS")

# %%
df_ozone[['일시', '평균오존전량(DU)']].plot()
# %%
df_ozone['일시'] = pd.to_datetime(df_ozone['일시'])
# df_ozone['일시'] = df_ozone['일시'].astype('datetime64[ns]')
print(df_ozone.dtypes)
# %%
df_ozone_vis = df_ozone[['일시', '평균오존전량(DU)']]
print(df_ozone_vis)
df_ozone_vis.set_index('일시', inplace=True)
df_ozone_vis.plot()
# %%
# 오존데이터 : 데이터 프레임 타입의 시각화
df_ozone2 = pd.read_csv('data/ozone_data.csv', encoding="cp949")
df_ozone2["일시"] = df_ozone2["일시"].astype("datetime64[ns]")
df_ozone2.plot(x="일시", y="평균오존전량(DU)")

# %%
# 오존데이터 : 리스트타입 시각화
import matplotlib.pyplot as plt
df_ozone = pd.read_csv("data/ozone_data.csv", encoding='cp949')
df_ozone
dates = list(df_ozone.loc[:, '일시'])
dates
oz = list(df_ozone.loc[:, '평균오존전량(DU)'])
oz

plt.figure(figsize=(12, 3))
plt.clf()
plt.plot(dates, oz, 'k-')
plt.xticks(rotation=45)
plt.grid()
plt.show()

# %%
# (5) 데이터의 내용과 구조 파악
df = pd.read_csv("data/20200511_ghg.csv", encoding='cp949')

print(df)
# %%
# 데이터의 내용
print(df.head())
# %%
print(df.tail())
# %%
# 구조파악
print(df.info())
# %%
print(df.shape)
# %%
# 타입변환
df['시간'] = pd.to_datetime(df['시간'])
print(df.info())
# %%
# 요약통계량 파악
print(df.describe())
# %%
# 결측치 확인
print(df.isnull().sum())
# %%
# 컬럼명 얻어내기
print(df.columns)
# %%
# 데이터 얻어내기
print(df.values)
# %%
df1 = pd.read_excel('data/20200426_excel_test.xlsx', sheet_name=0)
print(df1)
print(df1.head())
print(df1.tail())
print(df1.info())
print(df1.describe())

# %%
# (6) 기본적인 연산방법
print(df1.head())
# %%
# 1) 변수단위로 연산
print(df1['남자인구수'] + df1['여자인구수'])
# %%
print(df1['인구수'] / df1['세대수'])
# %%
# 2) NaN값이 포함된 연산의 결과는 항상 NaN
print(df.info())
print(df.head())
print(df.columns)
print(df['CO2_ppm'].isnull().sum())
print(df['CH4_ppm'].isnull().sum())
# %%
df_x = df['CO2_ppm'] + df['CH4_ppm']
print(df_x.head())
# %%
print(df_x.isnull().sum())
# %%
# (7) 주요 통계함수
print(df.describe())
# %%
print(df['CO2_ppm'].sum())
print(df['CH4_ppm'].sum())
# %%
print(df['CO2_ppm'].mean())
print(df['CH4_ppm'].mean(skipna=True))  # nan값을 제외하고 연산
print(df['CH4_ppm'].mean(skipna=False))  # nan값을 포함하고 연산
# %%
print(df['CO2_ppm'].count())
print(df['CH4_ppm'].count())
# %%
print(df['CO2_ppm'].mode())
print(df['CH4_ppm'].mode())
# %%
print(df['CH4_ppm'].min())
print(df['CH4_ppm'].max())
# %%
print(df['CO2_ppm'].median())
print(df['CH4_ppm'].median())
# %%
print(df['CO2_ppm'].quantile(0.25))
print(df['CO2_ppm'].quantile(0.5))
print(df['CO2_ppm'].quantile(0.75))
# %%
print(df['CH4_ppm'].quantile(0.25))
print(df['CH4_ppm'].quantile(0.25))
print(df['CH4_ppm'].quantile(0.5))
print(df['CH4_ppm'].quantile(0.75))
# %%
print(df['CO2_ppm'].var())
print(df['CO2_ppm'].std())
print(df['CH4_ppm'].var())
print(df['CH4_ppm'].std())
# %%
print(df['CO2_ppm'].round(2))
# %%
print(round(df['CO2_ppm'].std(), 2))

# %%
# (8) 함수 적용
print(df['CO2_ppm'] * df['CO2_ppm'])
# %%
print(df['CO2_ppm'].apply(lambda x: x * x))
# %%


def func_test(x):
    if x >= 400:
        y = x * x
    else:
        y = x * 2
    return y


print(df['CO2_ppm'])
print(df['CO2_ppm'].apply(func_test))
