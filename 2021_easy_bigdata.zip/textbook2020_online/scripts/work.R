library(dplyr) 
library(ggplot2)

df_ghgs <- read.csv("data/20180218_1999-2018년_월간_온실가스.csv")

df_ghgs_new <- df_ghgs[, 2:9]
names(df_ghgs_new)
names(df_ghgs_new) <- c("관측일", "CO2_ppm", "CH4_ppm", "N2O_ppm", 
                        "CFC11_ppm", "CFC12_ppm","CFC113_ppm", "SF6_ppm")
names(df_ghgs_new)

head(df_ghgs_new)
tail(df_ghgs_new)
dim(df_ghgs_new)
str(df_ghgs_new)
summary(df_ghgs_new)

df_ghgs_new %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_point()
cor(df_ghgs_new$CO2_ppm, df_ghgs_new$CH4_ppm, use="complete.obs")

df_ghgs_new %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_point() + geom_smooth(method='lm', formula=y~x)
