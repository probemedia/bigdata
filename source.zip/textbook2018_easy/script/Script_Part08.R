#### 08-2 ####

## -------------------------------------------------------------------- ##
library(ggplot2)


# x축 displ, y축 hwy로 지정해 배경 생성
ggplot(data = mpg, aes(x = displ, y = hwy))#그래프의 종류를 결정하지 않아서 배경만 보임 

# 배경에 산점도 추가
ggplot(data = mpg, aes(x = displ, y = hwy)) + geom_point()

# x축 범위 3~6으로 지정
ggplot(data = mpg, aes(x = displ, y = hwy)) + geom_point() + xlim(3, 6)

# x축 범위 3~6, y축 범위 10~30으로 지정
ggplot(data = mpg, aes(x = displ, y = hwy)) + 
  geom_point() + 
  xlim(3, 6) + 
  ylim(10, 30)


#### 08-3 ####

## -------------------------------------------------------------------- ##
library(dplyr)

mpg <- as.data.frame(ggplot2::mpg) 

df_mpg <- mpg %>% 
  group_by(drv) %>%
  summarise(mean_hwy = mean(hwy))

df_mpg

ggplot(data = df_mpg, aes(x = drv, y = mean_hwy)) + geom_col()

ggplot(data = df_mpg, aes(x = reorder(drv, -mean_hwy), y = mean_hwy)) + geom_col()

ggplot(data = mpg, aes(x = drv)) + geom_bar()

ggplot(data = mpg, aes(x = hwy)) + geom_bar()


#### 08-4 ####
head(economics,5)
## -------------------------------------------------------------------- ##
ggplot(data = economics, aes(x = date, y = unemploy)) + geom_line()
str(economics)
ggplot(data = economics, aes(x = date, y = psavert)) + geom_line()
ggplot(data = economics, aes(x = date, y = uempmed)) + geom_line()

#-----------
df_rw <- read.csv("data/20180813_2016년 원전 방사성폐기물 발생현황_연도형식수정.csv")
df_rw
str(df_rw)
df_rw$연도 <- as.Date(df_rw$연도)
str(df_rw)

df_rw_vol <- df_rw %>% filter(구분 == "저장용량")
df_rw_vol
df_rw_st <- df_rw %>% filter(구분 == "저장실적")
df_rw_st
date_breaks <- seq(as.Date("2016-01-01"), as.Date("2016-11-01"), by="1 month")
date_breaks
date_breaks2 <- df_rw_st$연도
date_breaks2
ggplot(data = df_rw_st, aes(x = 연도, y = 고리)) + geom_line() + 
  scale_x_date(breaks=date_breaks2) + theme(axis.text.x = element_text(angle=30, hjust=1))
#-----------


#### 08-5 ####

## -------------------------------------------------------------------- ##
ggplot(data = mpg, aes(x = drv, y = hwy)) + geom_boxplot()


## -------------------------------------------------------------------- ##
## 1.산점도
ggplot(data = mpg, aes(x = displ, y = hwy)) + geom_point()

# 축 설정 추가
ggplot(data = mpg, aes(x = displ, y = hwy)) +
  geom_point() +
  xlim(3, 6) +
  ylim(10, 30)


## 2.평균 막대 그래프

# 1단계.평균표 만들기
df_mpg <- mpg %>%
  group_by(drv) %>%
  summarise(mean_hwy = mean(hwy))

# 2단계.그래프 생성하기, 크기순 정렬하기
ggplot(data = df_mpg, aes(x = reorder(drv, -mean_hwy), y = mean_hwy)) + geom_col()


## 3.빈도 막대 그래프
ggplot(data = mpg, aes(x = drv)) + geom_bar()

## 4.선 그래프
ggplot(data = economics, aes(x = date, y = unemploy)) + geom_line()

## 5.상자 그림
ggplot(data = mpg, aes(x = drv, y = hwy)) + geom_boxplot()

----QnA

datas <- read.csv("data/temp_life.csv")
datas

cor(datas$Temp.,datas$Life)

datas %>% ggplot(aes(Temp.,Life)) + geom_point() + geom_smooth(method = "glm")

model_d <- lm(Life ~ Temp. , data=datas)

summary(model_d )

predict(model_d)
resid(model_d)

new_Temp. <- c(95,105,115)
datas_p <- data.frame(Temp. = new_Temp.)
predict(model_d, newdata = datas_p)

datas_p <- data.frame(Temp. = new_Temp.)
new_Life <- predict(model_d, newdata = datas_p)

p_data <- data.frame(Temp. = new_Temp.,Life = new_Life)
new_datas <- bind_rows(datas,p_data )
new_datas
new_datas %>% ggplot(aes(Temp.,Life)) + geom_point() + geom_smooth(method = "glm")

new_Temp. <- c(86,87,88,89,90,91,92,93,94,95)
datas_p <- data.frame(Temp. = new_Temp.)
predict(model_d, newdata = datas_p)

datas_p <- data.frame(Temp. = new_Temp.)
new_Life <- predict(model_d, newdata = datas_p)

p_data <- data.frame(Temp. = new_Temp.,Life = new_Life)
new_datas <- bind_rows(datas,p_data )
new_datas
new_datas %>% ggplot(aes(Temp.,Life)) + geom_point() + geom_smooth(method = "glm")

datas %>% ggplot(aes(Temp.,Life)) + geom_point() + geom_smooth()
summary(datas$Life)
boxplot(datas$Life)

datas_cut <- datas[c(4,5),]
datas_cut

datas_cut %>% ggplot(aes(Temp.,Life)) + geom_point() + geom_smooth()
model_d_cut <- lm(Life ~ Temp. , data=datas_cut)

summary(model_d )

new_Temp. <- c(90,95,100)
datas_p <- data.frame(Temp. = new_Temp.)
predict(model_d_cut, newdata = datas_p)

new_Life_cut <- predict(model_d_cut, newdata = datas_p)
p_data_cut <- data.frame(Temp. = new_Temp.,Life = new_Life_cut)

new_datas_cut <- bind_rows(datas, p_data_cut)
new_datas_cut
new_datas_cut %>% ggplot(aes(Temp.,Life)) + geom_point() + geom_smooth(method = "glm")
