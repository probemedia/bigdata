#내부망에서 package설치 


##1.install.packages("sqldf") #sqldf
install.packages("packages/sqldf_0.4-11.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/gsubfn_0.7.zip", repos = NULL)
install.packages("packages/proto_1.0.0.zip", repos = NULL)
install.packages("packages/chron_2.3-52.zip", repos = NULL)


##2.install.packages("tidyverse") #tidyverse
install.packages("packages/tidyverse_1.2.1.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/praise_1.0.0.zip", repos = NULL)
install.packages("packages/testthat_2.0.0.zip", repos = NULL)
install.packages("packages/mnormt_1.5-5.zip", repos = NULL)
install.packages("packages/processx_3.1.0.zip", repos = NULL)
install.packages("packages/psych_1.8.4.zip", repos = NULL)
install.packages("packages/callr_2.0.4.zip", repos = NULL)
install.packages("packages/clipr_0.4.1.zip", repos = NULL)
install.packages("packages/selectr_0.4-1.zip", repos = NULL)
install.packages("packages/dbplyr_1.2.1.zip", repos = NULL)
install.packages("packages/forcats_0.3.0.zip", repos = NULL)
install.packages("packages/haven_1.1.2.zip", repos = NULL)
install.packages("packages/hms_0.4.2.zip", repos = NULL)
install.packages("packages/lubridate_1.7.4.zip", repos = NULL)
install.packages("packages/modelr_0.1.2.zip", repos = NULL)
install.packages("packages/readr_1.1.1.zip", repos = NULL)
install.packages("packages/reprex_0.2.0.zip", repos = NULL)
install.packages("packages/rvest_0.3.2.zip", repos = NULL)

##3.install.packages("gridExtra") #gridExtra
install.packages("packages/gridExtra_2.3.zip", repos = NULL)

##4.install.packages("gapminder") #gapminder
install.packages("packages/gapminder_0.3.0.zip", repos = NULL)
