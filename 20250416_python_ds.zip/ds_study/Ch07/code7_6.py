import pandas as pd

df = pd.read_csv('d:/data/iris.csv')

# 순위
df['Petal_Length'].rank().astype(int) # 오름차순 순위
df['Petal_Length'].rank(ascending = False).astype(int) # 내림차순 순위