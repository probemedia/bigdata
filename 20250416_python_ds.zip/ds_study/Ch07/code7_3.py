import pandas as pd
from sklearn.impute import KNNImputer
from sklearn.preprocessing import MinMaxScaler

df_org = pd.read_csv('d:/data/iris.csv')
df_miss = df_org.copy()

# 결측값 생성
df_miss.iloc[0, 3] = pd.NA ; df_miss.iloc[0, 2] = pd.NA
df_miss.iloc[1, 2] = None ; df_miss.iloc[2, 3] = None
df_miss.head(4)

# (1) 데이터 표준화
scaler = MinMaxScaler()                         # 스케일러 정의
df_scaled = scaler.fit_transform(df_miss.iloc[:, :4]) # 표준화
df_scaled[0:5, :]

# (2) 결측값 추정
imputer = KNNImputer(n_neighbors=5)             # 추정모델 정의
df_scaled = imputer.fit_transform(df_scaled)    # 결측값 추정
df_scaled[0:5, :]

# (3) 표준화 이전으로 변환
df_filled = scaler.inverse_transform(df_scaled)
df_filled[0:5, :]

df_miss.iloc[:,:4] = df_filled                  # 추정값 -> 결측값 

# 추정값의 정확도 확인
df_miss.head(4)
df_org.head(4)