import pandas as pd
import itertools

df = pd.read_csv('d:/data/iris.csv')

# 임의 샘플링
df20 = df.sample(n=20, random_state=123)
df20

# 층화 샘플링
stratified = df.groupby('Species').apply(
    lambda x: x.sample(frac=0.2, random_state=123)
)
stratified

# 조합
species = df.Species.unique()

comb = list(itertools.combinations(species, 2))
comb
