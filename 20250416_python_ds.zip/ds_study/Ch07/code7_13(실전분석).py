import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('d:/data/airquality.csv')
df.head()

df.isnull().sum()  # 컬럼별 결측값 확인
df.isna().sum(axis=1).sum()  # 결측값이 있는 행의 수 확인

df_cleaned = df.reset_index(drop=True)

ozone = df_cleaned['Ozone']
Q1 = ozone.quantile(0.25)
Q3 = ozone.quantile(0.75)
IQR = Q3 - Q1

outliers = ozone[(ozone < Q1 - IQR*1.5) |
                 (ozone > Q3 + IQR*1.5)]
print(outliers)

df_cleaned = df_cleaned.loc[~df_cleaned['Ozone'].isin(outliers)]
df_cleaned

result = df_cleaned.groupby('Month')[['Ozone', 'Solar.R', 'Wind', 'Temp']].mean()
result
result.plot(marker='o')
plt.show()
