import pandas as pd
import matplotlib.pyplot as plt

# 데이터 읽기
df = pd.read_csv('d:/data/iris.csv')

# 그룹이 있는 다중 산점도 작성
dict = {'setosa': 'red', 'versicolor': 'green', 'virginica': 'blue'}
colors = list(dict[key] for key in df.Species)  # 각 점의 색 지정
colors

df.plot.scatter(x='Petal_Length',  # x축 변수명
                y='Petal_Width',  # y축 변수명
                s=30,  # 점의 크기
                c=colors,  # 점의 색깔
                marker='o')  # 점의 모양
plt.show()
