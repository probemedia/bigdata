import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv('d:/data/BostonHousing.csv')
house_price = df['medv']
house_price

house_price.mean()
house_price.median()
house_price.quantile([0.25, 0.5, 0.75])

quan = house_price.quantile([0.25, 0.5, 0.75])
bins = [house_price.min(), quan[0.25], quan[0.5], quan[0.75], house_price.
        max()]
labels = ['Q1', 'Q2', 'Q3', 'Q4']
grp = pd.cut(house_price, bins=bins, labels=labels)
avg = house_price.groupby(grp).mean()
avg.plot.bar()
plt.xlabel('Quartiles')
plt.ylabel('House Price')
plt.title('Average House Price by Quartiles')
plt.show()

house_price.plot.box()
plt.show()

house_price.plot.hist(bins=8)
plt.show()
