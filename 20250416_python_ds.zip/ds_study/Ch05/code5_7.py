import pandas as pd
import numpy as np

# 산포 계산
mydata = pd.Series([60, 62, 64, 65, 68, 69, 72])

mydata.var()  # 분산
mydata.std()  # 표준편차