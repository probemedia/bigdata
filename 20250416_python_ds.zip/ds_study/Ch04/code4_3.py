# 코드 4-1 #########################################################
import pandas as pd

df = pd.read_csv('d:/data/iris.csv')  # csv 파일 읽기

# 코드 4-1에 이어서 실행 ##############################################

# 인덱싱과 슬라이싱
df.iloc[2, 3]  # 2행 3열의 값
df.loc[3, 'Petal_Width']  # 'Petal_Width' 컬럼의 3행 값
df.loc[[0, 2, 4], ['Petal_Length', 'Petal_Width']]

df.loc[5:8, 'Petal_Length']  # 'Petal_Length' 컬럼의 5~8행 값
df.iloc[:5, :4]  # 0~4행, 0~3열의 값

df.loc[:, 'Petal_Length']  # 'Petal_Length' 컬럼의 모든 행의 값
df['Petal_Length']  # 'Petal_Length' 컬럼의 모든 값
df.Petal_Length  # 'Petal_Length' 컬럼의 모든 값

df.iloc[:5, :]  # 0~4행의 모든 컬럼의 값
df.iloc[:5]  # 0~4행의 모든 컬럼의 값