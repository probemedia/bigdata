# 코드 4-7 #########################################################
import pandas as pd

df = pd.read_csv('d:/data/iris.csv')  # csv 파일 읽기

# 데이터프레임 객체에 있는 값의 수정
df3 = df.copy()  # df를 df3로 복사
df3.iloc[1, 2] = 5.5  # 1행 2열의 값 수정

df3.loc[1, 'Petal_Length'] = 1.1
df3.loc[df.Petal_Length > 6.5, 'Petal_Length'] *= 100

# 코드 4-7에 이어서 실행 #######################################################

# 데이터프레임 객체에 대한 행과 컬럼의 추가

# 뒷부분에 새로운 행 추가
new_idx = df3.shape[0]  # 추가할 행 번호 결정
df3.loc[new_idx] = [1.1, 4.5, 3.4, 2.2, 'setosa']
df3.tail()

# 중간에 새로운 행 추가
new_row = pd.DataFrame([[1.1, 2.2, 3.3, 4.4, 'virginica']],
                       columns=df3.columns)
new_row
df3 = pd.concat([df3.iloc[:10], new_row, df3.iloc[10:]], ignore_index=True)
df3.iloc[8:13, :]  # 입력 결과 확인

# 여러 행 추가
ext = pd.DataFrame([[1.2, 3.5, 4.3, 3.1, 'setosa'],
                    [2.1, 3.2, 2.3, 5.2, 'versicolor']],
                   columns=df3.columns)
ext
df3 = df3._append(ext, ignore_index=True)
df3

# 뒤쪽에 컬럼 추가
new_col = df3.Petal_Length * 10
df3['new_col'] = new_col
df3

# 중간에 컬럼 추가
df4 = df.copy()
df4.insert(loc=2, column='new_col2', value=new_col)  # 컬럼 인덱스 2 위치에 추가
df4
