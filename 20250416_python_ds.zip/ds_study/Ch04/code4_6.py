# 코드 4-1 #########################################################
import pandas as pd

df = pd.read_csv('d:/data/iris.csv')  # csv 파일 읽기

# 코드 4-1에 이어서 실행 ############################################

# 데이터프레임의 통계 관련 메서드
df2 = df.loc[:, df.columns != 'Species']  # 숫자형 컬럼만 추출
df2.sum()  # 값들의 합계
df2.mean()  # 값들의 평균
df2.median()  # 값들의 중앙값
df2.max()  # 값들의 최댓값
df2.min()  # 값들의 최솟값
df2.std()  # 값들의 표준편차
df2.var()  # 값들의 분산
df2.abs()  # 값들의 절댓값
df2.describe()  # 기초 통계 정보
