# 코드 4-1 #########################################################
import pandas as pd

df = pd.read_csv('d:/data/iris.csv')  # csv 파일 읽기

# 코드 4-1에 이어서 실행 #########################################

# 데이터프레임 객체의 정보 확인
df.info()  # 배열의 정보
df.shape  # 배열의 형태
df.shape[0]  # 행의 개수
df.shape[1]  # 컬럼의 개수

df.dtypes  # 각 컬럼의 자료형
df['Species'] = df['Species'].astype('category')
df.dtypes

df.columns  # 컬럼들의 이름 보기

df.head()  # 데이터 앞부분 일부 보기
df.tail()  # 데이터 뒷부분 일부 보기

df['Species'].unique()  # 품종 정보 확인
