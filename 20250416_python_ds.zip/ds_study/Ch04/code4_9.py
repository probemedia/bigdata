# 코드 4-1 #########################################################
import pandas as pd

df = pd.read_csv('d:/data/iris.csv')  # csv 파일 읽기

# 코드 4-1에 이어서 실행 ##################################################

# 데이터프레임 객체에 대한 행과 컬럼의 삭제
df5 = df.copy()

# 행의 삭제
df5 = df5.drop(index=[1, 3])
df5
df5 = df5.reset_index()
df5

# 컬럼의 삭제
df5 = df5.drop(columns='Petal_Length')
df5