import sqlite3
import pandas as pd

# DB 연결
conn = sqlite3.connect('d:/data/empdb.db')

# dept 테이블 생성
df = pd.read_csv('d:/data/dept.csv')
df.to_sql(name='dept_df', con=conn, if_exists='replace', index=False,
          dtype={'DEPTNO': 'integer', 'DNAME': 'text', 'LOC': 'text'})

# emp 테이블 생성
df = pd.read_csv('d:/data/emp.csv')
df.to_sql(name='emp_df', con=conn, if_exists='replace', index=False)

conn.close()  # DB 연결 종료
