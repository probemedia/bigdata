# 사용자 정의 클래스를 이용한 SQL 연습의 예

import os
os.chdir('d:/ds_study/Ch13/')     # SQLite.py 가 있는 폴더 지정
from SQLite import *
SL = SQLite()  # SQLite 객체 생성

sql = "select * from dept"
SL.run_sql(sql)  # 질의 결과 확인

sql = "select * from emp \
    where sal > 2500"
result = SL.run_sql(sql)
result
result['SAL'].sum()  # 질의 결과 가공

SL.close_db()  # DB 작업 종료
