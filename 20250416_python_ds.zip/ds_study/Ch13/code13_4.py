from SQLite import *
import pandas as pd

import os
os.chdir('d:/ds_study/Ch13/')     # SQLite.py 가 있는 폴더 지정
SL = SQLite()

# subway 테이블 생성
df = pd.read_csv('d:/data/subway_line_1_8_20231231.csv')
df.to_sql('subway', con=SL.conn, if_exists='replace', index=False)

SL.close_db()
