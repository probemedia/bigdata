a = 10
b = 20
c = (a+b) - 5
print(c)