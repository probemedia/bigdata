import pandas as pd

# 시리즈에 레이블 부여
age = pd.Series([25, 34, 19, 45])
age  # 레이블 부여 전
age.index = ['John', 'Jane', 'Tom', 'Luka']  # 행에 레이블 부여
age  # 레이블 부여 후

age.iloc[2]  # 절대 위치에 의한 인덱싱
age.loc['Tom']  # 레이블에 의한 인덱싱
# 데이터프레임에 레이블 부여

score = pd.DataFrame([[85, 96, 40, 95],
                      [73, 69, 45, 80],
                      [78, 50, 60, 90]])

score  # 레이블 부여 전
score.index = ['John', 'Jane', 'Tom']  # 행에 레이블 부여
score.columns = ['KOR', 'ENG', 'MATH', 'SCI']  # 열에 레이블 부여
score  # 레이블 부여 후

score.iloc[2, 1]  # 절대 위치에 의한 인덱싱
score.loc['Tom', 'ENG']  # 레이블에 의한 인덱싱