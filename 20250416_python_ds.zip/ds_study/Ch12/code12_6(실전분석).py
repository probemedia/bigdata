import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier as KNC

# 데이터 준비, 표준화
df = pd.read_csv('d:/data/iris.csv')
df.head()

X = df.drop('Species', axis=1)
y = df['Species']

scaler = StandardScaler()
scaler.fit(X)
result = scaler.transform(X)
X_scaled = pd.DataFrame(result, columns=X.columns)
X_scaled.head()

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y,
                                                    test_size=0.3, random_state=123, stratify=y)

knn = KNC(n_neighbors=3)
knn.fit(X_train, y_train)

# 모델 평가: 정확도(accuracy)
knn.score(X_test, y_test)

data = pd.DataFrame([[4.8, 3.1, 1.4, 0.2]],
                    columns=X_test.columns)
data = scaler.transform(data)
plant = pd.DataFrame(data,
                     columns=X_test.columns)
plant

pred = knn.predict(plant)
pred

for i in range(1, 11):
    knn = KNC(n_neighbors=i)
    knn.fit(X_train, y_train)
    print(i, knn.score(X_test, y_test))
