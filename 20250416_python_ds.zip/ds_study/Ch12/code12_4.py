import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier as KNC

# 데이터 준비
df = pd.read_csv('d:/data/PimaIndiansDiabetes.csv')
df.head()
df.groupby('diabetes')['diabetes'].count()

X = df.drop('diabetes', axis=1)
y = df['diabetes']

# 데이터 표준화
scaler = StandardScaler()
scaler.fit(X)
result = scaler.transform(X)
X_scaled = pd.DataFrame(result, columns=X.columns)
X_scaled.head()

# 훈련용, 검증용 데이터 분리
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.3, random_state=123, stratify=y)

# 모델 생성
knn = KNC(n_neighbors=3)
knn.fit(X_train, y_train)

# 모델 평가: 정확도(accuracy)
knn.score(X_test, y_test)

# 모델 활용
# 1명의 환자 예측
data = pd.DataFrame([[8, 182, 64, 0, 0, 23, 0.67, 32]],
                    columns=X_test.columns)
data = scaler.transform(data)
patient = pd.DataFrame(data,
                       columns=X_test.columns)
patient

pred = knn.predict(patient)
pred

# 여러 명의 환자 예측
pred = knn.predict(X_test)
pred
