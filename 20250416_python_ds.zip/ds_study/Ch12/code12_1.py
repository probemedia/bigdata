import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

# 데이터 준비
df = pd.read_csv('d:/data/iris.csv')
df = df.drop('Species', axis=1)
df.head()

# 데이터 표준화
scaler = StandardScaler()
result = scaler.fit_transform(df)
df_scaled = pd.DataFrame(result, columns=df.columns)
df_scaled.head()

# 차원 축소
pca = PCA(n_components=2)
transform = pca.fit_transform(df_scaled)  # 2차원으로 축소
transform = pd.DataFrame(transform)
transform.head()

# 시각화
transform.plot.scatter(x=0, y=1,  # 산점도
                       title='PCA plot')
plt.show()
