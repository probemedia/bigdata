import pandas as pd
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns

# 데이터 준비
df = pd.read_csv('d:/data/iris.csv')
df = df.drop('Species', axis=1)
df.head()

# 데이터 표준화
scaler = StandardScaler()
result = scaler.fit_transform(df)
df_scaled = pd.DataFrame(result, columns=df.columns)
df_scaled.head()

# 군집화
model = KMeans(n_clusters=3, n_init=10, random_state=123)
model.fit(df_scaled)

# 군집화 결과 확인
model.cluster_centers_  # 군집 중심점 좌표
model.labels_  # 각 행의 군집 번호
model.inertia_  # 군집 평가 점수

# 차원 축소
pca = PCA(n_components=2)
transform = pca.fit_transform(df_scaled)  # 2차원으로 축소
transform = pd.DataFrame(transform)
transform['cluster'] = model.labels_  # 군집 정보 추가
transform.head()

# 시각화
sns.scatterplot(
    data=transform,
    x=0,  # x축
    y=1,  # y축
    hue="cluster",  # 원의 색
    palette='Set2',  # 팔레트 선택
    legend=False  # 범례 표시 여부
)

plt.show()

# 12-2에 이어서 실행

# 적절한 k-값 결정
ks = range(1, 10)  # 군집의 개수
inertias = pd.Series([])  # 군집화 평가 결과

for k in ks:
    model = KMeans(n_clusters=k,
                   n_init=10, random_state=123)
    model.fit(df_scaled)
    inertias.loc[k] = model.inertia_

plt.figure(figsize=(7, 4))
inertias.plot.line(title='Inertias Score',
                   xlabel='number of clusters, k',
                   ylabel='inertia')
plt.show()
