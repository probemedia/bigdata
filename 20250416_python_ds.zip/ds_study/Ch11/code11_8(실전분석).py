import seaborn as sns
from scipy import stats

df = sns.load_dataset('titanic')

result = df.pivot_table(index='pclass',
columns='alive',
values='alone',
aggfunc='count')
result

result['yes']/(result.sum(axis=1))

stats.chi2_contingency(result)[3]

stats.chi2_contingency(result)[1]