import seaborn as sns
import matplotlib.pyplot as plt

df = sns.load_dataset('flights')
df.head()

# 그래프 테마 설정
sns.set_theme(style="whitegrid", rc={"figure.figsize": (8, 5)})
sns.set_palette('hls', 12)

# 월별, 연도별 항공기 탑승객 수
sns.lineplot(data=df,  # df 이름
             x='year',  # x축 컬럼
             y='passengers',  # y축 컬럼
             hue='month'  # 그룹 지정
             )
plt.show()
