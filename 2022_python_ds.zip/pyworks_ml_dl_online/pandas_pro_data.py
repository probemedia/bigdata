# -*- coding: utf-8 -*-
"""
Created on Tue May 12 09:39:42 2020

@author: KEO
"""
import pandas as pd
# %%
# (1) 변수(필드)추출
df1 = pd.read_excel('data/20200426_excel_test.xlsx', sheet_name=0)
print(df1)
# %%
print(df1.columns)
print(df1.values)
# %%
print(df1['자치구'])
# %%
print(df1[['자치구', '인구수']])
# %%
print(df1.loc[:, :])
# %%
print(df1.loc[:, '자치구'])
# %%
print(df1.loc[:, ['자치구', '인구수']])
# %%
print(df1.loc[:, '자치구':'인구수'])
# %%
print(df1.iloc[:, :])
# %%
print(df1.iloc[:, 0])
# %%
print(df1.iloc[:, 0:2])
# %%
print(df1.iloc[:, [0, 2]])
# %%
# (2)값 1개 추출
print(df1)
# %%
print(df1.at[5, '인구수'])
# %%
df1_1 = df1.set_index('자치구')
print(df1_1)
# %%
print(df1_1.at['동대문구', '인구수'])
# %%
df1_1 = df1_1.reset_index()
print(df1_1)
# %%
# (3) 인덱스 지정과 복귀

df_oz = pd.read_csv('data/ozone_data.csv', encoding="cp949")
print(df_oz.columns)
# %%
df_oz1 = df_oz[['일시', '평균오존전량(DU)']]
df_oz1 = df_oz1.set_index('일시')
print(df_oz1)
# %%
df_oz1 = df_oz1.reset_index()
print(df_oz1)
# %%
# (4)새 필드 추가 : 파생변수 생성
df1_pop = df1
print(df1_pop.head())
# %%
df1_pop['세대당인구수'] = df1_pop['인구수'] / df1_pop['세대수']
print(df1_pop.head())
# %%
df1_pop['여자인구수_대비_남자인구수비율'] = \
  df1_pop['남자인구수'] / df1_pop['여자인구수']
print(df1_pop.head())

# %%
# (5) 필터링 - 데이터추출
df_ol = pd.read_excel('data/20180217_2017년서울시구별노령화지수.xlsx')
print(df_ol)
# %%
df_ol2 = df_ol.iloc[1:, 1:]
print(df_ol2)
# %%
print(df_ol2[df_ol2['노령화지수'] < 100])
# %%
print(df_ol2[df_ol2['노령화지수'] >= 150])
# %%
df_ol_new = pd.read_excel('data/20191006_2018_서울시_자치구별_노령화지수.xlsx')
print(df_ol_new)
# %%
df_ol_new2 = df_ol_new.iloc[1:, :]
print(df_ol_new2)
# %%
# (6) 조인 - 변수 결합
df_ol_joined = df_ol2.set_index('자치구').join(df_ol_new2.set_index('구분'))
print(df_ol_joined)
# %%
df_ol_joined.reset_index(inplace=True)
print(df_ol_joined)
# %%
# (7) 변수명 변경 : rename()
df_ol_joined.rename(
        columns={'합계': '노령화지수_2018평균', '남자': '남자노령화지수_2018',
                 '여자': '여자노령화지수_2018'}, inplace=True)
print(df_ol_joined)
# %%
# (8) 바인딩: append()함수, concat()함수
df_subway2 = pd.read_csv("data/20200423_202002_서울지하철승하차인원수.csv",
                         encoding='cp949', engine="python")
print(df_subway2.shape)
# %%
df_subway3 = pd.read_csv("data/20200423_202003_서울지하철승하차인원수.csv",
                         encoding='cp949', engine="python")
print(df_subway3.shape)
# %%
# append()함수
df_subway_new = df_subway2.append(df_subway3, ignore_index=True)
print(df_subway_new.shape)
# %%
# concat()함수 - 데이터 결합
df_subway_new2 = pd.concat([df_subway2, df_subway3], ignore_index=True)
print(df_subway_new2.shape)
# %%
# concat()함수 - 변수 결합
df_subway_joined2 = pd.concat([df_ol2, df_ol_new2], axis=1, join='inner')
print(df_subway_joined2)
# %%
print(df_subway2['노선명'].value_counts())
# %%
print(df_subway2.노선명.value_counts())
# pd.crosstab(df_subway2['노선명'], df_subway2['역명'])
# %%
import matplotlib as mpl
import matplotlib.pyplot as plt
import platform

plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    mpl.rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = mpl.font_manager.FontProperties(fname=path).get_name()
    mpl.rc('font', family=font_name)
else:
    print("Unknown System OS")
# %%
# (9) 그룹화 : groupby()
print(df_subway_new.columns)
print(df_subway_new['하차총승객수'].sum())
# %%
df_subway_groupby = df_subway_new.groupby('노선명').sum()
print(df_subway_groupby)
print(df_subway_groupby.shape)
# %%
df_subway_groupby['하차총승객수'].plot(kind='bar', rot=45, figsize=(12, 7))
# %%
df_subway_groupby['하차총승객수'].plot(kind='pie', figsize=(10, 10))

# %%
# 7. pandas 결측치 처리
# (1) NaN을 처리하는 메소드
df = pd.read_csv("data/20200511_ghg.csv", encoding='cp949')

print(df.columns)
# %%
print(df.info())
# %%
print(df["CH4_ppm"].count())
# %%
print(df["CH4_ppm"].dropna())
# %%
print(df["CH4_ppm"].fillna(0))
# %%
print(df["CH4_ppm"].fillna(method='ffill'))
# %%
print(df["CH4_ppm"].fillna(method='bfill'))
# %%
print(df["CH4_ppm"].isnull().sum())
print(df["CH4_ppm"].notnull().sum())
# %%
# (2) 결측치 처리
df_air = df[['시간', 'CO2_ppm', 'CH4_ppm']]
print(df_air[df_air['CH4_ppm'].notnull()])
# %%
print(df.describe())
# %%
df_air2 = df.fillna(method='bfill')
print(df_air2.describe())
# %%
# (3) 이상치 처리
print(df_air2["CO2_ppm"])
# %%
co2_q1 = df_air2["CO2_ppm"].quantile(0.25)
co2_q3 = df_air2["CO2_ppm"].quantile(0.75)

co2_nm_min = co2_q1 - (co2_q3 - co2_q1) * 1.5
co2_nm_max = co2_q3 + (co2_q3 - co2_q1) * 1.5

print(df_air2[df_air2["CO2_ppm"] >= co2_nm_min])
# %%
print(df_air2[df_air2["CO2_ppm"] <= co2_nm_max])
# %%
print(df_air2[(df_air2["CO2_ppm"] >= co2_nm_min) & (df_air2["CO2_ppm"] <= co2_nm_max)])
