import numpy as np
from sklearn import svm, metrics
# CSV 파일을 읽어 들이고 가공하기 --- (※1)


def load_csv(fname):
    labels = []
    images = []
    with open(fname, "r") as f:
        for line in f:
            cols = line.split(",")
            if len(cols) < 2:
                continue
            labels.append(int(cols.pop(0)))
            vals = list(map(lambda n: int(n) / 256, cols))
            images.append(vals)
    return {"labels": labels, "images": images}


data = load_csv("./mnist/train.csv")
test = load_csv("./mnist/t10k.csv")
np.random.seed(1909)
# 학습하기 --- (※2)
clf = svm.SVC()
clf.fit(data["images"], data["labels"])
# 예측하기 --- (※3)
predict = clf.predict(test["images"])
# 결과 확인하기 --- (※4)
ac_score = metrics.accuracy_score(test["labels"], predict)
cl_report = metrics.classification_report(test["labels"], predict)
print("정답률 =", ac_score)
print("리포트 =")
print(cl_report)

# %%
from sklearn.externals import joblib
joblib.dump(clf, "minist.joblib")
# %%
minist_pre = joblib.load("minist.joblib")
result = minist_pre.predict(data["images"])
true_dat = data["labels"]

rlist = 0
for i in range(result.size):
    if(result[i] == true_dat[i]):
        rlist += 1

tr = rlist / result.size

print("Ture rate : " + str(tr))
# %%
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn import svm, metrics
np.random.seed(1909)  # 재현성확보에 필요
# 분류기 이름 -> (선 스타일, 분류기 인스턴스)
CLASS_MAP = {
        '로지스틱 회귀': ('-', LogisticRegression()),
        '나이브 베이즈': ('--', GaussianNB()),
        '결정 트리': ('.-', DecisionTreeClassifier(max_depth=5)),
        '랜덤 포레스트': (':', RandomForestClassifier()),
        'SVM': (':', svm.SVC())
}


def load_csv(fname):
    labels = []
    images = []
    with open(fname, "r") as f:
        for line in f:
            cols = line.split(",")
            if len(cols) < 2:
                continue
            labels.append(int(cols.pop(0)))
            vals = list(map(lambda n: int(n) / 256, cols))
            images.append(vals)
    return {"labels": labels, "images": images}


# 데이터 읽기
data = load_csv("./mnist/train.csv")
test = load_csv("./mnist/t10k.csv")
# 데이터 내부의 기호를 숫자로 변환하기--- (※2)

# 학습 전용과 테스트 전용 데이터로 나누기 --- (※3)

# 데이터 학습시키기 --- (※4)
for name, (line_fmt, model) in CLASS_MAP.items():
    model.fit(data["images"], data["labels"])
    # 데이터 예측하기 --- (※5)
    predict = model.predict(test["images"])
    # 결과 테스트하기 --- (※6)
    ac_score = metrics.accuracy_score(test["labels"], predict)
    cl_report = metrics.classification_report(test["labels"], predict)
    print("분류기 :", name)
    print("정답률 =", ac_score)
    print("리포트 =\n", cl_report)
