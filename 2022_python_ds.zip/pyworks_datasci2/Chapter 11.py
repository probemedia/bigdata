
# coding: utf-8

# # 11장
import numpy as np
import scipy as sp
import pandas as pd

from matplotlib import pyplot as plt
import sklearn.datasets
from sklearn.cross_validation import train_test_split
from sklearn.linear_model import LinearRegression, Lasso
from sklearn.preprocessing import normalize
from sklearn.metrics import r2_score
from sklearn.linear_model import LinearRegression
from scipy.optimize import curve_fit

from matplotlib import font_manager, rc
import platform

# matplotlib 한글꺠짐 처리
plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font', family=font_name)
else:
    print("Unknown System OS")

# %%

# # 11.1 당뇨병 예측

import sklearn.datasets
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.cross_validation import train_test_split
from sklearn.linear_model import LinearRegression, Lasso
from sklearn.preprocessing import normalize
from sklearn.metrics import r2_score
import seaborn as sns
np.random.seed(190811)  # 재현성확보에 필요

diabetes = sklearn.datasets.load_diabetes()
X, Y = normalize(diabetes['data']), diabetes['target']
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=.8)
linear = LinearRegression()
linear.fit(X_train, Y_train)
preds_linear = linear.predict(X_test)
corr_linear = round(pd.Series(preds_linear).corr(
    pd.Series(Y_test)), 3)
rsquared_linear = r2_score(Y_test, preds_linear)
print("선형 계수:")
print(linear.coef_)
plt.scatter(preds_linear, Y_test)
plt.title("선형 회귀 결과. 상관관계=%f  $R^2$ 점수=%f"
          % (corr_linear, rsquared_linear))
plt.xlabel("예측값")
plt.ylabel("실제값")
# 비교를 위해 x=y 라인 추가
plt.plot(Y_test, Y_test, 'k--')

plt.show()

lasso = Lasso()
lasso.fit(X_train, Y_train)
preds_lasso = lasso.predict(X_test)
corr_lasso = round(pd.Series(preds_lasso).corr(
    pd.Series(Y_test)), 3)
rsquared_lasso = round(
    r2_score(Y_test, preds_lasso), 3)
print("라쏘 계수:")
print(lasso.coef_)
plt.scatter(preds_lasso, Y_test)
plt.title("라쏘 회귀 결과. 상관관계=%f  $R^2$ 점수=%f"
          % (corr_lasso, rsquared_lasso))
plt.xlabel("예측값")
plt.ylabel("실제값")
# 비교를 위해 x=y 라인 추가
plt.plot(Y_test, Y_test, 'k--')

plt.show()

# %%
# # 11.2 선형 회귀

import numpy as np
from sklearn.linear_model import LinearRegression

np.random.seed(190811)  # 재현성확보에 필요
x = np.array([[0.0], [1.0], [2.0]])

y = np.array([1.0, 2.0, 2.9])

lm = LinearRegression().fit(x, y)

lm.coef_

lm.intercept_

# %%
# # 11.3 커브 피팅


from scipy.optimize import curve_fit
import numpy as np

np.random.seed(190811)  # 재현성확보에 필요

xs = np.array([1.0, 2.0, 3.0, 4.0])
ys = 2.0 + 3.0 * xs * xs + 0.2 * np.random.uniform(3)


def calc(x, a, b):
    return a + b * x * x


cf = curve_fit(calc, xs, ys)
best_fit_params = cf[0]

best_fit_params

# %%
import pandas as pd

df_ozone = pd.read_csv("ozone_data.csv", encoding="cp949")
df_ozone.columns.values
df_1 = df_ozone[['일시', '평균오존전량(DU)']]
df_1.plot()


