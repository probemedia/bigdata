import sqlite3
import pandas as pd

class SQLite:
    def __init__(self, db_path='d:/data/empdb.db'):
        self.conn = sqlite3.connect(db_path)
        self.cur = self.conn.cursor()

    def close_db(self):  # 커서와 DB 연결 종료
        self.cur.close()
        self.conn.close()

    def run_sql(self, sql):  # SQL 문 실행
        self.cur.execute(sql)
        result = self.cur.fetchall()
        columns = [column[0] for column in self.cur.description]
        df_result = pd.DataFrame(result, columns=columns)
        return df_result
