import os
os.chdir('d:/ds_study/Ch13/')     # SQLite.py 가 있는 폴더 지정
from SQLite import *

SL = SQLite()  # SQLite 객체 생성

sql = "select 호선명, 승객유형, t07_08시간대+t08_09시간대 from subway"
result = SL.run_sql(sql)
result.head()

# 피벗 테이블 생성
df_pivot = result.pivot_table(index='호선명',
                              columns='승객유형',
                              values='t07_08시간대+t08_09시간대',
                              aggfunc='sum')
df_pivot

# csv 저장
df_pivot.to_csv('subway_summary.csv', encoding='EUC-KR')

SL.close_db()  # DB 작업 종료
