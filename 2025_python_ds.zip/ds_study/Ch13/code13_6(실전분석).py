import geokakao as gk
import pandas as pd

import os
os.chdir('d:/ds_study/Ch13/')     # SQLite.py 가 있는 폴더 지정
from SQLite import *

SL = SQLite()

# store 테이블 생성
df = pd.read_csv('d:/data/seoul_201712.csv')
df.to_sql('store', con=SL.conn, if_exists='replace', index=False)

sql = 'select * from store where rowid <= 10'
SL.run_sql(sql)  # 질의 결과 확인

addr = '서울특별시 강남구 강남대로 지하396'
lat_lon = gk.convert_address_to_coordinates(addr)
lat_lon = [float(lat_lon[0]), float(lat_lon[1])]  # 문자열을 숫자로 변환

sql = "select store_name, class_small from store \
    where lat between {} and {} \
        and lon between {} and {}".format(lat_lon[0]-0.001, lat_lon[0]+0.001,
                                          lat_lon[1]-0.001, lat_lon[1]+0.001)

result = SL.run_sql(sql)  # 질의 결과 확인
result.info()
result.head()

result.to_csv('d:/ds_study/store_info.csv', encoding='EUC-KR')

SL.close_db()  # DB 작업 종료
