import pandas as pd

# 2차원 리스트로부터 데이터프레임 생성
score = pd.DataFrame([[85, 96, 40, 95],
                      [73, 69, 45, 80],
                      [78, 50, 60, 90]])
score  # score 내용 출력
type(score)  # score 자료형 출력

score.index  # 행 방향 인덱스
score.columns  # 열 방향 인덱스

score.iloc[1, 2]  # 인덱스 1행 2열의 값