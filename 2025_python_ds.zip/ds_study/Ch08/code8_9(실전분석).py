import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.graphics.mosaicplot import mosaic

plt.rcParams['font.family'] ='Malgun Gothic' # 한글 폰트 설정
plt.rcParams['axes.unicode_minus'] = False # 마이너스 부호 깨짐 방지

df = sns.load_dataset('titanic')

dict1 = {0:'사망', 1:'생존'}
dict2 = {1:'1등실', 2:'2등실', 3:'3등실'}

df = df.replace({'survived': dict1})
df = df.replace({'pclass': dict2})
df.head()

df2 = df.pivot_table(index = 'pclass', # 행 위치에 들어갈 컬럼
                    columns = 'survived', # 열 위치에 들어갈 컬럼
                    values = 'class', # 데이터로 사용할 컬럼
                    aggfunc = 'count' # 데이터 집계함수
                    )

df2

df2.plot.bar(stacked=True)
plt.subplots_adjust(bottom=0.2)
plt.show()

props = lambda key: {'color': 'lightgreen' if '생존' in key else 'yellow'}

# 그래프 작성
mosaic(data = df.sort_values('pclass'),
index = ['pclass', 'survived'],
properties = props, # 타일 색상 변경
axes_label = True, # 축 레이블 표시
title='타이타닉 선실별 생존비율' # 그래프 제목
)

plt.show()

import plotly.express as px
import matplotlib.image as mpimg

df3 = df.groupby(['pclass', 'survived'])['sex'].count()
df3 = df3.reset_index()
df3.columns = ['pclass', 'survived', 'population']

fig = px.treemap(data_frame = df3,
path=['pclass', 'survived'], # 데이터의 계층 구조
values='population', # 타일 면적 기준 컬럼
color='population', # 색 온도 기준 컬럼
color_continuous_scale='Bluyl' # 컬러 팔레트
)

plt.axis('off') # 축 눈금 제거
fig.update_layout(title_text = 'Titinic', # 그래프 제목
title_font_size =20) # 제목 폰트 크기

# 그래프 저장 & 화면에 표시하기
fig.write_image('treemap.png')
plt.imshow(mpimg.imread('treemap.png'))
plt.show()