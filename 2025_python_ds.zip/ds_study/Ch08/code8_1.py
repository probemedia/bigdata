import seaborn as sns
import matplotlib.pyplot as plt
df = sns.load_dataset('tips')
df.head()

# 그래프 테마 설정
sns.set_theme(style="whitegrid", rc={"figure.figsize": (5, 5)})
sns.set_palette('hls', 4)

# 요일별 평균 지불 금액
sns.barplot(data=df,  # df 이름
            x='day',  # x축 컬럼
            y='total_bill',  # y축 컬럼
            estimator='mean',  # y축 컬럼 적용 함수
            hue='day',  # 그룹 지정
            legend=None  # 범례 표시 안 함
            )
plt.show()

# 요일별 성별 평균 지불 금액
sns.barplot(data=df,  # df 이름
            x='day',  # x축 컬럼
            y='total_bill',  # y축 컬럼
            estimator='mean',  # y축 컬럼 적용 함수
            hue='sex',  # y축 값의 그룹핑 기준
            ci=None  # 에러선 삭제
            )
plt.show()

# 누적 막대그래프
df2 = df.pivot_table(index='day',  # 행 위치에 들어갈 컬럼
                     columns='sex',  # 열 위치에 들어갈 컬럼
                     values='total_bill',  # 데이터로 사용할 컬럼
                     aggfunc='mean'  # 데이터 집계함수
                     )
df2
df2.plot.bar(stacked=True)
plt.subplots_adjust(bottom=0.2)
plt.show()
