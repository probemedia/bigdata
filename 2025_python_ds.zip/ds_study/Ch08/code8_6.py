import seaborn as sns
import matplotlib.pyplot as plt

flights = sns.load_dataset('flights')
flights.head()

# 피벗 테이블 생성
df = flights.pivot_table(index='month',  # 행 위치에 들어갈 컬럼
                         columns='year',  # 열 위치에 들어갈 컬럼
                         values='passengers',  # 데이터로 사용할 컬럼
                         aggfunc='mean'  # 데이터 집계함수
                         )
df.head()

# 히트맵 작성
sns.set_theme(rc={'figure.figsize': (8, 7)})
sns.heatmap(df).set_title('Heatmap of Flight Passenger', fontsize=20)
plt.show()
