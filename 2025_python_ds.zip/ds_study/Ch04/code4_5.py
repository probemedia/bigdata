# 코드 4-1 #########################################################
import pandas as pd

df = pd.read_csv('d:/data/iris.csv')  # csv 파일 읽기

# 코드 4-1에 이어서 실행 ##############################################

# 데이터프레임 객체에 대한 산술 연산
df.loc[:, df.columns != 'Species'] # 'Species' 컬럼 제외
df.loc[:, ~df.columns.isin(['Species'])] # 'Species' 컬럼 제외

df.loc[:, df.columns != 'Species'] + 10 # 모든 값에 10을 더함

df['Sepal_Length'] + df['Petal_Length'] # 두 컬럼의 같은 행 값들끼리 연산
# 꽃잎의 길이가 5 이상인 경우에는 꽃잎의 길이에 –1을 곱하시오
# (5 미만인 경우에는 원래 값 유지)
tmp = df['Petal_Length'].apply(lambda x: -1 if x >= 5 else 1)
tmp
df['Petal_Length'] * tmp