# 코드 4-1 #########################################################
import pandas as pd

df = pd.read_csv('d:/data/iris.csv')  # csv 파일 읽기

# 코드 4-1에 이어서 실행 ############################################

# 데이터프레임 객체에 있는 값의 수정
df3 = df.copy()  # df를 df3로 복사
df3.iloc[1, 2] = 5.5  # 1행 2열의 값 수정

df3.loc[1, 'Petal_Length'] = 1.1

df3.Petal_Length.to_list()  # 시리즈를 리스트 형태로 출력
df3.loc[df.Petal_Length > 6.5, 'Petal_Length'] *= 100
df3.Petal_Length.to_list()  # 시리즈를 리스트 형태로 출력
