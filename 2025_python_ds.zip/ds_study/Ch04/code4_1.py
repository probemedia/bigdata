import pandas as pd

df = pd.read_csv('d:/data/iris.csv')  # csv 파일 읽기
df  # 내용 확인