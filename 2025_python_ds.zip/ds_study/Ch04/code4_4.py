# 코드 4-1 #########################################################
import pandas as pd

df = pd.read_csv('d:/data/iris.csv')  # csv 파일 읽기

# 코드 4-1에 이어서 실행 ###########################################

# 조건문을 이용한 슬라이싱

# 꽃잎의 길이가 6.5 이상인 행들의 모든 컬럼을 보이시오
df.loc[df.Petal_Length >= 6.5, :]
df.loc[df.Petal_Length >= 6.5]  # 모든 컬럼의 경우 컬럼 인덱스 생략

# 꽃잎의 길이가 6.5 이상인 행들의 인덱스 번호를 보이시오
df.loc[df.Petal_Length >= 6.5].index

# 꽃잎의 길이가 3.5~3.8 사이인 행들의 모든 컬럼을 보이시오
df.loc[(df.Petal_Length >= 3.5) &
       (df.Petal_Length <= 3.8)]

# 꽃잎의 길이가 1.3 미만이거나 6.5를 초과하는 행들의 꽃잎의 길이와 폭을 보이시오
df.loc[(df.Petal_Length < 1.3) |
       (df.Petal_Length > 6.5), ['Petal_Length', 'Petal_Width']]

# where()를 이용한 조건 검색
df.where(df.Petal_Length >= 6.5).dropna()
