emp = pd.read_csv('d:/data/emp.csv')
dept = pd.read_csv('d:/data/dept.csv')
emp.head()
dept.head()

df = emp.merge(dept, on='DEPTNO')
df.head()

df.pivot_table(index='LOC', columns='JOB', values='SAL', aggfunc='sum')

df.pivot_table(index='DNAME', columns='JOB', values='ENAME', aggfunc='count')
