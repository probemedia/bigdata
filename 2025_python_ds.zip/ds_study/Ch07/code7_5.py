import pandas as pd

df = pd.read_csv('d:/data/iris.csv')

# 데이터프레임의 정렬
# 오름차순 정렬
df_sorted = df.sort_values('Sepal_Length')
df_sorted.head(10)

# 내림차순 정렬
df_sorted = df.sort_values('Sepal_Length', ascending=False)
df_sorted.head(10)

# 여러 개의 기준 컬럼 적용
df_sorted = df.sort_values(['Species', 'Sepal_Width'])
df_sorted.head(10)
