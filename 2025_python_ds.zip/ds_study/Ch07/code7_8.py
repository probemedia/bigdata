import pandas as pd
df = pd.read_csv('d:/data/iris.csv')

df_agg = df.groupby('Species').mean()  # 평균
df_agg

df_agg = df.groupby('Species').std()  # 표준편차
df_agg
