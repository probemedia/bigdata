import pandas as pd
from scipy import stats

# 데이터 준비
df = pd.read_csv('d:/data/prestige.csv')
df.info()
df.head()

group_1 = df.loc[df.type == 'bc', 'income']  # 블루칼라
group_2 = df.loc[df.type == 'wc', 'income']  # 화이트칼라
group_1
group_2

group_1.count()  # 그룹별 표본 크기
group_2.count()  # 그룹별 표본 크기
group_1.mean()  # 그룹별 평균
group_2.mean()  # 그룹별 평균

stats.shapiro(group_1)
stats.shapiro(group_2)

stats.levene(group_1, group_2)

stats.ttest_ind(group_1, group_2, equal_var=True)
