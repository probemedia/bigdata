import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt

df = pd.read_csv('d:/data/paired_ttest.csv')

# 데이터 탐색
df.head()
df[['before', 'after']].mean()  # 그룹별 평균
(df['after']-df['before']).mean()  # before, after 차이의 평균

fig, axes = plt.subplots(nrows=1, ncols=2)
df['before'].plot.box(grid=False, ax=axes[0])
plt.ylim([60, 100])
df['after'].plot.box(grid=False, ax=axes[1])
plt.show()

# 정규성 검정
stats.shapiro(df['after']-df['before'])

# 대응표본 t-검정
result = stats.ttest_rel(df['before'], df['after'])
result
