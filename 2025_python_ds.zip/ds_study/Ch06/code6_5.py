# 여러 변수 간 상관계수
import pandas as pd

df = pd.read_csv('d:/data/iris.csv')
df2 = df.loc[:, ~df.columns.isin(['Species'])]  # 품종 컬럼 제외

df2.corr() # 4개 변수 간 상관성 분석
