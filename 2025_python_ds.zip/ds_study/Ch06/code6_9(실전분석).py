import pandas as pd
import matplotlib.pyplot as plt
state = pd.read_csv('d:/data/state_x77.csv')
division = pd.read_csv('d:/data/state_division.csv')
state['division'] = division
state.head()

state.plot.scatter(x='Illiteracy', y='Income')
plt.show()
state['Illiteracy'].corr(state['Income'])

state.plot.scatter(x='Income', y='Life_Exp')
plt.show()
state['Income'].corr(state['Life_Exp'])

pd.plotting.scatter_matrix(state, figsize=(10, 10))
plt.show()

state_tmp = state.drop(['State', 'division'], axis=1)
state_tmp.corr()

pop = state.groupby('division')['Population'].sum()
pop  # 지역별 주의 인구수 합계
pop.plot.bar()
plt.xlabel('Division')
plt.ylabel('Population')
plt.title('Population by Division')
plt.subplots_adjust(bottom=0.3)
plt.show()

dict = {'East South Central': 'black', 'Pacific': 'grey', 'Mountain': 'brown',
        'West South Central': 'red', 'New England': 'orange',
        'South Atlantic': 'green', 'East North Central': 'blue',
        'West North Central': 'cyan', 'Middle Atlantic': 'purple'}
colors = list(dict[key] for key in state.division)  # 각 점의 색을 지정

state.plot.scatter(x='HS_Grad', y='Income', c=colors)
plt.show()
