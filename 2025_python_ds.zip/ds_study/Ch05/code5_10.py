import pandas as pd
import matplotlib.pyplot as plt

# 데이터 불러오기
df = pd.read_csv('d:/data/iris.csv')

# 상자그림 그리기
df.boxplot(column='Petal_Length',  # 상자그림 대상 컬럼
           by='Species',  # 그룹 정보 컬럼
           grid=False)  # 격자 표시 제거
plt.suptitle('')  # 기본 표시 제목 제거
plt.show()
