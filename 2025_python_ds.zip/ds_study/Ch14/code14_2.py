# code 14_1 에 이어서 실행

# 데이터 기본 정보 확인 및 분석 대상 데이터 추출하기

df.info()
df['수집년월'].unique()
df.groupby('상권업종대분류명')['상권업종대분류명'].count()
df.groupby('상권업종중분류명')['상권업종중분류명'].unique().index
df.groupby('상권업종소분류명')['상권업종소분류명'].unique().index

# 결측값 확인
df.isna().sum()
# 201712 수집 데이터만 추출
df_201712 = df.loc[df.수집연월 == 4, :]
df_201712.shape

# 업종별 점포 수 그래프 그리기
result = df_201712.groupby('상권업종대분류명')['상가업소번호'].count()
result
plt.figure(figsize=(10, 6))
fig = sns.barplot(data=result)
fig.set_ylabel('점포수')
fig.set_title('업종별 점포수')
plt.show()

# 구별 점포 수 그래프 그리기
result = df_201712.groupby('시군구명')['시군구명'].count()
result
plt.figure(figsize=(10, 6))
fig = sns.barplot(data=result)
fig.set_ylabel('점포수')
fig.set_xlabel('')
fig.set_title('구별 점포수')
fig.set_xticklabels(fig.get_xticklabels(), rotation=45)
plt.show()

# 지도의 중심점 구하기
center = [df_201712['위도'].mean(), df_201712['경도'].mean()]
center

# 구의 중심점 구하기
loc = df_201712.groupby('시군구명')[['위도', '경도']].mean()
loc

# 구의 점포 수 구하기
store = df_201712.groupby('시군구명')['시군구명'].count()
store
df_store = pd.concat([store, loc], axis=1)
df_store.columns = ['점포수', '위도', '경도']
df_store

# 점포 수를 원의 크기로 표시하기
map = folium.Map(location=center, zoom_start=11)  # 지도 가져오기

# 지도 위에 점포 수를 원의 크기로 표시하기
for i in range(len(df_store)):
    folium.CircleMarker(location=[df_store['위도'].iloc[i],
                                  df_store['경도'].iloc[i]],
                        radius=(df_store['점포수'].iloc[i]/1000)*3,  # 원의 반지름
                        color='red',  # 원의 색
                        stroke=False,  # 윤곽선 X
                        fill=True,  # 원의 내부 색
                        fill_opacity='30%'  # 원의 투명도
                        ).add_to(map)

# 지도에 구 이름 추가하기
html_start = html = '<div \
    style="\
        font-size: 12px;\
            color: blue;\
                background-color:rgba(255, 255, 255, 0.2);\
                    width:85px;\
                        text-align:left;\
                            margin:0px;\
                                "><b>'
html_end = '</b></div>'

for i in range(len(df_store)):
    folium.Marker(location=[df_store['위도'].iloc[i],
                            df_store['경도'].iloc[i]],
                  icon=folium.DivIcon(
        icon_anchor=(0, 0),  # 텍스트 위치 설정
        html=html_start+df_store.index[i]+html_end
    )).add_to(map)
dm.showMap(map)

# 점포 수가 많은 상위 10개 동 알아보기
store = df_201712.groupby('행정동명')['행정동명'].count()
store = store.sort_values(ascending=False).head(10)
store
plt.figure(figsize=(10, 6))
fig = sns.barplot(data=store)
fig.set_ylabel('점포수')
fig.set_xlabel('')
fig.set_title('점포수 많은 상위 10개동')
fig.set_xticklabels(fig.get_xticklabels(), rotation=45)
plt.subplots_adjust(bottom=0.2)
plt.show()
