# code14_1, code14_2에 이어서 실행  

# 업종별 (대분류) 점포 수 변화
store_change = df.groupby(['수집연월', '상권업종대분류명'])['행정동명'].count()
store_change = store_change.reset_index()
store_change.columns = ['수집연월', '상권업종대분류명', '점포수']
store_change

plt.figure(figsize=(10, 6))
sns.set_theme(style='darkgrid', font='Malgun Gothic')
fig = sns.lineplot(x='수집연월', y='점포수',
                   hue='상권업종대분류명', marker='o',
                   data=store_change)

fig.set_xticks(range(5))
fig.set_xticklabels(ym)
fig.set_title('업종별 점포수 변화 (대분류)')
plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0)
plt.subplots_adjust(right=0.75)
plt.show()

# 점포 수 변화가 큰 상위 10개 업종 (소분류)
store_change = pd.pivot_table(df,
                              index='상권업종소분류명',
                              columns='수집연월',
                              values='상가업소번호',
                              aggfunc='count'
                              )
store_change['diff'] = abs(store_change[4]-store_change[0])
store_change = store_change.sort_values('diff', ascending=False).head(10)
store_change  # 상위 10개 업종

top10 = store_change.reset_index().rename_axis(None, axis=1)
top10 = pd.melt(top10, id_vars=['상권업종소분류명'], value_vars=[0, 1, 2, 3, 4])
top10.columns = ['상권업종소분류명', '수집연월', '점포수']
top10

plt.figure(figsize=(10, 6))
sns.set_theme(style='darkgrid', font='Malgun Gothic')
fig = sns.lineplot(x='수집연월', y='점포수',
                   hue='상권업종소분류명', marker='o',
                   data=top10)

fig.set_xticks(range(5))
fig.set_xticklabels(ym)
fig.set_title('업종별 점포수 변화 (소분류)')
plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0)
plt.subplots_adjust(right=0.75)
plt.show()

# 구별 점포 수의 변화
store_change = df.groupby(['시군구명', '수집연월'])['상가업소번호'].count()
store_change = store_change.reset_index().rename_axis(None, axis=1)
store_change.columns = ['시군구명', '수집연월', '점포수']
store_change

plt.figure(figsize=(10, 6))
sns.set_theme(style='darkgrid', font='Malgun Gothic')
fig = sns.lineplot(x='수집연월', y='점포수',
                   hue='시군구명', marker='o',
                   data=store_change)

fig.set_xticks(range(5))
fig.set_xticklabels(ym)
fig.set_title('구별 점포수 변화')
plt.legend(bbox_to_anchor=(1.05, 1), loc=2, ncols=2, borderaxespad=0)
plt.subplots_adjust(right=0.7)
plt.show()

# 점포 수 변화가 큰 상위 10개 동 확인
store_change = pd.pivot_table(df,
                              index='행정동명',
                              columns='수집연월',
                              values='상가업소번호',
                              aggfunc='count'
                              )
store_change['diff'] = abs(store_change[4]-store_change[0])
store_change = store_change.sort_values('diff', ascending=False).head(10)
store_change

top10 = store_change.reset_index().rename_axis(None, axis=1)
top10 = pd.melt(top10, id_vars=['행정동명'], value_vars=[0, 1, 2, 3, 4])
top10.columns = ['행정동명', '수집연월', '점포수']
top10

plt.figure(figsize=(10, 6))
sns.set_theme(style='darkgrid', font='Malgun Gothic')
fig = sns.lineplot(x='수집연월', y='점포수',
                   hue='행정동명', marker='o',
                   data=top10)

fig.set_xticks(range(5))
fig.set_xticklabels(ym)
fig.set_title('점포수 변화가 많은 동 Top 10')
plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0)
plt.subplots_adjust(right=0.75)
plt.show()
