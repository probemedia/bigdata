import pandas as pd
import seaborn as sns
import folium

import os
os.chdir('D:/ds_study/Ch09/')    # displayMap.py 가 있는 폴더지정
import displayMap as dm
import matplotlib.pyplot as plt

plt.rcParams['font.family'] = 'Malgun Gothic'  # 한글 폰트 설정
plt.rcParams['axes.unicode_minus'] = False  # 마이너스 부호 깨짐 방지

ym = ["201512", "201606", "201612", "201706", "201712"]
df_list = []
ym = ["201512", "201606", "201612", "201706", "201712"]
df_list = []
for i in range(len(ym)):
    filename = "d:/data/seoul_" + ym[i] + ".csv"
    print("read ", filename, "...")  # 읽을 파일 이름 출력
    tmp = pd.read_csv(filename)  # csv 파일 읽기
    tmp['수집연월'] = i  # 수집 연월 추가
    df_list.append(tmp)
df = pd.concat(df_list, ignore_index=True)
df.head()
