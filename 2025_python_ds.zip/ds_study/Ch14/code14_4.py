# code14_1, code14_2, code14_3 에 이어서 실행 

# 역삼1동 상권 분석
df_sel = df.loc[(df.행정동명 == '역삼1동') & (df.수집연월 == 4), :]

dict_color = {'학문/교육': 'yellow', '소매': 'red',
              '생활서비스': 'green', '부동산': 'gray',
              '음식': 'blue', '관광/여가/오락': 'tomato',
              '의료': 'pink', '숙박': 'cyan',
              '스포츠': 'steelblue'}

#점포를 업종별(대분류)로 구분하여 지도에 표시하기
center = [df_sel['위도'].mean(), df_sel['경도'].mean()]

map = folium.Map(location=center, zoom_start=15)  # 지도 가져오기

for i in range(len(df_sel)):
    folium.CircleMarker(location=[df_sel['위도'].iloc[i],
                                  df_sel['경도'].iloc[i]],
                                  radius=4,  # 원의 반지름
                                  color=dict_color[df_sel['상권업종대분류명'].iloc[i]],  # 원의 색
                                  stroke=False,  # 윤곽선 X
                                  fill=True,  # 원의 색
                                  fill_opacity='90%'  # 원의 투명도
                                  ).add_to(map)
dm.showMap(map)

# 커피 점포만 지도에 표시하기
df_sel = df.loc[(df.행정동명 == '역삼1동') & (df.수집연월 == 4) &
                (df.상권업종소분류명 == '커피전문점/카페/다방'), :]

# 지도의 중심점 구하기
center = [df_sel['위도'].mean(), df_sel['경도'].mean()]

map = folium.Map(location=center, zoom_start=15)  # 지도 가져오기

for i in range(len(df_sel)):
    folium.CircleMarker(location=[df_sel['위도'].iloc[i],
                                df_sel['경도'].iloc[i]],
                        radius=4,  # 원의 반지름
                        color='red',  # 원의 색
                        stroke=False,  # 윤곽선 X
                        fill=True,  # 원의 내부 색
                        fill_opacity='90%'  # 원의 투명도
                        ).add_to(map)
dm.showMap(map)
