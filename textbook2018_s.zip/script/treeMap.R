
install.packages("treemap")
#install.packages("gtable")
#install.packages("munsell")
#install.packages("lazyeval")
#install.packages("tibble")
library(treemap)

#txt파일 로딩 : 2014구별소계인구수.txt
data <- read.table("data/2014구별소계인구수.txt",header=T)
data

#treemap(data-데이터프레임,index-군집지수,vSize-사각형의크기를 결정하는 필드명,
# type-사각형이 색칠해지는 방법을 결정, align.label-레이블 위치, title-타이틀)
treemap(data, index=c("자치구","인구"), vSize="인구", type="index", 
        align.labels=list(c("center", "center"),c("center", "bottom")),
        title="자치구별 인구수")

#txt파일 로딩 : 2009_2013년구매액.txt
data <- read.table("data/2009_2013년구매액.txt",header=T)
data


#treemap(data-데이터프레임,index-군집지수,vSize-사각형의크기를 결정하는 필드명,
# type-사각형이 색칠해지는 방법을 결정, align.label-레이블 위치, title-타이틀)
treemap(data, index=c("기준연월","금액합계"), vSize="금액합계", type="index", 
        align.labels=list(c("center", "center"),c("center", "bottom")),
        title="2009~2013년 구매금액")


data2 <- read.table("data/2016년서울시4분기구별인구수.txt",header=T)
data2
treemap(data2, index=c("자치구","인구수"), vSize="인구수", type="index", 
        align.labels=list(c("center", "center"),c("center", "bottom")),
        title="자치구별 인구수")

data21 <- read.table("data/2017년3분기_서울시구별인구수.txt",header=T)
data21
treemap(data21, index=c("자치구","인구수"), vSize="인구수", type="index", 
        align.labels=list(c("center", "center"),c("center", "bottom")),
        title="자치구별 인구수")

data3 <- read.table("data/20170328_유형별해양사고현황2002-2012.txt",header=T)
data3
treemap(data3, index=c("사고종류","건수"), vSize="건수", type="index", 
        align.labels=list(c("center", "center"),c("center", "bottom")),
        title="2012년 유형별 해양사고건수")

data4 <- read.csv("data/2014년_범죄건수별현황.csv")
data4
treemap(data4, index=c("범죄분류","계"), vSize="계", type="index", 
        align.labels=list(c("center", "center"),c("center", "bottom")),
        title="2014년 범죄분류별 건수")

data41 <- read.csv("data/20180204_2016년_범죄종류별_범죄건수.csv")
data41

treemap(data41, index=c("범죄중분류","범죄건수"), vSize="범죄건수", type="index", 
        align.labels=list(c("center", "center"),c("center", "bottom")),
        title="2016년 범죄분류별 건수")

data42 <- read.csv("data/20180204_2016년_구리시_범죄종류별_범죄건수.csv")
data42

treemap(data42, index=c("범죄중분류","범죄건수"), vSize="범죄건수", type="index", 
        align.labels=list(c("center", "center"),c("center", "bottom")),
        title="2016년 구리시 범죄분류별 건수")


data5 <- read.table("data/20170505_안양시2015년4사분기동별인구수.txt",header=T)
data5
treemap(data5, index=c("동명","인구수"), vSize="인구수", type="index", 
        align.labels=list(c("center", "center"),c("center", "bottom")),
        title="안양시2015년4사분기동별인구수")