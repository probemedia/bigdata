#twitteR, ROAuth패키지를 사용한 검색 데이터 수집
install.packages("twitteR") 
install.packages("ROAuth")

library(twitteR)
library(RColorBrewer)
library(ROAuth)
require(RCurl)

url_rqst <- "https://api.twitter.com/oauth/request_token"
url_acc <- "https://api.twitter.com/oauth/access_token"
url_auth <- "https://api.twitter.com/oauth/authorize"

API_key <- "your API_key"
API_secret <- "your API_secret"

twitCred <- OAuthFactory$new(consumerKey=API_key, 
                             consumerSecret=API_secret,
                             requestURL=url_rqst, 
                             accessURL=url_acc,
                             authURL=url_auth)
download.file(url="http://curl.haxx.se/ca/cacert.pem",destfile = "cacert.pem")

twitCred$handshake(cainfo="cacert.pem")

save(list="twitCred", file = "twitter_credentials")
#registerTwitterOAuth(twitCred)

Access_token <- "your Access_token"
Access_token_secret <-"your Access_token_secret"

setup_twitter_oauth(API_key,API_secret,Access_token,Access_token_secret)

iPhone6_tweets<-searchTwitter("iphone6 lang:en", n=500)
head(iPhone6_tweets)
length(iPhone6_tweets)

#Fix OAuth authentication error - 64bit추가

install.packages("base64enc")
library(base64enc)
library(httr)

# 1. Find OAuth settings for twitter:
#    https://dev.twitter.com/docs/auth/oauth
oauth_endpoints("twitter")

# 2. Register an application at https://apps.twitter.com/
#    Make sure to set callback url to "http://127.0.0.1:1410"
#
#    Replace key and secret below
API_key <- "your API_key"
API_secret <- "your API_secret"
myapp <- oauth_app("twitter",
                   key = API_key,
                   secret = API_secret
)

# 3. Get OAuth credentials
twitter_token <- oauth1.0_token(oauth_endpoints("twitter"), myapp)

# 4. Use API
req <- GET("https://api.twitter.com/1.1/statuses/home_timeline.json",
           config(token = twitter_token))
stop_for_status(req)
content(req)



#read.table()을 사용한 웹 데이터파일(정형데이터) 읽기
oildata <- read.table("http://people.stat.sc.edu/habing/courses/data/oildata.txt", header = TRUE)
oildata
#oildata 파일로 저장 :  정형데이터 txt파일로 저장
write.table(oildata,"c:/project/textbook_s/data/oildata.txt", quote = FALSE, append = FALSE)


#XML패키지를 사용한  데이터 수집
# http://www.columbia.edu/~cjd11/charles_dimaggio/DIRE/styled-4/styled-6/code-13/
#Web Scraping
install.packages("XML")
install.packages("RCurl")
library(XML)
library(RCurl)

srts<-htmlParse("http://apps.saferoutesinfo.org/legislation_funding/state_apportionment.cfm")
class(srts)

srts.table<- readHTMLTable(srts,stringsAsFactors = FALSE)

money <- sapply(srts.table[[1]][,-1], FUN= function(x) 
  as.character(gsub(",", "", as.character(x), fixed = TRUE) ))
money<-as.data.frame(substring(money,2), stringsAsFactors=FALSE)

names(money)<-c("Actual.05","Actual.06","Actual.07","Actual.08",
                "Actual.09","Actual.10","Actual.11", "Actual.12", "total")
money$state<-srts.table[[1]][,1]
money<-money[,c(10,1:9)]
money

top5<-money[rev(order(as.numeric(money$total))),]
top5[2:6, c(1,10)]

plot(money$total[1:51], type="h")

