#d3Chart
install.packages("devtools")
#windows의 경우 Rtools34.exe 필요시 자동 설치
library(devtools)

install_github("rCharts", "ramnathv")
library(rCharts)

names(iris) = gsub("\\.","",names(iris))
rPlot(PetalLength ~ PetalWidth | Species, data = iris, color = "Species", type="point")


#map
map3 <- Leaflet$new()
map3$setView(c(37.482078, 127.017892), zoom=14)
map3$marker(c(37.479567, 127.019174), bindPopup="<p>A</p>")
map3$marker(c(37.484973, 127.016181), bindPopup="<p>B</p>")
map3

#d3Network
#CRAN에 등록되지 않은 패키지 설치
#install_github("christophergandrud/d3Network")

install.packages("d3Network")
install.packages("RCurl")
library(RCurl)
library(d3Network)

ericOpenHtml <- function(filename){
  if(Sys.info()["sysname"]=="windows"){
    shell.exec(filename)
  }else{
    system(paste("open",filename))
  }
}

Source <- c("A","A","A","A","B","B","C","C","D")
Target <- c("B","C","D","J","E","F","G","H","I")
NetworkData <- data.frame(Source, Target)

d3SimpleNetwork(NetworkData, width=400, height = 250, file="html/test2.html")
#ericOpenHtml("test.html")

##Energy Flow
url <- "https://raw.githubusercontent.com/christophergandrud/d3Network/sankey/JSONdata/energy.json"
energy <- getURL(url, .opts = list(ssl.verifypeer = FALSE))

#convert to dataframe
engLinks <- JSONtoDF(jsonStr = energy, array = "links")
engNodes <- JSONtoDF(jsonStr = energy, array = "nodes")

#plot
d3Sankey(Links = engLinks, Nodes = engNodes, Source = "source", Target = "target", Value = "value", NodeID = "name",
         fontsize = 12, nodeWidth = 30, file = "html/TestSankey.html")


#메르스전염현황
v1 <- read.csv("data/메르스전염현황.csv")
d3SimpleNetwork(v1, width = 800, height = 800, file="html/test.html")

#Komaps패키지 - 한국한국행정지도 파일을 R에서 사용
#http://web-r.org/webrboard/6477  참고 
# CRAN에 등록되어 있지 않음.  github에 있는 패키지 설치
#선수작업 : install.packages("devtools")
#devtools::install_github("cardiomoon/Kormaps2014")
devtools::install_github("cardiomoon/Kormaps")
library(Kormaps)
library(tmap)

qtm(kormap1) #시/도 경계지도
qtm(kormap2) #시/군/구 경계지도
qtm(kormap3) #읍/면/동 경계지도

#korpopmap1 #인구정보 
names(korpopmap1) #한글깨짐 
Encoding(names(korpopmap1))<-"UTF-8" # 한글인코딩 UTF-8로 지정 
names(korpopmap1) #한글 안 깨짐 

#총인구에 의한 시/도 단계구분도 
qtm(korpopmap1,"총인구_명")+tm_layout(fontfamily="AppleGothic")

#korpopmap2 #인구정보 
names(korpopmap2) #한글깨짐 
Encoding(names(korpopmap2))<-"UTF-8" # 한글인코딩 UTF-8로 지정
names(korpopmap2) #한글 안 깨짐 

#총인구에 의한 시/군/구 단계구분도 
qtm(korpopmap2,"총인구_명")+tm_layout(fontfamily="AppleGothic")

#korpopmap3 #인구정보 
names(korpopmap3) #한글깨짐 
Encoding(names(korpopmap3))<-"UTF-8" # 한글인코딩 UTF-8로 지정
names(korpopmap3) #한글 안 깨짐 

#총인구에 의한 읍/면/동 단계구분도 
qtm(korpopmap3,"총인구_명")+tm_layout(fontfamily="AppleGothic")

#
ecode.kor <- korpopmap2
Encoding(ecode.kor$name)<-"UTF-8"
ecode.kor$name
Encoding(ecode.kor$행정구역별_읍면동)<-"UTF-8"
ecode.kor$행정구역별_읍면동

#Seoul2=submap(ecode.kor,"서울")
#qtm(Seoul2,"외국인_계_명")+tm_layout(fontfamily="AppleGothic")

ecode.kor3 <- korpopmap3
head(ecode.kor3)
Encoding(ecode.kor3$name)<-"UTF-8"
ecode.kor3$name
Encoding(ecode.kor3$행정구역별_읍면동)<-"UTF-8"
ecode.kor3$행정구역별_읍면동
head(ecode.kor3)
#

#seoul3=submap(ecode.kor3,"서울")
#qtm(seoul3,"외국인_계_명")+tm_layout(fontfamily="AppleGothic")


#행정지도 시각화
#https://encaion.wordpress.com/2016/03/13/korea_map_vis_1/ 참고 
#install.packages("패키지명")
library(ggplot2)
library(ggmap)
library(sp)
library(maptools)

#2013년 행정구역 지도 사용 - 시도구역 지도 
korea_map_shp = readShapePoly("maps/2013_si_do.shp") #2013년 시도구역지도 
korea_map = fortify(korea_map_shp)
head(korea_map)

ggplot(data = korea_map, aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", colour = "#000000")

ggplot(data = korea_map, aes(x = long, y = lat, group = group, colour = id)) + 
  geom_polygon(fill = "#FFFFFF")

data_slot = korea_map_shp@data
data_slot
cbind( id = row.names(data_slot), kor_names = as.character(data_slot$name))
#korea_map$id : "0" - 제주도, "9"- 세종시  16"-서울시
ggplot(data = korea_map, aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", colour = "#000000") + 
  geom_polygon(data = korea_map[ korea_map$id == "0", ],
               aes(x = long, y = lat, group = group),
               fill = "#FFFFFF", colour = "#FF0000")

ggplot(data = korea_map, aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", colour = "#000000") + 
  geom_polygon(data = korea_map[ korea_map$id == "9", ],
               aes(x = long, y = lat, group = group),
               fill = "#FFFFFF", colour = "#FF0000")

#2017년 행정구역 지도 사용  - 시도구역 지도 
korea_map_shp = readShapePoly("maps/01_sido_201703/TL_SCCO_CTPRVN.shp")#2017년3월 시도구역지도 
korea_map = fortify(korea_map_shp)
head(korea_map)

ggplot(data = korea_map, aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", colour = "#000000")

ggplot(data = korea_map, aes(x = long, y = lat, group = group, colour = id)) + 
  geom_polygon(fill = "#FFFFFF")

data_slot = korea_map_shp@data
data_slot
cbind( id = row.names(data_slot), kor_names = as.character(data_slot$CTP_KOR_NM))

#korea_map$id : "0" - 서울시, "7"- 세종시  16"-제주도
ggplot(data = korea_map, aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", colour = "#000000") + 
  geom_polygon(data = korea_map[ korea_map$id == "0", ],
               aes(x = long, y = lat, group = group),
               fill = "#FFFFFF", colour = "#FF0000")

ggplot(data = korea_map, aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", colour = "#000000") + 
  geom_polygon(data = korea_map[ korea_map$id == "7", ],
               aes(x = long, y = lat, group = group),
               fill = "#FFFFFF", colour = "#FF0000")

#2017년 행정구역 지도 사용  - 시군구 구역 지도 
korea_map_shp2 = readShapePoly("maps/02_sigungu_201703/TL_SCCO_SIG.shp")#2017년3월 시도구역지도 
korea_map2 = fortify(korea_map_shp2)
head(korea_map2)

ggplot(data = korea_map2, aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", colour = "#000000")

ggplot(data = korea_map2, aes(x = long, y = lat, group = group, colour = id)) + 
  geom_polygon(fill = "#FFFFFF")

data_slot = korea_map_shp2@data
data_slot
cbind( id = row.names(data_slot), kor_names = as.character(data_slot$CTP_KOR_NM))

#korea_map$id : "94" - 과천시, "74"- 세종시
ggplot(data = korea_map, aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", colour = "#000000") + 
  geom_polygon(data = korea_map[ korea_map$id == "94", ],
               aes(x = long, y = lat, group = group),
               fill = "#FFFFFF", colour = "#FF0000")

ggplot(data = korea_map, aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", colour = "#000000") + 
  geom_polygon(data = korea_map[ korea_map$id == "74", ],
               aes(x = long, y = lat, group = group),
               fill = "#FFFFFF", colour = "#FF0000")

#서울시 행정구역 시군구 정보 
seoul_map_shp = readShapePoly("maps/2014_seoul/2014_seoul_TL_SCCO_SIG_W.shp")
seoul_map = fortify(seoul_map_shp)
head(seoul_map)

#지도 경계선 표시
ggplot(data = seoul_map, aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", colour = "#000000")

#지도에 구명 추가 표시
data_seoul <- read.csv("data/20171111_서울시_행정구역_시군구 정보.csv")
head(data_seoul)

maps_seoul <- ggplot(data = seoul_map, aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", colour = "#000000")
maps_seoul + geom_text(data=data_seoul, aes(x = 경도, y = 위도, group = 순번, label=시군구명K))


