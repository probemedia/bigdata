#패키지 설치
source("http://bioconductor.org/biocLite.R")

biocLite()

biocLite("EBImage")

install.packages("brew")

install.packages("tiff", type="source")
install.packages("lattice")
library(EBImage)

Image <- readImage("figure/t.jpg")
display(Image)

Image #이미지의 정보표시

#이미지 밝기 +로 조절
Image1 <- Image + 0.2 #밝게
display(Image1)

Image2 <- Image - 0.2 #어둡게
display(Image2)

#이미지 명암 *로 조절
Image3 <- Image * 0.5 
display(Image3)

Image4 <- Image * 2
display(Image4)

#이미지 감마 ^로 조절
Image5 <- Image ^ 2 
display(Image5)

Image6 <- Image ^ 0.7
display(Image6)

#이미지 자르기
display(Image[200:500, 300:600,])

#이미지 회전
Imagetr <- translate(rotate(Image,45),c(50,0))
display(Imagetr)

#이미지 윤곽선 표시
fHigh <-matrix(1, nc=3, nr=3)
fHigh[2,2] <- -8
Image.fHigh <- filter2(Image, fHigh)
imageCluster = bwlabel(Image.fHigh)
cat("Number of Object=", max(imageCluster),"\n")

medFltr <- medianFilter(Image, 1.1)
display(medFltr)


