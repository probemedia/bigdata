install.packages("googleVis")
library(googleVis)

line <- read.csv("data/1-4호선승하차승객수.csv",header=T,sep=",")
line

t1 <- gvisMotionChart(line, idvar="line_no", timevar = "time",
                       options = list(width=1000, height=500))
plot(t1)