##A에서 B로 이동하는데 소요되는 비용 최소화

install.packages("lpSolve")
library(lpSolve)

#각 지점에 비용할당
costs <- matrix(10000,8,5) #초깃값
costs

costs[4,1] <- 0
costs

costs[-4,5] <- 0 #4행을 제외한 5열의 값을 0으로
costs

costs[1,2] <- costs[2,3] <- costs[3,4] <- 7
costs[1,3] <- costs[2,4] <- 7.7
costs[5,1] <- costs[7,3] <- costs[3,4] <- 8
costs[1,4] <- 8.4
costs[6,2] <- 9
costs[8,4] <- 10
costs[4,2:4] <- c(0.7,1.4,2.1)
costs

#제약값 할당
row.signs <- rep("<",8)
row.rhs <- c(200,300,350,200,100,50,100,150) #row에 할당할 수 있는 최댓값
col.signs <- rep(">",5)
col.rhs <- c(250,100,400,500,200)

#최소비용 산출
lp.transport(costs, "min", row.signs, row.rhs, col.signs, col.rhs)

lp.transport(costs, "min", row.signs, row.rhs, col.signs, col.rhs)$solution

## traveling salesman problem: 시작위치에서 주어진 위치를 모두 한번만 방문하고 시작위치로 되돌아 오기
install.packages("TSP")
library(TSP)

data("USCA50")
USCA50

methods <- c("nearest_insertion", "farthest_insertion", "arbitrary_insertion", "nn", "repetitive_nn", "2-opt")
tours <- sapply(methods, FUN = function(m) solve_TSP(USCA50, method = m), simplify = FALSE)

tours[1] #50개도시의 여행 최단 거리

dotchart(c(sapply(tours, FUN = attr, "tour_length"), optimal = 14497), xlab="tour length",xlim = c(0,20000))

#
data("USCA312")
tsp <- insert_dummy(USCA312, label = "cut")
tsp

tour <- solve_TSP(tsp, method="farthest_insertion")
tour

path <- cut_tour(tour, "cut")
head(labels(path))
tail(labels(path))

install.packages("maps")
install.packages("sp")
install.packages("maptools")

library(maps)#지리학적인 지도를 그림 
library(sp) #2D, 3D공간데이터 처리 
library(maptools) #공간 객체를 읽고 처리 
data("USCA312_map")

plot_path <- function(path){
  plot(as(USCA312_coords,"Spatial"), axes = TRUE)
  plot(USCA312_basemap, add = TRUE, col = "gray")

  points(USCA312_coords, pch = 3, cex = 0.4, col = "red")
  path_line <- SpatialLines(list(Lines(list(Line(USCA312_coords[path,])), ID="1")))
  plot(path_line, add = TRUE, col ="black") + points(USCA312_coords[c(head(path,1),tail(path,1)),], pch = 19, col="black")
}

plot_path(path)

