#396
mat1 <- matrix(c(1,2,3,4,5,6), nrow = 2, byrow = T)
mat1
a <- c(1)
sweep(mat1,1,a)
sweep(mat1,1,a,'-')
sweep(mat1,1,a,'+')

length(Fruits)

ceiling(4.1)
floor(4.1)

#function




#402
sort1 <- Fruits$Sales
sort1
sort(sort1)