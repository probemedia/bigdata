##Energy Flow
install.packages("XML")
install.packages("RCurl")
#install.packages("devtools")
#library(devtools)#먼저 로드해야 install.packages("d3Network")실행됨  
install.packages("d3Network")

library(XML)
library(RCurl)
#install_github("christophergandrud/d3Network")
library(d3Network)

url <- "https://raw.githubusercontent.com/christophergandrud/d3Network/sankey/JSONdata/energy.json"
energy <- getURL(url, .opts = list(ssl.verifypeer = FALSE))

#convert to dataframe
engLinks <- JSONtoDF(jsonStr = energy, array = "links")
engNodes <- JSONtoDF(jsonStr = energy, array = "nodes")

#plot
d3Sankey(Links = engLinks, Nodes = engNodes, Source = "source", Target = "target", Value = "value", NodeID = "name",
         fontsize = 12, nodeWidth = 30, file = "figure/TestSankey.html")
#ericOpenHtml("TestSankey.html")