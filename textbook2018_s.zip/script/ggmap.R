install.packages("ggmap") #구글맵 설치 
install.packages("stringr") #문자열 처리 설치 

#필요시 사용 
#install.packages("gtable")
#install.packages("munsell")
#install.packages("lazyeval")
#install.packages("tibble")

#라이브러리 로드 
library(ggmap)
library(stringr)

#데이터의 공백제거, 필드명의 ()제거등의 처리 작업 필요 
data <- read.csv("data/서초구 공공와이파이 위치정보.csv",head=T, sep=",")
head(data)

#data에서 필요한 필드만 추출 
#서초구 공공와이파이 위치정보에서 "지역명","설치위치.X좌표","설치위치.Y좌표","설치기관.회사" 만 추출
wifi_data <- data[,c(3,4,5,6)]
head(wifi_data)
colnames(wifi_data)

#서초구 공공 와이파이 위치를 지도에 표시
#get_map() : 구글지도 불러오기, ggmap() : 지도에 공간 데이터 표시, 
#geom_point(x,y):주어진 x,y좌표 공간데이터를 점으로 지도에 표시 
#주의: x=경도값, y=위도값
wpos <- get_map("Seocho-gu", zoom = 13, maptype = "roadmap")
wpos.map <- ggmap(wpos) + geom_point(data=wifi_data, aes(x=lon,y=lat),size=2,color="red")
wpos.map

##여기서 부터 참고:네이버맵 사용예시. 
#중요- 문제: 현재 ggmap의 api와 네이버의 static map의 api가 맞지 않음. 
#cent  <- c(mean(wifi_data[2],wifi_data[3]))
cent  <- c(lon=127.0021826,lat=37.4760208)
#use naver map , 서초구청: c(lon=127.0021826,lat=37.4760208)
wpos <- get_navermap(center = cent, baselayer="default", zoom = 13,  
                     overlayers = c("roadview"), marker = data.frame(cent[1], cent[2]),
                     key="c75a09166a38196955adee04d3a51bf8", uri="www.r-project.org",extent = "device",
                     base_layer = ggplot(wifi_data, aes(x=설치위치.X좌표,y=설치위치.Y좌표)))
wpos.map <- ggmap(wpos)
wpos.map + geom_point(data=wifi_data, aes(x=lon,y=lat),size=2,color="red")
wpos.map
##여기까지 참고 

#설치회사별로 구분 
wpos.map <- ggmap(wpos) + geom_point(data=wifi_data, aes(x=lon,y=lat,colour=설치기관.회사),size=2)
wpos.map

#서초1동으로 좌표의 중심위치 변경 후 지도에 와이파이 위치와 지역명 표시
#geom_tex(): 지도에 지정한 위치에 텍스트 추가 
wpos2 <- get_map(location = c(lon = 126.9993459, lat = 37.4886858), zoom = 15, maptype = "roadmap")
wpos2.map <- ggmap(wpos2) + geom_point(data=wifi_data, aes(x=lon,y=lat),size=2,color="red")
wpos2.map + geom_text(data=wifi_data,aes(x=lon,y=lat,label=지역명),size=2)

#데이터의 공백제거, 필드명의 ()제거등의 처리 작업 필요 
#마포구 방범용 CCTV 위치 정보 파일
data <- read.csv("data/서울특별시+마포구_CCTV_20160524.csv")
head(data)

#소재지지번주소, 설치목적구분, 위도, 경도 
wifi_data <- data[,c(3,4,11,12)]
head(wifi_data)
colnames(wifi_data)

#마포구 방범용 CCTV 위치를 지도에 표시
#get_map() : 구글지도 불러오기, ggmap() : 지도에 공간 데이터 표시, 
#geom_point(x,y):주어진 x,y좌표 공간데이터를 점으로 지도에 표시 
wpos <- get_map("Mapo-gu", zoom = 13, maptype = "roadmap")
wpos.map <- ggmap(wpos) + geom_point(data=wifi_data, aes(x=경도,y=위도),size=2,color="red")
wpos.map

#마포1동으로 좌표의 중심위치 변경 
wpos2 <- get_map("Mapo 1(il)-dong", zoom = 16, maptype = "roadmap")
wpos2.map <- ggmap(wpos2) + geom_point(data=wifi_data, aes(x=경도,y=위도),size=2,color="red")
wpos2.map


#데이터의 공백제거, 필드명의 ()제거등의 처리 작업 필요 
#해수욕장정보목록 위치 정보 파일
data <- read.csv("data/20170328_해수욕장정보목록_2014년10월2.csv")
head(data)

#고유번호,해수욕장명칭,경도,위도 
b_data <- data[,c(1,4,5,6)]
head(b_data)
colnames(b_data)

#전국 해수욕장 위치를 지도에 표시
#get_map() : 구글지도 불러오기, ggmap() : 지도에 공간 데이터 표시, 
#geom_point(x,y):주어진 x,y좌표 공간데이터를 점으로 지도에 표시 
#주의: 위치정보에서 경도값이 x좌표임.
wpos <- get_map("Daejeon", zoom = 6, maptype = "roadmap")
wpos.map <- ggmap(wpos) + geom_point(data=b_data, aes(x=경도,y=위도),size=1,color="red")
wpos.map

#부산으로 좌표의 중심위치 변경 
wpos2 <- get_map("Busan", zoom = 10, maptype = "roadmap")
wpos2.map <- ggmap(wpos2) + geom_point(data=b_data, aes(x=경도,y=위도),size=2,color="red")
wpos2.map + geom_text(data=b_data,aes(x=경도,y=위도,label=해수욕장명칭),size=2)

#해양수산부 인재개발원으로 좌표의 중심위치 변경 
wpos2 <- get_map(location = c(lon = 129.2209665, lat = 35.1922824), zoom = 13, maptype = "roadmap")
wpos2.map <- ggmap(wpos2) + geom_point(data=b_data, aes(x=경도,y=위도),size=2,color="red")
wpos2.map + geom_text(data=b_data,aes(x=경도,y=위도,label=해수욕장명칭),size=2,color="red")



#안양시_CCTV_현황_20170327 위치 정보 파일
data <- read.csv("data/20170505_안양시_CCTV_현황_20170327.csv")
head(data)

#도로명주소,관리기관전화번호, 위도, 경도 
b_data <- data[,c(2,7,8,9)]
head(b_data)
colnames(b_data)

#안양시_CCTV 위치를 지도에 표시
#get_map() : 구글지도 불러오기, ggmap() : 지도에 공간 데이터 표시, 
#geom_point(x,y):주어진 x,y좌표 공간데이터를 점으로 지도에 표시 
#주의: 위치정보에서 경도값이 x좌표임.
wpos <- get_map("Anyang-si", zoom = 13, maptype = "roadmap")
wpos.map <- ggmap(wpos) + geom_point(data=b_data, aes(x=경도,y=위도),size=1,color="red")
wpos.map

#동안구로 좌표의 중심위치 변경 
wpos2 <- get_map("Dongan-gu", zoom = 15, maptype = "roadmap")
wpos2.map <- ggmap(wpos2) + geom_point(data=b_data, aes(x=경도,y=위도),size=2,color="red")
wpos2.map

#만안구청을 좌표의 중심위치 변경 
wpos2 <- get_map(location = c(lon = 126.9303382, lat = 37.3865929), zoom = 17, maptype = "roadmap")
wpos2.map <- ggmap(wpos2) + geom_point(data=b_data, aes(x=경도,y=위도),size=2,color="red")
wpos2.map

#경기도+과천시_자전거대여소_20170401 위치 정보 파일
data <- read.csv("data/경기도+과천시_자전거대여소_20170401.csv")
head(data)

#자전거대여소명, 위도, 경도, 운영시작시각, 운영종료시각, "휴무일" 
b_data <- data[,c(1,5,6,7,8,9)]
head(b_data)
colnames(b_data)

#정부과천청사역을 좌표의 중심위치 변경 
wpos2 <- get_map(location = c(lon = 126.9876083, lat = 37.426449), zoom = 15, maptype = "roadmap")
wpos2.map <- ggmap(wpos2) + geom_point(data=b_data, aes(x=경도,y=위도),size=2,color="red")
wpos2.map + geom_text(data=b_data,aes(x=경도,y=위도,label=자전거대여소명),size=3,color="red")

#20180128_경기도_구리시_CCTV_20171130.csv 위치 정보 파일
data <- read.csv("data/20180128_경기도_구리시_CCTV_20171130.csv")
head(data)

#도로주소명, 설치목적, 위도, 경도 
b_data <- data[,c(2,4,11,12)]
head(b_data)
colnames(b_data)

#구리시청을 좌표의 중심위치 변경 
wpos2 <- get_map(location = c(lon = 127.1273764, lat = 37.5943119), zoom = 13, maptype = "roadmap")
wpos2.map <- ggmap(wpos2) + geom_point(data=b_data, aes(x=경도,y=위도),size=2,color="red")
wpos2.map

wpos2 <- get_map(location = c(lon = 127.1273764, lat = 37.5943119), zoom = 16, maptype = "roadmap")
wpos2.map <- ggmap(wpos2) + geom_point(data=b_data, aes(x=경도,y=위도),size=2,color="red")
wpos2.map

#20180128_경기도_구리시_무료와이파이_20171130.csv
data <- read.csv("data/20180128_경기도_구리시_무료와이파이_20171130.csv")
head(data)

#설치장소명, 설치시설구분, 위도, 경도 
b_data <- data[,c(1,5,13,14)]
head(b_data)
colnames(b_data)

#구리시청을 좌표의 중심위치 변경 
wpos2 <- get_map(location = c(lon = 127.1273764, lat = 37.5943119), zoom = 14, maptype = "roadmap")
wpos2.map <- ggmap(wpos2) + geom_point(data=b_data, aes(x=경도,y=위도),size=2,color="red")
wpos2.map
