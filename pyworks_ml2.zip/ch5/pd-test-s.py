import pandas as pd, numpy as np
s = pd.Series([1.0, 3.0, 5.0, 7.0, 9.0])
print(s)