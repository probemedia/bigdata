# -*- coding: utf-8 -*-
import numpy as np
import scipy as sp
import pandas as pd

# %%
print("Hello World!")
# %%
'''3.3.3'''

SALARY_RISE_FACTOR = 0.05
STATE_CODE_MAP = {'WA': 'Wasington', 'TX': 'Texas'}


def update_employee_record(rec):
    old_sal = rec['salary']
    new_sal = old_sal * (1 + SALARY_RISE_FACTOR)
    rec['salary'] = new_sal
    state_code = rec['state_code']
    rec['state_name'] = STATE_CODE_MAP[state_code]


input_data = [
        {'employee_name': 'Susan', 'salary': 100000.0, 'state_code': 'WA'},
        {'employee_name': 'Ellen', 'salary': 75000.0, 'state_code': 'TX'}]

for rec in input_data:
    update_employee_record(rec)
    name = rec['employee_name']
    salary = rec['salary']
    state = rec['state_code']
    print(name + ' now lives in ' + state)
    print(' and makes $ ' + str(salary))

# %%
'''3.3.4'''
my_integer = 2
my_float = 2.0
my_true_bool = True

# %%
'''3.4'''
a_string = "Hello"
same_as_previous = 'Hello'
an_empty_string = ""
w_a_single_quote = "Hello's"

multi_line_string = """line 1
line 2"""

"ABCD"[0]
"ABCD"[0:2]
"ABCD"[1:3]
"ABCD"[1:]
"ABCD"[:-1]

'''3.4.1'''
# 이 줄 전체가 주석입니다.
a = 5  # 이렇게하면 #뒤에 나오는 부분이 주석입니다.


def sqr1(x):
    "입력받은 값을 제곱합니다."
    return x * x


'''3.4.2'''
my_list = ["a ", "b ", "c "]
my_set = set(my_list)
my_tuple = tuple(my_list)

'''3.4.3'''
my_list = ["a", "b", "c"]
print(my_list[0])
my_list[0] = "A"
my_list.append("d")

mixed_list = ["A", 5.7, "B", [1, 2, 3]]

original_list = [1, 2, 3, 4, 5, 6, 7, 8]
squares = [x*x for x in original_list]
squares_of_evens = [x*x for x in original_list if x % 2 == 0]

my_list = ["a", "b", "c"]
first_two_elements = my_list[0:3]
first_two_elements = my_list[:3]
last_two_elements = my_list[1:]
all_but_last_elements = my_list[:-1]

'''3.4.4'''
"ABC DEF".split()
"ABC \tDEF".split()
"ABC \tDEF".split(' ')
"ABCABD".split("AB")
",".join(["A", "B", "C"])

start, end, count_by = 1, 7, 2
"ABCDEFG"[start: end: count_by]

'''3.4.5'''
my_tuple = (1, 2, "Hello World")
print(my_tuple[0])
my_tuple[1] = 5  # 에러남
my_tuple = (1, 2)
zeroth_field, first_field = my_tuple

'''3.4.6'''
my_dict = {"January": 1, "Fabruary": 2}
print(my_dict["January"])
my_dict["March"] = 3
my_dict["January"] = "State of the year"

paris = [("one", 1), ("two", 2)]
as_dict = dict(paris)
same_as_paris = as_dict.items()

'''3.4.7'''
s = set()
5 in s
s.add(5)
5 in s
# %%
'''3.5'''


def my_function(x):
    # y = x + 1  # not used
    x_sqrd = x * x
    return x_sqrd


five_plus_one_sqrd = my_function(5)

''' '''


def raise_fx(x, n=2):
    return pow(x, n)


two_sqrd = raise_fx(2)
two_cubed = raise_fx(2, n=3)


'''3.5 lambda'''
sqr = (lambda x: x * x)
five_sqrd = sqr(5)


def apply_to_evens(a_list, a_func):
    return [a_func(x) for x in a_list if x % 2 == 0]


my_list = [1, 2, 3, 4, 5]
sqrs_of_evens = apply_to_evens(my_list, lambda x: x * x)


'''3.5.1'''
my_list = [1, 2, 3]
for x in my_list:
    print("the number is ", x)

my_dict = {"January": 1, "Fabruary": 2}
for key, value in my_dict.items():
    print("the value for ", key, " is ", value)

i = 4
if i < 3:
    print("i은(는) 3보다 작다")
elif i < 5:
    print("i은(는) 3과 5사이의 값이다")
else:
    print("i은(는) 5보다 크다")

'''3.5.3'''
with open('Khalani.txt', 'r') as f:
    input_text = f.read()
    try:
        lines = input_text.split("\n")
        print("열 번째 줄 : ", lines[9])
    except IndexError:
        print("열 번째 줄이 없음")


''' 3.5.4
import 라이브러리명
라이브러리명.객체명
--> 객체명 : 함수명, 클래스명

import 라이브러리명 as 약어
약어.객체명

from 라이브러리명 import 객체명
객체명
'''

'''3.5.5'''


class Dog:
    def __init__(self, name):
        self.name = name

    def response_to_command(self, command):
        if command == self.name:
            self.speak()

    def speak(self):
        print('멍멍!!!')


fido = Dog("봉구")
fido.response_to_command("야옹이")
fido.response_to_command("봉구")

'''3.5.6'''
a = 5
b = a
a = a + 1
print(b)

a_list = []
b_list = a_list
a_list.append(5)
b_list

# %%
'''3.6'''
'''3.6.1'''
# import pandas as pd

df = pd.DataFrame({
        "name": ["Bob", "Alex", "Janice"],
        "age": [60, 25, 33]
        })

other_df = pd.read_csv("ozone_data.csv", encoding='cp949')

df["age_plus_one"] = df["age"] + 1
df["age_time_two"] = 2 * df["age"]
df["age_squared"] = df["age"] * df["age"]
df["over_30"] = (df["age"] > 30)

total_age = df["age"].sum()
median_age = df["age"].quantile(0.5)

df_below50 = df[df["age"] < 50]

df["age_squared"] = df["age"].apply(lambda x: x * x)


df = pd.DataFrame({
        "name": ["Bob", "Alex", "Janice"],
        "age": [60, 25, 33]
        })
print(df.index)

df_w_name_as_ind = df.set_index("name")
print(df_w_name_as_ind.index)

bobs_row = df_w_name_as_ind.loc["Bob"]
print(bobs_row["age"])

'''3.6.2'''
s = pd.Series([1, 2, 3])
s
s + 2
s.index
s + pd.Series([4, 4, 5])

bobs_row = df_w_name_as_ind.loc["Bob"]
type(bobs_row)
bobs_row

'''3.6.3'''
df_w_age = pd.DataFrame({
        "name": ["Tom", "Tyrell", "Claire"],
        "age": [60, 25, 33]
        })

df_w_height = pd.DataFrame({
        "name": ["Tom", "Tyrell", "Claire"],
        "height": [6.2, 4.0, 5.5]
        })
joined = df_w_age.set_index("name").join(
        df_w_height.set_index("name"))
print(joined)
print(joined.reset_index())

df = pd.DataFrame({
        "name": ["Tom", "Tyrell", "Claire"],
        "age": [60, 25, 33],
        "height": [6.2, 4.0, 5.5],
        "gender": ["M", "M", "F"]
        })

print(df.groupby("gender").mean())

medians = df.groupby("gender").quantile(0.5)


def agg(ddf):
    return pd.Series({
            "name": max(ddf["name"]),
            "oldest": max(ddf["age"]),
            "mean_height": ddf["height"].mean()})


print(df.groupby("gender").apply(agg))
