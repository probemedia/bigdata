# -*- coding: utf-8 -*-

# # 12장
import numpy as np
import scipy as sp
import pandas as pd
# %%
# 12.3

import json
json_str = '''{"name": "Field", "height": 6.0}'''
my_obj = json.loads(json_str)
my_obj

# read json file
df = pd.read_json("json_test.txt")
df
df['curriculum']
df['curriculum'][0]
type(df['curriculum'][0])
df['curriculum'][0]['codeNumber']

# %%
# # 12.4
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
import urllib.request
# In[1]:


import xml.etree.ElementTree as ET
xml_str = """
<data>
    <country name="Liechtenstein">
        <rank>1</rank>
        <year>2008</year>
        <gdppc>141100</gdppc>
        <neighbor name="Austria" direction="E"/>
        <neighbor name="Switzerland" direction="W"/>
    </country>
    <country name="Singapore">
        <rank>4</rank>
        <year>2011</year>
        <gdppc>59900</gdppc>
        <neighbor name="Malaysia" direction="N"/>
    </country>
    <country name="Panama">
        <rank>68</rank>
        <year>2011</year>
        <gdppc>13600</gdppc>
        <neighbor name="Costa Rica" direction="W"/>
        <neighbor name="Colombia" direction="E"/>
    </country>
</data>
"""


# In[3]:


root = ET.fromstring(xml_str)  # xml 문자열을 파싱한다.
root.tag  # 이 xml 데이터의 최상위 태그를 출력한다.


# In[4]:


root[0]  # 0번째 자식 노드의 성분


# In[5]:


root.getchildren()  # 이 노드의 자식 노드를 반환한다.


# In[6]:


del root[0]  # 0번째 자식 노드를 삭제한다.
modified_xml_str = ET.tostring(root)  # 편집이 끝난 xml객체를 문자열로 변환한다.


# In[13]:


print(modified_xml_str.decode('utf-8'))

# %%
# read XML file
xtree = ET.parse("xml_test.xml")
xroot = xtree.getroot()
xroot.getchildren()
xroot[0]
xroot.attrib
xroot[0].tag
xroot[0][1].tag
xroot[0][1].text
xroot[0].getchildren()

df_cols = [col.tag for col in xroot[0].getchildren()]
rows = []
for node in xroot:
    row = [col.text for col in node.getchildren()]
    rows.append(row)
rows
out_df = pd.DataFrame(rows, columns=df_cols)

out_df
# %%
# # 12.5

# In[30]:


from html.parser import HTMLParser
import urllib.request

TOPIC = "Dangiwa_Umar"
url = "https://en.wikipedia.org/wiki/%s" % TOPIC


class LinkCountingParser(HTMLParser):
    def __init__(self):
        '''HTMLParser를 상속한 클래스를 정의한다'''
        self.in_paragraph = False
        self.link_count = 0
        HTMLParser.__init__(self)

    def handle_starttag(self, tag, attrs):
        '''시작 태그를 처리하는 방법을 정의한다'''
        if tag == 'p':
            self.in_paragraph = True
        elif tag == 'a' and self.in_paragraph:
            self.link_count += 1

    def handle_endtag(self, tag):
        '''종료 태그를 처리하는 방법을 정의한다'''
        if tag == 'p':
            self.in_paragraph = False


html = urllib.request.urlopen(url).read()  # url에 해당하는 html을 읽어온다.
html = html.decode('utf-8')
parser = LinkCountingParser()  # 클래스 인스턴스를 만든다.
parser.feed(html)  # 읽어온 html을 입력으로 넣는다.
print("이 문서에는 %d개의 링크가 존재합니다." % parser.link_count)
