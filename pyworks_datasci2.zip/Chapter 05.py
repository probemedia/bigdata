
# coding: utf-8

# # 5장
import matplotlib as mpl
from matplotlib import pyplot as plt
from matplotlib import font_manager, rc
import platform
import sklearn.datasets
# matplotlib 한글꺠짐 처리
plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font', family=font_name)
else:
    print("Unknown System OS")
# In[1]:


#import matplotlib
#matplotlib.rc('font', family="NanumBarunGothicOTF")

#get_ipython().run_line_magic('matplotlib', 'inline')


# # 5.2 아이리스 데이터셋

# In[31]:


import pandas as pd
from matplotlib import pyplot as plt
import sklearn.datasets


def get_iris_df():
    ds = sklearn.datasets.load_iris()
    df = pd.DataFrame(ds['data'], columns=ds['feature_names'])
    code_species_map = dict(zip(
        range(3), ds['target_names']))
    df['species'] = [code_species_map[c] for c in ds['target']]
    return df


df = get_iris_df()
df_iris = df
print(df)

# %% 
# 5.3 원형 차트
# 꽃받침 너비에 따른 원형차트
sums_by_species = df.groupby('species').sum()
var = 'sepal width (cm)'
sums_by_species[var].plot(kind='pie', fontsize=20)
plt.ylabel(var, horizontalalignment='left')
plt.title('꽃받침 너비로 분류한 붓꽃', fontsize=25)
plt.savefig('iris_pie_for_one_variable.png')
plt.show()
plt.close()

# %%
# 꽃받침 너비/길이, 꽃잎 너비/길이에 따른 원형차트 - 4개 원형차트
sums_by_species = df.groupby('species').sum()
sums_by_species.plot(kind='pie', subplots=True,
                     layout=(2, 2), legend=False)
plt.title('종에 따른 전체 측정값Total Measurements, by Species')
plt.savefig('iris_pie_for_each_variable.png')
plt.show()
plt.close()

# %%
# 5.4 막대그래프

sums_by_species = df.groupby('species').sum()
var = 'sepal width (cm)'
sums_by_species[var].plot(kind='bar', fontsize=15, rot=30)

plt.title('꽃받침 너비(cm)로 분류한 붓꽃', fontsize=20)
# plt.savefig('iris_bar_for_one_variable.png')
# plt.close()
sums_by_species = df.groupby('species').sum()
sums_by_species.plot(
   kind='bar', subplots=True, fontsize=12)
plt.suptitle('종에 따른 전체 측정값')
plt.savefig('iris_bar_for_each_variable.png')
plt.show()
plt.close()

# %%
# 5.5 히스토그램
# 꽃받침 너비/길이, 꽃잎 너비/길이에 따른 히스토그램 - 4개의 히스토그램
df.plot(kind='hist', subplots=True, layout=(2, 2))
plt.suptitle('붓꽃 히스토그램', fontsize=20)
plt.show()
plt.close()

# %%
# 품종에 따른 꽃잎 길이 히스토그램 - 3개의 히스토그램이 1개의 차트에 그려짐

for spec in df['species'].unique():
    forspec = df[df['species'] == spec]
    forspec['petal length (cm)'].plot(kind='hist', alpha=0.4, label=spec)

plt.legend(loc='upper right')
plt.suptitle('종에 따른 꽃잎 길이')
plt.savefig('iris_hist_by_spec.png')
plt.show()
plt.close()

# %%
# 아이리스 품종별 비교 히스토그램 - 서브플롯으로 4개그래프 플롯
var1 = ['sepal length (cm)', 'sepal width (cm)',
        'petal length (cm)', 'petal width (cm)']
specs = df['species'].unique()
i = 0

plt.figure(figsize=(10, 9))

for v in var1:
    i += 1
    plt.subplot(2, 2, i)
    for spec in specs:
        forspec = df[df['species'] == spec]
        forspec[v].plot(kind='hist', alpha=0.4, label=spec)
        plt.legend(loc='upper right')
        plt.suptitle('아이리스 품종별 비교 히스토그램')
plt.savefig('iris_hist_by_spec2.png')
plt.show()
plt.close()
# %%
# 서브플롯에 각각 타이틀 지정
var1 = ['sepal length (cm)', 'sepal width (cm)',
        'petal length (cm)', 'petal width (cm)']

specs = df['species'].unique()
i = 0

fig = plt.figure(figsize=(10, 9))

for v in var1:
    i += 1
    ax = fig.add_subplot(2, 2, i)
    ax.title.set_text(v)
    for spec in specs:
        forspec = df[df['species'] == spec]
        forspec[v].plot(kind='hist', alpha=0.4, label=spec)
        plt.legend(loc='upper right')
        plt.suptitle('아이리스 품종별 비교 히스토그램')
plt.savefig('iris_hist_by_spec3.png')
plt.show()
plt.close()
# %%
# 4개의 개별 히스토그램 생성
var1 = ['sepal length (cm)', 'sepal width (cm)',
        'petal length (cm)', 'petal width (cm)']
specs = df['species'].unique()
for v in var1:
    for spec in specs:
        forspec = df[df['species'] == spec]
        forspec[v].plot(kind='hist', alpha=0.4, label=spec)
        plt.legend(loc='upper right')
        plt.suptitle(v)
    plt.show()

plt.close()
# %%
# # 5.6 평균, 표준편차, 중간값, 백분위

col = df['petal length (cm)']
average = col.mean()
std = col.std()
median = col.quantile(0.5)
percentile25 = col.quantile(0.25)
percentile75 = col.quantile(0.75)
print(average, std, median, percentile25, percentile75)


# %%
# 아웃라이어 걸러내기

col = df['petal length (cm)']
perc25 = col.quantile(0.25)
perc75 = col.quantile(0.75)
clean_avg = col[(col > perc25) & (col < perc75)].mean()
print(clean_avg)

# %%
# 5.7 상자그림

col = 'sepal length (cm)'
df['ind'] = pd.Series(df.index).apply(lambda i: i % 50)
df.pivot('ind', 'species')[col].plot(kind='box')
plt.show()
plt.close()

# %%
# 5.8 산포도

df.plot(kind="scatter",
        x="sepal length (cm)", y="sepal width (cm)")
plt.title("Length vs Width")
plt.show()
plt.close()

# %%


colors = ["r", "g", "b"]
markers = [".", "*", "^"]
fig, ax = plt.subplots(1, 1)

for i, spec in enumerate(df['species'].unique()):
    ddf = df[df['species'] == spec]
    ddf.plot(kind="scatter",
             x="sepal width (cm)", y="sepal length (cm)",
             alpha=0.5, s=10*(i+1), ax=ax,
             color=colors[i], marker=markers[i], label=spec)

plt.legend()
plt.show()
plt.close()

# %%

import pandas as pd
import sklearn.datasets as ds
import matplotlib.pyplot as plt
# 팬다스 데이터프레임 생성
bs = ds.load_boston()
df = pd.DataFrame(bs.data, columns=bs.feature_names)
df['MEDV'] = bs.target
# 일반적인 산포도
df.plot(x='CRIM', y='MEDV', kind='scatter')
plt.title('일반축에 나타낸 범죄 발생률')
plt.show()
plt.close()

# %%
# ## 로그를 적용
# Customize matplotlib
mpl.rcParams.update(
    {
        'text.usetex': False,
        'font.family': 'stixgeneral',
        'mathtext.fontset': 'stix',
    }
)


df.plot(x='CRIM', y='MEDV', kind='scatter', logx=True)
plt.title('Crime rate on logarithmic axis')
plt.show()
plt.close()

# %%
# 5.10 산포 행렬

# 'pandas.tools.plotting.scatter_matrix' is deprecated
# import 'pandas.plotting.scatter_matrix'

from pandas.plotting import scatter_matrix
scatter_matrix(df_iris)
plt.show()
plt.close()

# %%
# 5.11 히트맵

df_iris.plot(kind="hexbin", x="sepal width (cm)", y="sepal length (cm)")
plt.show()
plt.close()

# %%
# 5.12 상관관계

df = get_iris_df()

df["sepal width (cm)"].corr(df["sepal length (cm)"])  # Pearson corr

df["sepal width (cm)"].corr(df["sepal length (cm)"], method="pearson")

df["sepal width (cm)"].corr(df["sepal length (cm)"], method="spearman")

df["sepal width (cm)"].corr(df["sepal length (cm)"], method="spearman")

# %%
# 5.12 시계열 데이터

# $ pip install statsmodels
import statsmodels.api as sm
#data = sm.datasets.co2.load_pandas().data
data = sm.datasets.get_rdataset("epil", "MASS").data
data.to_csv('s_data.csv')

# %%
r_data = pd.read_csv('s_data.csv')
r_data.plot()

plt.show()
plt.close()

# %%
# ## 구글 주가 불러오는 코드는 야후 API가 작동하지 않아서 생략합니다.
# %%

import statsmodels.api as sm

dta = sm.datasets.co2.load_pandas().data
# deal with missing values. see issue
dta.plot()
plt.title("이산화탄소 농도")
plt.ylabel("PPM")
plt.show()
plt.close()
