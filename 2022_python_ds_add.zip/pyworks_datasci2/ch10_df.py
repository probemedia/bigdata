# -*- coding: utf-8 -*-
"""
Created on Wed Sep  5 21:14:53 2018

@author: KEO
"""
import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd
# %%
# https://wikidocs.net/4368 참조
daeshin = {'open':  [11650, 11100, 11200, 11100, 11000],
           'high':  [12100, 11800, 11200, 11100, 11150],
           'low':  [11600, 11050, 10900, 10950, 10900],
           'close': [11900, 11600, 11000, 11100, 11050]}

daeshin_day = pd.DataFrame(daeshin)
print(daeshin_day)

# column순서 재배열
daeshin_day = pd.DataFrame(daeshin, columns=['open', 'high', 'low', 'close'])
print(daeshin_day)
date = ['16.02.29', '16.02.26', '16.02.25', '16.02.24', '16.02.23']
daeshin_day = pd.DataFrame(daeshin,
                           columns=['open', 'high', 'low', 'close'],
                           index=date)
print(daeshin_day)
close = daeshin_day['close']  # 칼럼 선택
day_data = daeshin_day.loc['16.02.24']  # 로우 선택

print(daeshin_day.columns)  # 칼럼 이름확인
print(daeshin_day.index)  # 인덱스 이름확인

#
dat = pd.read_csv('out.csv', encoding='utf-8')
dat
#
dat2 = pd.read_csv('ozone_data.csv', encoding='cp949', index_col='일시')
dat2
type(dat2)
dat2.loc['2015-07']
part_data = dat2.iloc[:, 1:]
type(part_data)
part_data
part_data.loc['2015-07']

# %%
dat3 = pd.read_csv('ozone_data.csv', encoding='cp949')
dat3
dates = list(dat3.loc[:, '일시'])
dates
oz = list(dat3.loc[:, '평균오존전량(DU)'])
oz

mpl.rc('font', family='NanumGothic', size="12")
mpl.rc('lines', linewidth=3,  linestyle='-')
plt.figure(figsize=(12, 3))
plt.clf()
plt.plot(dates, oz, 'k-')

plt.xlabel('관측월')
plt.ylabel('월별평균오존전량(DU)')
plt.grid()
plt.show()
# %%
dat4 = pd.read_csv('ozone_data.csv', encoding='cp949')
dat4
# %%
dates_2 = list(dat4.loc[::3, '일시'])
dates_2
oz_2 = list(dat4.loc[::3, '평균오존전량(DU)'])
oz_2

mpl.rc('font', family='NanumGothic', size="12")
mpl.rc('lines', linewidth=3,  linestyle='-')
plt.figure(figsize=(12, 3))
plt.clf()
plt.plot(dates_2, oz_2, 'k-')

plt.xlabel('관측월')
plt.ylabel('월별평균오존전량(DU)')
plt.grid()
plt.show()
# %% 년도별 서브 플롯 작성
search_date = ['2013', '2014', '2015']
start_idx = []
end_idx = []
x_values = []
y_values = []

dates_3 = list(dat4.loc[:, '일시'])
oz_3 = list(dat4.loc[:, '평균오존전량(DU)'])

for v1 in search_date:
    for idx, val in enumerate(dates_3):
        if v1 in val:
            start_idx.append(idx)
            break

end_idx = start_idx.copy()
end_idx.append(len(dates_3))
del end_idx[0]

nums = [x+1 for x in range(len(start_idx))]

for i in range(len(start_idx)):
    x_values.append(dates_3[start_idx[i]:end_idx[i]])
    y_values.append(oz_3[start_idx[i]:end_idx[i]])

mpl.rc('font', family='NanumGothic', size="12")
mpl.rc('lines', linewidth=3,  linestyle='-')

plt.figure(figsize=(10, 9))
plt.clf()

for i in range(len(search_date)):
    plt.subplot(3, 1, nums[i])
    plt.plot(x_values[i], y_values[i], 'k-')
    plt.xlabel(search_date[i])
    plt.ylabel('월별평균오존전량(DU)')
    plt.grid()

plt.show()

# %%
