# 7. 결측치와 이상치 처리

#-----
library(readxl)
library(dplyr)
library(ggplot2)


#-----
# 7-001. 작업데이터 준비
df_ghgs <- read.csv("data/1999-2018_monthly_ghg.csv")

df_ghgs_new <- df_ghgs[, 2:9]
names(df_ghgs_new)
names(df_ghgs_new) <- c("관측일", "CO2_ppm", "CH4_ppm", "N2O_ppm", 
                        "CFC11_ppm", "CFC12_ppm","CFC113_ppm", "SF6_ppm")
names(df_ghgs_new)

head(df_ghgs_new)
tail(df_ghgs_new)
dim(df_ghgs_new)
str(df_ghgs_new)


#-----
# 7-002. df_ghgs_new데이터프레임의 결측치 확인
# df_ghgs_new데이터프레임의 수량형변수의 결측치 확인
summary(df_ghgs_new)

# table()함수를 사용한 CH4_ppm변수의 결측치와 결측치가 아닌값 분류
table(is.na(df_ghgs_new$CH4_ppm))


#-----
# 7-003. 결측치 제외
# filter()함수 사용
df_ch4 <- df_ghgs_new %>% 
  filter(!is.na(CH4_ppm)) %>%
  select(CH4_ppm)

summary(df_ch4)

# 함수에서 제공하는 결측치 제외 사용
median(df_ghgs_new$CH4_ppm, na.rm=T)


#-----
# 7-004. 결측치 보정
# 결측치 보정에 사용한 데이터프레임 준비
df_ch4_2 <- df_ghgs_new %>% select(관측일, CH4_ppm)
table(is.na(df_ch4_2["CH4_ppm"]))

# 중위수를 사용한 결측치 보정
df_ch4_2$CH4_ppm[is.na(df_ch4_2$CH4_ppm)] <- median(df_ch4_2$CH4_ppm, na.rm=T)
table(is.na(df_ch4_2["CH4_ppm"]))

# 선형보간법 사용
install.packages("pracma")
library(pracma)
x <- seq(0, 10)
y <- cos(x)
x2 <- seq(0, 10, len=30)
y2 <- interp1(x, y, x2, method="linear")
y2


#-----
# 7-005. 이상치를 결측치로 바꿔서 제외
# 복제 본 df_ch4_m1 생성
df_ch4_m1 <- df_ch4_2

# 정상치 범위는 1810~1990에 해당하지 않는 데이터는 NA로 처리
df_ch4_2$CH4_ppm <- ifelse(df_ch4_2$CH4_ppm >= 1810 &  df_ch4_2$CH4_ppm <= 1990,
                    df_ch4_2$CH4_ppm, NA)
summary(df_ch4_2)

# NA값 제외
df_ch4_2 %>% filter(!is.na(CH4_ppm))


#-----
# 7-006. 이상치를 중위수로 보정
df_ch4_m1$CH4_ppm <- ifelse(df_ch4_m1$CH4_ppm >= 1810 & df_ch4_m1$CH4_ppm <= 1990,
                            df_ch4_m1$CH4_ppm, median(df_ch4_m1$CH4_ppm, na.rm=T))
summary(df_ch4_m1)

# 통계학적 정상치의 범위
quantile(df_ghgs_new$CH4_ppm, na.rm=T)

q1 <- 1868
q3 <- 1929
q1 - (q3 -q1) * 1.5
q3 + (q3 - q1) * 1.5
