# 4. 통계 기초

#-----
# 4-001.평균, 분산, 표준편차, 최빈수 구하기 
# 엑셀파일을 읽어 변수에 저장
library(readxl)
df_ex <- read_excel("data/2020_seoul_gu_od.xlsx")
df_ex

# 작업대상 : df_ex데이터프레임변수에서 합계변수만 추출후 첫번째 데이터를 제외한 값 얻기
old_data <- df_ex$합계[2:length(df_ex$합계)]
old_data

# old_data벡터의 평균 구하기
mean(old_data)

# old_data벡터의 분산 구하기
var(old_data)

# old_data벡터의 표준편차 구하기
sd(old_data)

# data1벡터의 최빈수 구하기
data1 <- c(50, 11, 12, 50, 60, 11, 11)
as.numeric(names(sort(-table(data1)))[1])

table(data1)
sort(-table(data1))
names(sort(-table(data1)))


#-----
# 4-002.최소값, 최대값, 1분위수, 3분위수, 중위수 구하기
# old_data벡터의 최소값 구하기
min(old_data)

# old_data벡터의 최대값 구하기
max(old_data)

# old_data벡터의 분위수 구하기
quantile(old_data)

# old_data벡터의 1분위수 구하기
quantile(old_data, 0.25)

# old_data벡터의 3분위수 구하기
quantile(old_data, 0.75)

# old_data벡터의 중위수 구하기
median(old_data)  # quantile(old_data, 0.5)
