# 4. ch04_basic_statistics2.R
# 4. 통계 기초

#-----
# 4-001.평균, 분산, 표준편차, 최빈수 구하기 
# 엑셀파일을 읽어 변수에 저장
library(readxl)
df_ex <- read_excel("data/2020_seoul_gu_od.xlsx")
df_ex

# 작업대상 : df_ex데이터프레임변수에서 합계변수만 추출후 첫번째 데이터를 제외한 값 얻기
old_data <- df_ex$합계[2:length(df_ex$합계)]
old_data

# old_data벡터의 평균 구하기
mean(old_data)

# old_data벡터의 분산 구하기
var(old_data)

# old_data벡터의 표준편차 구하기
sd(old_data)

# data1벡터의 최빈수 구하기
data1 <- c(50, 11, 12, 50, 60, 11, 11)
as.numeric(names(sort(-table(data1)))[1])

table(data1)
sort(-table(data1))
names(sort(-table(data1)))


#-----
# 4-002.최소값, 최대값, 1분위수, 3분위수, 중위수 구하기
# old_data벡터의 최소값 구하기
min(old_data)

# old_data벡터의 최대값 구하기
max(old_data)

# old_data벡터의 분위수 구하기
quantile(old_data)

# old_data벡터의 1분위수 구하기
quantile(old_data, 0.25)

# old_data벡터의 3분위수 구하기
quantile(old_data, 0.75)

# old_data벡터의 중위수 구하기
median(old_data)  # quantile(old_data, 0.5)


#-----
# 4-003.주요 수학/통계함수
v1 <- c(1, 2, 5, 6, -99)

abs(v1)

exp(v1)

log(v1[1:4])

log10(v1[1:4])

max(v1)

min(v1)

range(v1)

round(123.457, 2)

sqrt(v1[1:4])

sum(v1)


#-----
# 4-004.확률분포 관련 함수
df_1 <- read.csv("data/data01_1.csv")
df_1

cor(df_1$총계, df_1$충돌)
cor(df_1[3:18])
round(cor(df_1[3:18]), 2)

cov(df_1)
round(cov(df_1), 2)

cumsum(1:5)

diff(df_1$총계)

mean(df_1$총계) 

median(df_1$총계) 

quantile(df_1$총계)

sd(df_1$총계)

sort(df_1$총계)

summary(df_1$총계)
summary(df_1)

var(df_1$총계)

df_ghg <- read.csv("data/1999-2020_ghgs.csv")
df_ghg
cor(df_ghg$CO2_ppm, df_ghg$CH4_ppm, method="pearson", use="complete.obs")
cor(df_ghg$CO2_ppm, df_ghg$CH4_ppm, method="spearman", use="complete.obs")
cor(df_ghg$CO2_ppm, df_ghg$CH4_ppm, method="kendall", use="complete.obs")
cor(df_ghg[3:9], use="complete.obs")
cor(df_ghg[3:9], method="spearman", use="complete.obs")

# 자기상관 : forecast의 ggAcf()
library(forecast)
ggAcf(df_ghg$CO2_ppm, lag=12)
ggAcf(df_ghg$CH4_ppm, lag=12)
df_p2 <- df_ghg[, 3:4]
df_p2$CO2_ppm <- na.interp(df_p2$CO2_ppm)
df_p2$CH4_ppm <- na.interp(df_p2$CH4_ppm)

co2_acf <- acf(df_p2$CO2_ppm, type=c("correlation"), lag=12, plot=TRUE)
co2_acf$acf

ch4_acf <- acf(df_p2$CH4_ppm, type=c("correlation"), lag=12, plot=TRUE)
ch4_acf$acf

#-----
# 4-005.확률분포 관련 함수
rnorm(10, 0, 1)  # 평균: 0, 표준편차: 1 인 난수 10개 생성
pnorm(0.6, mean=0.4, sd=0.1)  # 평균: 0.4, 표준편차:0.1에서 0.6보다 낮을 확률
dnorm(1:10, 0, 1)

#-----
# 마. 통계 분석에 필요한 기본개념

#-----
# 필요패키지 설치 및 로드
install.packages("ggplot2")
install.packages("tidyverse")
install.packages("gridExtra")
# 주요 패키지 로드
library(readxl)
library(dplyr)
library(ggplot2)
library(tidyverse)
library(gridExtra)


#-----
# 4-006. 코로나19사태 전과 후의 지하철 이용객수 차이 대응표본 t-test
# 데이터 로드
df_users <- read.csv("data/2019-2020_m_subway_diff.csv")
df_users

# diff_2020_2019변수만 벡터로 추출해서 sub_users에 저장
sub_users <- df_users$diff_2020_2019
sub_users

# 수량형데이터 - 통계치 파악
summary(sub_users)

sd(sub_users)  # 표준편차

# 데이터 파악을 위한 시각화
par(mfrow=c(2, 2))  # 4개의 서브플롯
hist(sub_users)  # 히스토그램
boxplot(sub_users)  # 상자그림
qqnorm(sub_users); qqline(sub_users) # 정규분포의 Q-Q plot
hist(sub_users, prob=TRUE)  # 백분율 히스토그램
lines(density(sub_users), lty=3)  # 히스토그램에 추정선 분포 추가
dev.off()  # 그래프제거

# 파일로 저장시 사용
png("plots/c19_ds.png", 5.5, 4, units="in", pointsize=9, res=600)
par(mfrow=c(2, 2))  # 4개의 서브플롯
hist(sub_users)  # 히스토그램
boxplot(sub_users)
qqnorm(sub_users); qqline(sub_users)
hist(sub_users, prob=TRUE)
lines(density(sub_users), lty=3)
dev.off()

# 가설검정 
t.test(sub_users)


#-----
# 4-007. 전륜구동차와 4륜구동차 간의 도시주행 연비차이 비교 독립표본 t-test 
# 데이터 로드
library(ggplot2)
df_mpg <- mpg

# 데이터 탐색
head(df_mpg)
tail(df_mpg)
str(df_mpg)

# 구동방식이 f, 4인 데이터 중 구동방식과 도시주행연비 변수를 가진 df_s_c 생성
df_s_c <- df_mpg %>%
  filter(drv %in% c("f", "4")) %>%
  select(drv, cty)

df_s_c

# 구동방식(drv)이 전륜(f)과 4륜(4)인 데이터수 파악
table(df_s_c$drv)

# 전륜(f)데이터 도시주행연비(cty) 요약통계량
df_s_c %>% filter(drv=='f') %>% select(cty) %>% summary()

# 4륜(4)데이터 도시주행연비(cty) 요약통계량
df_s_c %>% filter(drv=='4') %>% select(cty) %>% summary()

# 구동방식(drv)별 도시주행연비(cty)비교 병렬상자그림
df_s_c %>% ggplot(aes(drv, cty)) + geom_boxplot()

# 파일로 저장시 사용
g <- df_s_c %>% ggplot(aes(drv, cty)) + geom_boxplot()
ggsave("plots/mpg_drv_cty_boxplot.png", g, width=6,
       height=4, units="in", dpi=600)

# 가설검정
t.test(data=df_s_c, cty ~ drv, var.equal=T)


#-----
# 4-008.지하철 2호선역별일별 하차승객수와 지하철 평균역별일별 하차승객수 비교
# 단일 표본 t-test

# 데이터 로드
df_sub <- read.csv("data/202002_seoul_subway.csv")

# 데이터 탐색
head(df_sub)
tail(df_sub)
str(df_sub)

# 지하철 역별 일별 하차승객수 평균
tm_p <- (df_sub %>% summarise(mean_p=mean(하차총승객수)))$mean_p
tm_p

# 지하철 2호선 데이터만 추출후 df_sub_2에 저장
df_sub_2 <- df_sub %>% filter(노선명=="2호선")
df_sub_2

# df_sub_2의 하차총승객수 요약통계량
summary(df_sub_2$하차총승객수)

# 지하철 2호선 하차총승객수 상자그림
df_sub_2 %>% ggplot(aes(노선명, 하차총승객수)) + geom_boxplot()

# 가설검증
t.test(df_sub_2$하차총승객수, mu=tm_p)


#-----
# a, b, r, t, p 직접구하기
# 1) p값 계산식  2 * pt(-t, n - 2)  으로 cor.test(x, y)으로 검증.

# x,y가 독립적인 정규분포를 따르면 자유도가 n-2인 t분포를 따름 
# r, p, t값을 직접 구할 경우
x <- c(1, 2, 3, 4, 5)
y <- c(1, 3, 5, 2, 4)
r <- cor(x, y)  # r = 0.5
n <- 5
t <- r * sqrt(n - 2) / sqrt(1 -r^2)  # 자유도:n-2, t = 1
p <- 2 * pt(-t, n - 2)  # pt(): 누적분포함수(t분포), p = 0.391

# p, 신뢰구간 구하는 함수
cor.test(x, y)

# 2)  a, b값 계산 : optim()함수를 사용해서 최적화된 a, b 계산
# optim(c(1, 1), f1)$par를 사용해서 a, b 를 구함
# 최소제곱법으로 a, b 구하기
x <- c(1, 2, 3, 4, 5)
y <- c(1, 3, 5, 2, 4)

f1 <- function(arg){
  a <- arg[1]
  b <- arg[2]
  t <- a * x + b
  sum((y - t)^2)
}

ab <- optim(c(1, 1), f1)$par
ab[1]  # a
ab[2]  # b


#---
# 부트스트랩
# 방법1 : boot라이브러리의 boot()함수사용
# mpg데이터의 도시연비 평균값의 부트스트랩
library(ggplot2)
library(boot)
df_mpg <- mpg
names(df_mpg)
mean(df_mpg$cty)  # 16.85897

# x: 데이터, idx: 부트스트랩의 재표본추출 튜플
sta_fun <- function(x, idx) mean(x[idx])
# boot(데이터, R=반복횟수, statistic=정의한함수)
boot_obj <- boot(df_mpg$cty, R=100, statistic=sta_fun)
boot_obj


# 방법2
x <- runif(10000)  # 0~1사이의 난수 10000개 발생
sample(x, 20, replace=TRUE)  # 20개의 데이터를 복원추출
mean(sample(x, 20, replace=TRUE))  # 20개의 데이터를 복원추출한 것의 평균

# 20개의 데이터를 복원추출한 것의 평균을 100번 반복
b <- replicate(100, mean(sample(x, 20, replace=TRUE)))

sd(b)  # 표준편차
quantile(b, c(0.025, 0.0975))  # 95%신뢰구간

#----
# cor.test()로 p 값과 신뢰구간구하기
df_ghgs <- read.csv("data/1999-2020_ghgs.csv")

# CO2_ppm와 CH4_ppm에 NA값 확인
summary(df_ghgs[, 2:3])

# CO2_ppm와 CH4_ppm의 상관 계수 구함
cor(df_ghgs$CO2_ppm, df_ghgs$CH4_ppm, use="complete.obs")
cor.test(df_ghgs$CO2_ppm, df_ghgs$CH4_ppm)

cor(df_ghgs$CO2_ppm, df_ghgs$CH4_ppm, use="complete.obs", method="spearman")
cor.test(df_ghgs$CO2_ppm, df_ghgs$CH4_ppm, method="spearman")

cor(df_ghgs$CO2_ppm, df_ghgs$CH4_ppm, use="complete.obs", method="kendall")
cor.test(df_ghgs$CO2_ppm, df_ghgs$CH4_ppm, method="kendall")


# 
library(corrplot)
df_mefs <- read.csv("data/2011-2021_mefs.csv", fileEncoding = "cp949")
head(df_mefs)
names(df_mefs)
round(cor(df_mefs[2:23], use="complete.obs"),2)
cor(df_mefs$광주적설, df_mefs$칠발도풍속1, use="complete.obs")
cor(df_mefs$광주적설, df_mefs$칠발도풍속2, use="complete.obs")

df_mefs156 <- df_mefs[c(5:6,14:23)]
df_mefs156_cor <- round(cor(df_mefs156, use="complete.obs"),2)
corrplot(df_mefs156_cor, method="number")
cor(df_mefs156$광주적설, df_mefs156$칠발도평균파고, use="complete.obs")
cor(df_mefs156$광주적설, df_mefs156$칠발도평균파고, use="complete.obs", method="spearman")
cor(df_mefs156$광주적설, df_mefs156$칠발도평균파고, use="complete.obs", method="kendall")
cor.test(df_mefs156$광주적설, df_mefs156$칠발도평균파고)
t.test(df_mefs156$광주적설, df_mefs156$칠발도평균파고)
