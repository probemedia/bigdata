# 5. R 초급통계분석

#-----
# 05-001. 필요패키지 설치 및 로드

# 주요 패키지 로드
library(readxl)
library(dplyr)
library(ggplot2)
library(tidyverse)
library(gridExtra)


#-----
# 05-002. 모든 데이터에 공통으로 수행하는 분석
install.packages("corrplot")
library(corrplot)

# 데이터 로드
df_ghgs <- read.csv("data/1999-2020_ghgs.csv")

# 데이터 파악
head(df_ghgs)
tail(df_ghgs)
dim(df_ghgs)
str(df_ghgs)

# 데이터의 요약통계량, 결측치 확인
summary(df_ghgs)

# 수량형 변수들의 관계를 한 번에 파악하는 산점도 행렬, 상관행렬 히트맵
# 산점도 행렬
pairs(df_ghgs[, 3:9])

# 상관행렬 히트맵
df_ghgs_cor <- cor(df_ghgs[, 3:9], use="complete.obs")
corrplot(df_ghgs_cor, method="number")


#-----
# 05-003. 1개의 수량형 변수 분석
# 오존전량 데이터 사용
# 1) 데이터로드 및 데이터파악
# 데이터로드
df_ozone <- read.csv("data/ozone_data.csv")

# 데이터 파악
names(df_ozone)
head(df_ozone)
tail(df_ozone)
str(df_ozone)

# 2) 작업대상 변수 선택 및 통계량 확인 
# 작업대상 변수 선택
df_ozone1 <- df_ozone %>%
  filter(평균오존전량.DU.>0)
df_ozone1

ozone_du <- df_ozone1$평균오존전량.DU.
ozone_du

# 통계량 확인
summary(ozone_du)  # 요약통계량
mean(ozone_du)  # 평균
median(ozone_du)  # 중위수
range(ozone_du)  # 값의 범위
quantile(ozone_du)  # 사분위수
quantile(ozone_du, prob=0.25)  # q1
quantile(ozone_du, prob=0.75)  # q3

# 3) 데이터 형태파악을 위한 시각화
par(mfrow=c(2, 2))
hist(ozone_du)
boxplot(ozone_du)
qqnorm(ozone_du); qqline(ozone_du)
hist(ozone_du, prob=TRUE)
lines(density(ozone_du), lty=3)
dev.off()  # 2x2형태의 시각화 해제 필요한 경우

# 데이터파악 시각화결과 파일로 저장
png("plots/ozone.png", 5.5, 4, units='in', pointsize=9, res=600)
par(mfrow=c(2, 2))
hist(ozone_du)
boxplot(ozone_du)
qqnorm(ozone_du); qqline(ozone_du, col=2)
hist(ozone_du, prob=TRUE)
lines(density(ozone_du), lty=3)
dev.off()

# 시계열 그래프작성
# 일시변수 확인
df_ozone1$일시

# 일시변수 날짜타입 변환
df_ozone1$일시 <- as.Date(df_ozone1$일시)
str(df_ozone1)

# 시계열 그래프
df_ozone1 %>% ggplot(aes(일시, 평균오존전량.DU.)) + geom_line()
df_ozone1 %>% ggplot(aes(일시, 평균오존전량.DU.)) + geom_line() + 
  geom_smooth(method='lm', formula=y~x)
# 시계열 그래프 파일로 저장
g <- df_ozone1 %>% ggplot(aes(일시, 평균오존전량.DU.)) + geom_line() +
  geom_smooth(method='lm', formula=y~x)
ggsave("plots/ozone_line.png", g, width=6, height=4, units="in", dpi=600)

# 4) 일변량 t-test
t.test(ozone_du)

# 5) 이상치와 로버스트 통계방법
c(mean(ozone_du), sd(ozone_du))  # 평균, 표준편차
c(median(ozone_du), mad(ozone_du))  # 중앙값, mad


#-----
# 05-004. 1개의 범주형 변수 분석
# 서울시 코로나19 확진자 데이터 사용
# 1) 데이터로드 및 파악
df_c19 <- read.csv("data/20211004_seoul_c19_suc.csv")
names(df_c19)
head(df_c19)
tail(df_c19)
str(df_c19)

# 2) 작업대상 변수 선택 및 빈도표 확인
# 확진자 상태에 대한 빈도표
table(df_c19$상태)

# 작업대상 변수 선택 
df_c19 <- df_c19[, c(1, 3)]

# 변수명 변경
names(df_c19) <- c("no", "status")
names(df_c19)

# status변수를 factor타입으로 변환하고 레벨 설정 퇴원-yes, 퇴원아님-no
fac_sta <- factor(df_c19$status, levels=c("no","yes"))  
fac_sta

# no, yes 범주에 해당하는 데이터 수(빈도표)
table(fac_sta)  

# no, yes 범주에 해당하는 데이터의 비율
prop.table(table(fac_sta)) 

# 3) 데이터 형태파악을 위한 시각화
# 각 범주의 데이터량 비교를 위한 막대그래프
df_c19 %>% ggplot(aes(x = status)) + geom_bar()

# 막대그래프파일로 저장
g <- df_c19 %>% ggplot(aes(x = status)) + geom_bar()
ggsave("plots/c19status_hist.png", g, width=6, height=4, units='in', dpi=600)

# 4) 이항검정 binom.test()
len_yes = length(fac_sta[fac_sta=="yes"])  # 성공(yes)의 수
len_all = length(fac_sta)  # 전체데이터의 수
binom.test(x=len_yes, n=len_all, p=0.5)  # 이항검정

# 5) 오차한계, 표본크기
# 성공확률은 0.8479292와 신뢰구간 0.8457271~ 0.8501118 에 대한 오차한계
pos = 0.8479292
n = 103511
x1 = as.integer(n * pos) * 100
diff_ci = 0.8501118 - 0.8457271
moe = diff_ci/2  # 오차한계
moe

# 표본의크기를 100배크게하면 오차한계는 1/10로 줄어듦
binom.test(x=x1, n=n*100)  # 표본크기*100

diff_ci2 = 0.8481383 - 0.8477006
diff_ci2/2  # 표본의크기가 100배 커진경우 오차한계


#-----
# 05-005. 2개의 수량형 변수 분석
# 온실가스 데이터 사용 - CO2_ppm와 CH4_ppm 분석

# 1) 데이터로드 및 파악
# 데이터로드
library(corrplot)

df_ghgs <- read.csv("data/1999-2020_ghgs.csv")

# 데이터 파악
head(df_ghgs)
tail(df_ghgs)
dim(df_ghgs)
str(df_ghgs)

# 2) 요약통계량, 결측치 확인
# df_ghgs데이터프레임의 수량형 변수 요약통계량 확인
summary(df_ghgs)

# CO2_ppm 변수 요약통계량
summary(df_ghgs$CO2_ppm) 

# CH4_ppm 변수 요약통계량
summary(df_ghgs$CH4_ppm)

# 3) 데이터 형태파악을 위한 시각화
# 산점도 행렬
pairs(df_ghgs[, 3:9])

# 상관행렬
df_ghgs_cor <- cor(df_ghgs[, 3:9], use="complete.obs")
df_ghgs_cor

# 상관행렬 히트맵
corrplot(df_ghgs_cor, method="number")

# CO2_ppm, CH4_ppm 변수 산점도
df_ghgs %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_point()

#  CO2_ppm, CH4_ppm 변수 산점도: 단순 회귀 - 비선형 모형
df_ghgs %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_point() + geom_smooth()

#  CO2_ppm, CH4_ppm 변수 산점도: 단순 선형 모형
df_ghgs %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_point() + 
  geom_smooth(method='lm', formula=y~x)

# 4) 상관계수
# CO2_ppm와 CH4_ppm 변수의 상관계수: 피어슨 방식
cor(df_ghgs$CO2_ppm, df_ghgs$CH4_ppm, use="complete.obs")

# CO2_ppm와 CH4_ppm 변수의 상관계수: 스피어만 방식
cor(df_ghgs$CO2_ppm, df_ghgs$CH4_ppm, method="spearman", 
    use="complete.obs")

# CO2_ppm와 CH4_ppm 변수의 상관계수: 캔달 방식
cor(df_ghgs$CO2_ppm, df_ghgs$CH4_ppm, method="kendall", 
    use="complete.obs")

# 5) 단순 회귀분석 - lm()
# 선형모형을 최소제곱법으로 추정
ghg_lm <- lm(CH4_ppm ~ CO2_ppm, data=df_ghgs)
ghg_lm

# 추정치와 각 모수값이 0인지 가설검정
summary(ghg_lm)

# 7) 선형회귀 모형 예측
# 반응변수CH4_ppm의 예측값
predict(ghg_lm)

# 잔차계산
resid(ghg_lm)
# summary(df_ghgs$CO2_ppm)
# 새로운 데이터 CO2_ppm=c(430, 440, 450)에 따른 CH4 예측값 
predict(ghg_lm, newdata=data.frame(CO2_ppm=c(430, 440, 450)))

# 새로운 데이터 CO2_ppm=c(430, 440, 450)에 따른 CH4 예측값 및 예측오차
predict(ghg_lm, newdata=data.frame(CO2_ppm=c(430, 440, 450)), se.fit=TRUE)

# 8) 선형회귀 모형의 가정 진단
# 선형회귀 모형 진단 플롯
par(mfrow=c(2, 2))
plot(ghg_lm, las=1) # las=1, 축레벨이 축과 평행
dev.off() # 2x2형태의 시각화 해제

# 그래프 파일로 저장
png("plots/co2_ch4_lrd_plot.png", 5.5, 4, units="in", 
    pointsize=9, res=600)
par(mfrow=c(2, 2))
plot(ghg_lm, las=1)
dev.off()

# 9) 로버스트 선형회귀분석 - lqs()
# 이산화탄소 배출량(CO2값)에 가장 큰 영향을 변수 확인
library(MASS)  # lqs() 제공

# 난수시드 고정
set.seed(2110)
# 로버스트 선형회귀분석
lqs(CO2_ppm ~ ., data=df_ghgs[, 3:9])

# 최소제곱법 선형회귀분석
lm(CO2_ppm ~ ., data=df_ghgs[, 3:9])  

# 10) 비선형(비모수적) 방법- 평활법: LOESS
# 산점도로 CO2_ppm와 CH4_ppm의 관계및 분포확인
df_ghgs %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_point()

# LOESS를 사용한 비선형 회귀분석
ghgs_lo <- loess(CH4_ppm ~ CO2_ppm, data=df_ghgs)
ghgs_lo

# 비선형 회귀분석의 예측선 시각화: 산점도에 geom_smooth() 추가
df_ghgs %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_point() + geom_smooth()


#-----
# 05-006. 2개의 수량형 변수 분석 - 범주형 변수:x , 수량형 변수:y
# 자동차 연비 데이터 사용 - 구동방식(drv)과 고속도로주행연비(hwy) 분석

# 1) 데이터로드 및 파악
# 데이터로드
library(ggplot2)
df_mpg <- mpg

# 데이터 파악
head(df_mpg)
tail(df_mpg)
str(df_mpg)
names(df_mpg)

# 2) 통계량, 빈도표 확인
# 전체 요약통계량
summary(df_mpg)

# 구동방식별 빈도표
table(df_mpg$drv)

# 고속도로 주행연비 요약통계량
summary(df_mpg$ hwy)

# 3) 데이터 형태파악을 위한 시각화
df_mpg %>% ggplot(aes(drv, hwy)) + geom_boxplot()

# 4) 분산분석 - lm(y ~ x)
hwy_lm <- lm(hwy ~ drv, data=df_mpg)
summary(hwy_lm)

# 5) 분산분석결과 진단 플롯
par(mfrow=c(2, 2))
plot(hwy_lm, las=1)
dev.off()


#----------------
# 11장 문제: 서울시 노령화지수 예측
# 1) 데이터 로드
df_os <- read.csv("data/2016-2020_seoul_gu_od.csv")
df_os

# 2) 데이터 파악
str(df_os)

# 3) 기본시각화
df_os %>% ggplot(aes(x = 기간, y = 노령화지수)) + geom_line() +
  geom_smooth(method='lm', formula=y~x)

# 4) 상관계수
cor(df_os$기간, df_os$노령화지수)

# 5) 단순 회귀분석 - lm()
os_lm <- lm(노령화지수 ~ 기간, data=df_os)

summary(os_lm)

# 6) 선형회귀 모형 예측
predict(os_lm)
resid(os_lm)

predict(os_lm, newdata=data.frame(기간=c(2021, 2022, 2023, 2024, 2025)))
predict(os_lm, newdata=data.frame(기간=c(2021, 2022, 2023, 2024, 2025)), se.fit=TRUE)

# 7) 노령화지수 관측치와 예측치를 합쳐서 시각화
df_od_1 <- df_os[, c(1, 4)]

r1 <- predict(os_lm, newdata=data.frame(기간=c(2021, 2022, 2023, 2024, 2025)))
r1

df_os_preict <- data.frame(기간=c(2021, 2022, 2023, 2024, 2025), 노령화지수=r1)
df_os_preict
df_od_p <- bind_rows(df_od_1, df_os_preict)
df_od_p

df_od_p %>% ggplot(aes(x = 기간, y = 노령화지수)) + geom_line() +
  geom_smooth(method='lm', formula=y~x)
