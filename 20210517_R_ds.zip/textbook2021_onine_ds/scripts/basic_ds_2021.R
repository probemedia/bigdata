## 1. 가설검정과 p값, 신뢰구간 ##

#(2) 가설검정과 p값

#1)대응표본 t-test : 하나의 집단에서 비교 - 코로나19사태 전과 후의 지하철 이용객수 차이
df_users <- read.csv("data/20200903_2019-2020년_월별지하철이용객수차이.csv")
df_users
sub_users <- df_users$diff_2020_2019
sub_users

summary(sub_users)
sd(sub_users)

par(mfrow=c(2, 2))  # 4개의 서브플롯
hist(sub_users)  # 히스토그램
boxplot(sub_users)
qqnorm(sub_users); qqline(sub_users)
hist(sub_users, prob=TRUE)
lines(density(sub_users), lty=3)

t.test(sub_users)

#2)독립표본 t-test : 서로 다른 두개의 그룹간의 평균비교 - 소형차와 suv차 간의 연비차이 비교
library(ggplot2)
library(dplyr)
df_mpg <- mpg
df_s_c <- df_mpg %>%
  filter(class %in% c('compact','suv')) %>%
  select(class, hwy)

df_s_c

table(df_s_c$class)
summary(df_s_c)
df_s_c %>% filter(class=='suv') %>% summary()
df_s_c %>% filter(class=='compact') %>% summary()

df_s_c %>% ggplot(aes(class, hwy)) + geom_boxplot()

t.test(data=df_s_c, hwy ~ class, var.equal=T)

## 3. 데이터타입에 따른 분석 기법  ##
df_ghgs <- read.csv("data/20180218_1999-2018년_월간_온실가스.csv")
df_ozone <- read.csv("data/ozone_data.csv")
library(readxl)
df_acr <- read_excel("data/20180217_2017년서울시구별노령화지수.xlsx")
df_accdata1 <- read_excel("data/20200423_2014-2016년_강남구accidentInfoList.xlsx")

# (2) 모든 데이터에 공통으로 수행하는 분석
# 1) 데이터 로드 및 데이터 파악
# 이산화탄소(CO2), 메탄(CH4) ,아산화질소(N2O), 염화불화탄소11(CFC11), 염화불화탄소12(CFC12), 염화불화탄소113(CFC113), 육불화황(SF6)

df_ghgs <- read.csv("data/20180218_1999-2018년_월간_온실가스.csv")
df_ghgs_new <- df_ghgs[, 2:9]
names(df_ghgs_new)
names(df_ghgs_new) <- c("관측일", "CO2_ppm", "CH4_ppm", "N2O_ppm", 
                        "CFC11_ppm", "CFC12_ppm","CFC113_ppm", "SF6_ppm")
names(df_ghgs_new)

head(df_ghgs_new)
tail(df_ghgs_new)
dim(df_ghgs_new)
str(df_ghgs_new)
glimpse(df_ghgs_new)

# 2) 데이터의 요약통계량, 빈도표 파악- 수량형데이터 요약통계 : summary(), 범주형데이터 빈도표: table()
summary(df_ghgs_new)

# 3)결측치 확인 : 결측치/이상치 처리
summary(df_ghgs_new)

# 4) 무조건 시각화함
pairs(df_ghgs_new[, 2:8])

# (3) 1개의 수량형 변수 분석
# 1) 데이터로드 및 파악
df_ozone <- read.csv("data/ozone_data.csv")
names(df_ozone)
head(df_ozone)
tail(df_ozone)
dim(df_ozone)
str(df_ozone)

# 2) 작업대상 변수 선택 및 통계량 확인
ozone_du <- df_ozone$평균오존전량.DU.
summary(ozone_du)
mean(ozone_du)
median(ozone_du)
range(ozone_du)
quantile(ozone_du)
quantile(ozone_du, prob=0.25) # q1
quantile(ozone_du, prob=0.75) # q3

# 3) 데이터 형태파악을 위한 시각화
par(mfrow=c(2, 2))
hist(ozone_du)
boxplot(ozone_du)
qqnorm(ozone_du); qqline(ozone_du)
hist(ozone_du, prob=TRUE)
lines(density(ozone_du), lty=3)

# 파일로 저장
png("plots/ozone.png", 5.5, 4, units='in', pointsize=9, res=600)
par(mfrow=c(2, 2))
hist(ozone_du)
boxplot(ozone_du)
qqnorm(ozone_du); qqline(ozone_du, col=2)
hist(ozone_du, prob=TRUE)
lines(density(ozone_du), lty=3)
dev.off()

# 시계열 그래프
df_ozone$일시 <- gsub(" ", "", paste(df_ozone$일시, "-01"))
df_ozone$일시
df_ozone$일시 <- as.Date(df_ozone$일시)
str(df_ozone)
df_ozone %>% ggplot(aes(일시, 평균오존전량.DU.)) + geom_line()

dev.off() # 2x2형태의 시각화 해제

# 4) 일변량 t-검정
t.test(ozone_du)

# 5) 이상치와 로버스트 통계방법
c(mean(ozone_du), sd(ozone_du))  # 평균, 표준편차
c(median(ozone_du), mad(ozone_du))  # 중앙값, mad

# (4) 1개의 범주형 변수 분석
# 1) 데이터로드 및 파악
df_c19 <- read.csv("data/20210331기준_서울시코로나퇴원현황.csv")
names(df_c19)
head(df_c19)
tail(df_c19)
dim(df_c19)
str(df_c19)
table(df_c19$status)
# 2) 작업대상 변수 선택 및 통계량 확인
df_c19 <- df_c19[, 2:3]
names(df_c19) <- c("no", "status")
names(df_c19)

fac_sta <- factor(df_c19$status, levels=c("no","yes"))  # 퇴원-yes, 퇴원아님-no
fac_sta
table(fac_sta)  # no, yes 범주에 해당하는 데이터의 수
prop.table(table(fac_sta))  # no, yes 범주에 해당하는 데이터의 비율

# 3) 데이터 형태파악을 위한 시각화
barplot(table(fac_sta))

df_c19 %>% ggplot(aes(x = status)) + geom_bar()

# 파일로 저장
g <- df_c19 %>% ggplot(aes(x = status)) + geom_bar()
ggsave("plots/c19status_hist.png", g, width=6, height=4, units='in', dpi=600)

# 4) 이항검정 binom.test()
len_yes = length(fac_sta[fac_sta=="yes"])
len_all = length(fac_sta)
binom.test(x=len_yes, n=len_all, p=0.5, alternative="two.sided")

# 5) 오차한계, 표본크기
pos = 0.9430965
n = 32230
x1 = as.integer(n * pos) * 100
diff_ci = 0.9456011 - 0.9405117
diff_ci
moe = diff_ci/2  # 오차한계
moe
binom.test(x=x1, n=n*100)

diff_ci2 = 0.9433492 - 0.9428430
diff_ci2/2  # 표본의크기가 100배 커진경우 오차한계

# (5) 2개의 변수 - 수량형 변수:x , 수량형 변수:y 분석
# 1) 데이터로드 및 파악
df_ghgs <- read.csv("data/20180218_1999-2018년_월간_온실가스.csv")
df_ghgs_new <- df_ghgs[, 2:9]
names(df_ghgs_new)
names(df_ghgs_new) <- c("관측일", "CO2_ppm", "CH4_ppm", "N2O_ppm", 
                        "CFC11_ppm", "CFC12_ppm","CFC113_ppm", "SF6_ppm")
names(df_ghgs_new)

head(df_ghgs_new)
tail(df_ghgs_new)
dim(df_ghgs_new)
str(df_ghgs_new)
summary(df_ghgs_new)

# 2) 작업대상 변수 선택 및 통계량 확인
summary(df_ghgs_new)
summary(df_ghgs_new$CO2_ppm)
summary(df_ghgs_new$CH4_ppm)

# 3) 데이터 형태파악을 위한 시각화
# 산점도 행렬
pairs(df_ghgs_new[, 2:8])

# 산점도
df_ghgs_new %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_point()

set.seed(2009)
df_ghgs_new %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_jitter()

# 단순 회귀 - 비선형 모형
df_ghgs_new %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_point() + geom_smooth()
# 단순 선형 모형
df_ghgs_new %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_point() + geom_smooth(method="lm")

# 4) 상관계수
cor(df_ghgs_new$CO2_ppm, df_ghgs_new$CH4_ppm, use="complete.obs")
cor(df_ghgs_new$CO2_ppm, df_ghgs_new$CH4_ppm, method="spearman", use="complete.obs")
cor(df_ghgs_new$CO2_ppm, df_ghgs_new$CH4_ppm, method="kendall", use="complete.obs")

# 5) 단순 회귀분석 - lm()
ghg_lm <- lm(CH4_ppm ~ CO2_ppm, data=df_ghgs_new)

summary(ghg_lm)

# 6) 모형 적합도 검정

# 7) 선형회귀 모형 예측
predict(ghg_lm)
resid(ghg_lm)

predict(ghg_lm, newdata=data.frame(CO2_ppm=c(420, 430, 440)))
predict(ghg_lm, newdata=data.frame(CO2_ppm=c(420, 430, 440)), se.fit=TRUE)

# 8) 선형회귀 모형의 가정 진단
class(ghg_lm)
par(mfrow=c(2, 2))
plot(ghg_lm, las=1)
plot(ghg_lm)

dev.off() # 2x2형태의 시각화 해제

# 9) 로버스트 선형회귀분석 - lqs()
library(MASS)  # lqs() 제공

set.seed(2009)
lqs(CO2_ppm ~ ., data=df_ghgs_new[, 2:8])  # 로버스트 선형 회귀분석
lm(CO2_ppm ~ ., data=df_ghgs_new[, 2:8])  # 최소제곱법

# 10) 비선형/비모수적 방법. 평활법과 LOESS
plot(CH4_ppm ~ CO2_ppm, data=df_ghgs_new)
ghgs_lo <- loess(CH4_ppm ~ CO2_ppm, data=df_ghgs_new)
ghgs_lo
summary(ghgs_lo)

df_ghgs_new %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_point() + geom_smooth()

# (6) 2개의 변수 - 범주형 변수:x , 수량형 변수:y 분석
# 1) 데이터로드 및 파악
df_mpg <- mpg
names(df_mpg)

head(df_mpg)
tail(df_mpg)
dim(df_mpg)
str(df_mpg)
summary(df_mpg)

# 2) 작업대상 변수 선택 및 통계량 확인
table(df_mpg$drv)
summary(df_mpg$cty)

# 3) 데이터 형태파악을 위한 시각화
df_mpg %>% ggplot(aes(drv, hwy)) + geom_boxplot()

# 4) 분산분석 - lm(y ~ x)
hwy_lm <- lm(hwy ~ drv, data=df_mpg)
summary(hwy_lm)

# 진단 플롯
par(mfrow=c(2, 2))
plot(hwy_lm, las=1)
