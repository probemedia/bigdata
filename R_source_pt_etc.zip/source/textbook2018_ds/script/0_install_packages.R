#내부망에서 package설치 


##1.install.packages("sqldf") #sqldf
install.packages("packages/sqldf_0.4-11.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/gsubfn_0.7.zip", repos = NULL)
install.packages("packages/proto_1.0.0.zip", repos = NULL)
install.packages("packages/chron_2.3-53.zip", repos = NULL)

##2.install.packages("gridExtra") #gridExtra
install.packages("packages/gridExtra_2.3.zip", repos = NULL)

##3.install.packages("gapminder") #gapminder
install.packages("packages/gapminder_0.3.0.zip", repos = NULL)

##4.install.packages(c( "ISLR", "MASS", "glmnet","randomForest", "gbm"))) #
install.packages("packages/iterators_1.0.12.zip", repos = NULL)
install.packages("packages/foreach_1.4.7.zip", repos = NULL)
install.packages("packages/gridExtra_2.3.zip", repos = NULL)
install.packages("packages/ISLR_1.2.zip", repos = NULL)
install.packages("packages/MASS_7.3-51.4.zip", repos = NULL)
install.packages("packages/glmnet_2.0-18.zip", repos = NULL)
install.packages("packages/randomForest_4.6-14.zip", repos = NULL)
install.packages("packages/gbm_2.1.5.zip", repos = NULL)


##5.install.packages("tidyverse") #tidyverse
install.packages("packages/tidyverse_1.2.1.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/generics_0.0.2.zip", repos = NULL)
install.packages("packages/selectr_0.4-1.zip", repos = NULL)
install.packages("packages/broom_0.5.2.zip", repos = NULL)
install.packages("packages/dbplyr_1.4.2.zip", repos = NULL)
install.packages("packages/lubridate_1.7.4.zip", repos = NULL)
install.packages("packages/modelr_0.1.5.zip", repos = NULL)
install.packages("packages/reprex_0.3.0.zip", repos = NULL)
install.packages("packages/rvest_0.3.4.zip", repos = NULL)

##6.install.packages("ROCR") #ROCR
install.packages("packages/ROCR_1.0-7.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/bitops_1.0-6.zip", repos = NULL)
install.packages("packages/gtools_3.8.1.zip", repos = NULL)
install.packages("packages/gdata_2.18.0.zip", repos = NULL)
install.packages("packages/caTools_1.17.1.2.zip", repos = NULL)
install.packages("packages/gplots_3.0.1.1.zip", repos = NULL)
