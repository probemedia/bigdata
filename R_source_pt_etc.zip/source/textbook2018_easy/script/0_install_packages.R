#내부망에서 package설치 
##1.install.packages. 업데이트 항목.


##2.install.packages("ggplot2")
install.packages("packages/ggplot2_3.2.1.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/backports_1.1.4.zip", repos = NULL)
install.packages("packages/ellipsis_0.2.0.1.zip", repos = NULL)
install.packages("packages/zeallot_0.1.0.zip", repos = NULL)
install.packages("packages/glue_1.3.1.zip", repos = NULL)
install.packages("packages/magrittr_1.5.zip", repos = NULL)
install.packages("packages/stringi_1.4.3.zip", repos = NULL)
install.packages("packages/colorspace_1.4-1.zip", repos = NULL)
install.packages("packages/askpass_1.1.zip", repos = NULL)
install.packages("packages/utf8_1.1.4.zip", repos = NULL)
install.packages("packages/vctrs_0.2.0.zip", repos = NULL)
install.packages("packages/plyr_1.8.4.zip", repos = NULL)
install.packages("packages/Rcpp_1.0.2.zip", repos = NULL)
install.packages("packages/stringr_1.4.0.zip", repos = NULL)
install.packages("packages/labeling_0.3.zip", repos = NULL)
install.packages("packages/munsell_0.5.0.zip", repos = NULL)
install.packages("packages/R6_2.4.0.zip", repos = NULL)
install.packages("packages/RColorBrewer_1.1-2.zip", repos = NULL)
install.packages("packages/cli_1.1.0.zip", repos = NULL)
install.packages("packages/crayon_1.3.4.zip", repos = NULL)
install.packages("packages/fansi_0.4.0.zip", repos = NULL)
install.packages("packages/pillar_1.4.2.zip", repos = NULL)
install.packages("packages/pkgconfig_2.0.2.zip", repos = NULL)
install.packages("packages/digest_0.6.20.zip", repos = NULL)
install.packages("packages/gtable_0.3.0.zip", repos = NULL)
install.packages("packages/lazyeval_0.2.2.zip", repos = NULL)
install.packages("packages/reshape2_1.4.3.zip", repos = NULL)
install.packages("packages/rlang_0.4.0.zip", repos = NULL)
install.packages("packages/scales_1.0.0.zip", repos = NULL)
install.packages("packages/tibble_2.1.3.zip", repos = NULL)
install.packages("packages/viridisLite_0.3.0.zip", repos = NULL)
install.packages("packages/withr_2.1.2.zip", repos = NULL)


##3.install.packages("readxl") # readxl 설치
install.packages("packages/readxl_1.3.1.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/rematch_1.0.1.zip", repos = NULL)
install.packages("packages/hms_0.5.0.zip", repos = NULL)
install.packages("packages/prettyunits_1.0.2.zip", repos = NULL)
install.packages("packages/cellranger_1.1.0.zip", repos = NULL)
install.packages("packages/progress_1.2.2.zip", repos = NULL)


##4.install.packages("dplyr")  # dplyr 설치
install.packages("packages/dplyr_0.8.3.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/purrr_0.3.2.zip", repos = NULL)
install.packages("packages/tidyselect_0.2.5.zip", repos = NULL)
install.packages("packages/BH_1.69.0-1.zip", repos = NULL)
install.packages("packages/plogr_0.2.0.zip", repos = NULL)


##5.install.packages("KoNLP")  # KoNLP 설치
install.packages("packages/KoNLP_0.80.1.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/sys_3.2.zip", repos = NULL)
install.packages("packages/ini_0.3.1.zip", repos = NULL)
install.packages("packages/ps_1.3.0.zip", repos = NULL)
install.packages("packages/askpass_1.1.zip", repos = NULL)
install.packages("packages/bit_1.1-14.zip", repos = NULL)
install.packages("packages/clipr_0.7.0.zip", repos = NULL)
install.packages("packages/clisymbols_1.2.0.zip", repos = NULL)
install.packages("packages/curl_4.0.zip", repos = NULL)
install.packages("packages/desc_1.2.0.zip", repos = NULL)
install.packages("packages/fs_1.3.1.zip", repos = NULL)
install.packages("packages/gh_1.0.1.zip", repos = NULL)
install.packages("packages/rprojroot_1.3-2.zip", repos = NULL)
install.packages("packages/whisker_0.3-2.zip", repos = NULL)
install.packages("packages/yaml_2.2.0.zip", repos = NULL)
install.packages("packages/processx_3.4.1.zip", repos = NULL)
install.packages("packages/mime_0.7.zip", repos = NULL)
install.packages("packages/openssl_1.4.1.zip", repos = NULL)
install.packages("packages/xopen_1.0.0.zip", repos = NULL)
install.packages("packages/brew_1.0-6.zip", repos = NULL)
install.packages("packages/commonmark_1.7.zip", repos = NULL)
install.packages("packages/xml2_1.2.2.zip", repos = NULL)
install.packages("packages/evaluate_0.14.zip", repos = NULL)
install.packages("packages/praise_1.0.0.zip", repos = NULL)
install.packages("packages/bit64_0.9-7.zip", repos = NULL)
install.packages("packages/blob_1.2.0.zip", repos = NULL)
install.packages("packages/DBI_1.0.0.zip", repos = NULL)
install.packages("packages/memoise_1.1.0.zip", repos = NULL)
install.packages("packages/usethis_1.5.1.zip", repos = NULL)
install.packages("packages/callr_3.3.1.zip", repos = NULL)
install.packages("packages/git2r_0.26.1.zip", repos = NULL)
install.packages("packages/httr_1.4.1.zip", repos = NULL)
install.packages("packages/jsonlite_1.6.zip", repos = NULL)
install.packages("packages/pkgbuild_1.0.4.zip", repos = NULL)
install.packages("packages/pkgload_1.0.2.zip", repos = NULL)
install.packages("packages/rcmdcheck_1.3.3.zip", repos = NULL)
install.packages("packages/remotes_2.1.0.zip", repos = NULL)
install.packages("packages/roxygen2_6.1.1.zip", repos = NULL)
install.packages("packages/rstudioapi_0.10.zip", repos = NULL)
install.packages("packages/sessioninfo_1.1.1.zip", repos = NULL)
install.packages("packages/testthat_2.2.1.zip", repos = NULL)
install.packages("packages/rJava_0.9-11.zip", repos = NULL)
install.packages("packages/hash_2.2.6.1.zip", repos = NULL)
install.packages("packages/tau_0.0-21.zip", repos = NULL)
install.packages("packages/Sejong_0.01.zip", repos = NULL)
install.packages("packages/RSQLite_2.1.2.zip", repos = NULL)
install.packages("packages/devtools_2.1.0.zip", repos = NULL)


##6.useNIADic()

#dependecy packages - 선수설치
install.packages("packages/knitr_1.24.zip", repos = NULL)
install.packages("packages/rmarkdown_1.14.zip", repos = NULL)
install.packages("packages/data.table_1.12.2.zip", repos = NULL)
install.packages("packages/highr_0.8.zip", repos = NULL)
install.packages("packages/markdown_1.1.zip", repos = NULL)
install.packages("packages/xfun_0.8.zip", repos = NULL)
install.packages("packages/htmltools_0.3.6.zip", repos = NULL)
install.packages("packages/base64enc_0.1-3.zip", repos = NULL)
install.packages("packages/tinytex_0.15.zip", repos = NULL)


##6-2.install.packages("wordcloud") 
install.packages("packages/wordcloud_2.6.zip", repos = NULL)
#dependecy packages - 선수설치

##7. install.packages("corrplot") # corrplot 설치
install.packages("packages/corrplot_0.84.zip", repos = NULL)

##8.install.packages("ggiraphExtra")  # ggiraphExtra 설치
install.packages("packages/ggiraphExtra_0.2.9.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/forcats_0.4.0.zip", repos = NULL)
install.packages("packages/readr_1.3.1.zip", repos = NULL)
install.packages("packages/farver_1.1.0.zip", repos = NULL)
install.packages("packages/zip_2.0.3.zip", repos = NULL)
install.packages("packages/uuid_0.1-2.zip", repos = NULL)
install.packages("packages/nortest_1.0-4.zip", repos = NULL)
install.packages("packages/htmlwidgets_1.3.zip", repos = NULL)
install.packages("packages/gdtools_0.1.9.zip", repos = NULL)
install.packages("packages/haven_2.1.1.zip", repos = NULL)
install.packages("packages/insight_0.4.1.zip", repos = NULL)
install.packages("packages/tweenr_1.0.1.zip", repos = NULL)
install.packages("packages/polyclip_1.10-0.zip", repos = NULL)
install.packages("packages/RcppEigen_0.3.3.5.0.zip", repos = NULL)
install.packages("packages/flextable_0.5.5.zip", repos = NULL)
install.packages("packages/officer_0.3.5.zip", repos = NULL)
install.packages("packages/moonBook_0.2.3.zip", repos = NULL)
install.packages("packages/ggiraph_0.6.1.zip", repos = NULL)
install.packages("packages/mycor_0.1.1.zip", repos = NULL)
install.packages("packages/ppcor_1.1.zip", repos = NULL)
install.packages("packages/sjlabelled_1.1.0.zip", repos = NULL)
install.packages("packages/sjmisc_2.8.1.zip", repos = NULL)
install.packages("packages/webshot_0.5.1.zip", repos = NULL)
install.packages("packages/tidyr_0.8.3.zip", repos = NULL)
install.packages("packages/ggforce_0.3.0.zip", repos = NULL)
install.packages("packages/ztable_0.2.0.zip", repos = NULL)

##9. install.packages("mapproj") # mapproj 설치
install.packages("packages/mapproj_1.2.6.zip", repos = NULL)

##10. install.packages("maps") # maps 설치
install.packages("packages/maps_3.3.0.zip", repos = NULL)

##11.install.packages("plotly")  # plotly 설치
install.packages("packages/plotly_4.9.0.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/httpuv_1.5.1.zip", repos = NULL)
install.packages("packages/xtable_1.8-4.zip", repos = NULL)
install.packages("packages/sourcetools_0.1.7.zip", repos = NULL)
install.packages("packages/later_0.8.0.zip", repos = NULL)
install.packages("packages/promises_1.0.1.zip", repos = NULL)
install.packages("packages/shiny_1.3.2.zip", repos = NULL)
install.packages("packages/tidyr_0.8.3.zip", repos = NULL)
install.packages("packages/hexbin_1.27.3.zip", repos = NULL)
install.packages("packages/crosstalk_1.0.0.zip", repos = NULL)

##12. install.packages("dygraphs")  # dygraphs 설치
install.packages("packages/dygraphs_1.1.1.6.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/zoo_1.8-6.zip", repos = NULL)
install.packages("packages/xts_0.11-2.zip", repos = NULL)




