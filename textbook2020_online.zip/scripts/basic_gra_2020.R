
### 1. R 기본 문법 ###

# 변수 선언
#변수 <- 값  : 권장 문법
#예)
x <- 5  # 숫자변수 선언과 값할당
x
data <- "aaa" #문자변수 선언과 값할당

# 변수 제거
#문법: remove(변수)  
remove(data)


# 대입 : 변수 <- 값
x <- 5
x
# 데이터 타입과 형변환

# 벡터 : 같은 타입의 여러개 값을 저장
# 1개 이상의 값을 저장(하는 변수). 같은 타입의 값을 나열

# 벡터를 만드는 방법 - c()함수 사용
# c(인수리스트)함수의 인수는 ,를 사용해서 나영 
# c(값1,값2,...)함수 사용 - 
c(1,2,3,4,5)
# 시작값:끝값 - 
1:5 
# seq(시작값, 끝값)함수 사용 - 
seq(1,5) 
#seq(시작값, 끝값,증분)함수 사용 - 
seq(1,5,2)

#벡터변수 : 벡터 값을 갖는 변수
datas <- c("a","b","c") #문자벡터를 datas변수에저장 
values <- 1:3 #숫자벡터를 values변수에 저장

# 벡터 원소 값 추출 : 벡터명[원소번호]
d <- c("a","b","c","d","e")
d
#벡터명[시작원소번호:끝원소번호]
d[1:3]
d[2:4]
#벡터명[c(원소번호1, 원소번호2, ...)]
d[c(1,3)] 
d[c(2,5)] 
#데이터프레임 : data.frame()
#여러 타입의 값이 나열된 2차원 데이터

#직접만들기
#문법: 변수명 <- data.frame(변수1=값목록1, 변수2=값목록2, ...)
a <- data.frame(x=c(1,3,5), y=c(2,4,6))
a
#외부데이터(정형데이터)파일을 읽으면(read) => 데이터프레임이 만들어짐
# 텍스트파일로부터 데이터프레임 작성:read.table()
mydata <- read.table("data/data01.txt", header=TRUE, sep="")
mydata
# csv파일로부터 데이터프레임 작성: read.csv()
mydata2 <- read.csv("data/data01.csv", head=T)
mydata2
read.csv("data/data02.csv", head=F)  # 헤더없는 csv읽기. names(df)<-c(필드명 나열)

# 엑셀파일로부터 데이터프레임 작성: read_excel()
#선수: 
install.packages("readxl")
library(readxl)
mydata3 <- read_excel("data/20180217_2017년서울시구별노령화지수.xlsx")
mydata3
# 필드명 제외하고 불러오기
df_ex <- read_excel("data/20180217_2017년서울시구별노령화지수.xlsx",
                    col_names=F)
df_ex
df_ex2 <- read_excel("data/20200426_excel_test.xlsx", sheet=2)
df_ex2
df_ex3 <- read_excel("data/20200426_excel_test.xlsx", sheet="2017년3분기_서울시구별인구수")
df_ex3
#데이터 로드 및 저장
#파일 로드: read.xxx()메소드 사용
#txt파일 로드 : 정형데이터 - 데이터프레임 형식으로 읽어옴
mydata2 <- read.table("data/2017년3분기_서울시구별인구수.txt", header=TRUE, sep = "")
mydata2
# txt파일 로드 : 비정형데이터
mydata3 <- readLines("text/news2.txt", encoding = "UTF-8")
mydata3

#csv파일 로드 :정형데이터 - 데이터프레임 형식으로 읽어옴
x2 <- read.csv("data/data01.csv", head = T)
x2

#참고: 용량이 큰 CSV파일 읽기 - fread()함수 사용
read.csv("data/20190309_very_big.csv")

# install.packages("data.table")
library(data.table) #경우에따라 생략가능
fread("data/20190309_very_big.csv")

DT <- fread("data/20190309_very_big.csv") #읽은 파일을 data.table형식으로 저장
#읽은 파일을 데이터프레임(data.frame)형식으로 저장. data.table=FALSE 옵션사용
DT <- fread("data/20190309_very_big.csv", data.table=FALSE) #데이터프레임
head(DT)

#xls파일 로드 - read.table()로 읽을 수 없음.
#엑셀파일 로드 : xlsx패키지의 read_excel()메소드 사용
mydata4 <- read_excel("data/20180218_2016년_범죄분류별건수.xlsx")
mydata4

#파일 저장 : write.xxx()메소드 사용
oildata <- read.table("http://people.stat.sc.edu/habing/courses/data/oildata.txt", header = TRUE)
oildata
oildata <- read.table("data/oildata.txt", header = TRUE)
oildata
# txt파일로 저장 : 정형데이터
#정형데이터일때는 데이터프레임형식을 파일로 저장
write.table(oildata, "data/oildata.txt", quote = FALSE, append = FALSE)

#txt파일로 저장 : 비정형데이터
write(mydata3, "text/datas.txt")

# csv파일로 저장
#oildata변수의 내용을 data폴더안에 data.csv파일로 저장
write.csv(oildata,"data/data.csv", row.names = TRUE)

#xls파일로 저장 : 엑셀파일로 저장 - 단, oildata2.xlsx는 안 됨.
#sep="\t"이 옵션을 사용해야만 각 셀에 값이 들어감
write.table(oildata,"data/oildata2.xls", sep="\t")

#rvest 패키지를 사용한 검색 데이터 수집

install.packages("selectr")
install.packages("xml2")
install.packages("rvest")

library(xml2)
library(rvest)
library(stringr)
library(dplyr)
pops <- read_html("https://en.wikipedia.org/wiki/World_population")
pops

wp <- pops %>% html_nodes(".wikitable")
wp
df_wp_raw <- as.data.frame(wp[3] %>% html_table())
df_wp_raw
class(df_wp_raw)
df_wp_raw[c(1:5)]
write.csv(df_wp_raw[c(1:5)],'data/pop.csv') # 파일저장 후 엑셀에서 열어서 손봄
# 파일저장 후 엑셀에서 열어서 처리한 파일 pop1.csv
df_wp <- read.csv('data/pop1.csv')
df_wp

#그래픽스 - 플롯(plot, 작도)
x <- 1:10 
y <- 1:10
plot(x,y)


### 2.전처리 ### 
install.packages("dplyr")
install.packages("ggplot2")

library(dplyr) 
library(ggplot2)

df_mpg <- mpg
df_mpg
head(df_mpg)  # 데이터프레임의 위쪽 데이터 6개 확인
tail(df_mpg)  # 데이터프레임의 위쪽 데이터 6개 확인
dim(df_mpg)  # 데이터프레임의 차원 확인 
str(df_mpg)  # 데이터프레임의 각 변수의 속성 확인
summary(df_mpg)  # 요약 통계량 확인

glimpse(df_mpg)  # 데이터프레임의 차원 확인 
tbl_df(df_mpg)  # 많은 양의 데이터를 가진 데이터프레임을 다룰때 사용 
df_mpg
df_mpg %>% 
  head

# filter(조건) : 조건을 만족하는 데이터 추출
df_mpg %>%
  filter(class == "compact")

df_mpg %>%
  filter(hwy >= 30)  # 고속도로연비가 모두 30이상

df_mpg %>%
  filter(hwy >= 30 & cty >= 30)  # 고속도로연비와 도시연비가 모두 30이상

df_mpg %>%   # class가  "pickup" 이거나 "suv"인 경우
  filter(class == "pickup" | class == "suv")

df_mpg %>%  # class가  "pickup" 이거나 "suv"이거나 "2seater"인 경우
  filter(class == "pickup" | class == "suv" | class == "2seater")

df_mpg %>%  # class가  "pickup" 이거나 "suv"이거나 "2seater"인 경우
  filter(class %in% c("pickup", "suv", "2seater"))

df_mpg %>% 
  filter(class == "pickup" | class == "suv") %>%
  head

# select(변수명1,변수명2,..) : 지정한 변수만 추출
df_mpg %>% 
  select(drv, cty, hwy)

df_mpg1 <- df_mpg %>% select(drv, cty, hwy)

df_mpg %>% 
  filter(class == "pickup" | class == "suv") %>% 
  select(drv, cty, hwy)

df_mpg %>% 
  filter(class == "compact") %>% 
  select(drv, cty, hwy) %>% 
  head(10)

# arrange(변수명) : 지정한 변수로 오름차순 정렬
# arrange(desc(변수명)) 또는 arrange(-변수명) : 지정한 변수로 내림차순 정렬
df_mpg %>% 
  arrange(model)

df_mpg %>% 
  arrange(desc(hwy))

df_mpg %>% 
  arrange(-cyl)

df_mpg %>% 
  arrange(class, -cty) %>%
  head(10)


install.packages("gapminder")
library(gapminder)

df_gap <- gapminder
df_gap
head(df_gap)
tail(df_gap)
dim(df_gap)
str(df_gap)
summary(df_gap)
names(df_gap)

df_gap %>%
  filter(country == "Korea, Rep.")

df_gap %>%
  filter(country == "Korea, Rep." | country == "Korea, Dem. Rep.")
install.packages("stringr")
library(stringr)

df_gap %>%  # str_detect() : 원소별 패턴검사
  filter(str_detect(country, "Korea"))

df_gap %>%
  filter(str_detect(country, "Korea") & year < 1990) %>%
  arrange(year)

# mutate(새변수=계산식,...) : 계산식을 사용해서 새변수(파생변수) 생성
df_gap %>%
  mutate(gdp = pop * gdpPercap) %>%
  head
# 한국("Korea, Rep.")데이터만 추출 후 년도별 한국평균1인당gdp차이를 계산
df_gap %>%
  filter(country == "Korea, Rep.") %>%
  mutate(diff_gdpPercap_mean = mean(gdpPercap) - gdpPercap)
  
df_mpg %>% 
  mutate(drv=factor(drv, levels=c("f", "r", "4"))) %>%
  arrange(drv) %>%
  head(20)

# summarize(요약통계변수 = 요약통계함수(),...) : 요약 통계량
df_gap %>%
  summarize(n_data=n(), # 전체 데이터 수
            median_lifeExp=median(lifeExp), # 전체 기대수명 중위수 
            mean_lifeExp=mean(lifeExp), # 전체 기대수명 평균 
            median_gdpPercap=median(gdpPercap), # 전체 1인당gdp 중위수
            mean_gdpPercap=mean(gdpPercap)) # 전체 1인당gdp 평균

# group_by(그룹화변수,...) : 그룹화
df_gap1 <- df_gap %>%
  group_by(continent) %>% 
  summarize(n_country=n(), # 대륙별 데이터 수
            median_lifeExp=median(lifeExp), # 대륙별 기대수명 중위수 
            mean_lifeExp=mean(lifeExp), # 대륙별 기대수명 평균 
            median_gdpPercap=median(gdpPercap), # 대륙별 1인당gdp 중위수
            mean_gdpPercap=mean(gdpPercap)) # 대륙별 1인당gdp 평균

df_mpg %>%
  group_by(class, drv) %>%
  summarise(n_car=n(),
            mean_cty = mean(cty),
            mean_hwy = mean(hwy))

df_mpg %>%
  filter(class %in% c("compact", "subcompact")) %>%
  group_by(class, drv, model) %>%
  summarise(n_car=n(),
            mean_cty = mean(cty),
            mean_hwy = mean(hwy),
            maen_displ = mean(displ))

###
df_subway1 <- read.csv("data/20200423_202002_서울지하철승하차인원수.csv")
head(df_subway1)
tail(df_subway1)
dim(df_subway1)
str(df_subway1)

df1 <- df_subway1 %>%
  group_by(노선명) %>%
  summarise(feb_승차총수=sum(승차총승객수),
            feb_하차총수=sum(하차총승객수))
df_subway1 %>%
  group_by(노선명) %>%
  summarise(feb_승차총수=sum(승차총승객수),
            feb_하차총수=sum(하차총승객수)) %>%
  arrange(-feb_하차총수) %>%
  head

df_subway2 <- read.csv("data/20200423_202003_서울지하철승하차인원수.csv")
df2 <- df_subway2 %>%
  group_by(노선명) %>%
  summarise(mar_승차총수=sum(승차총승객수),
            mar_하차총수=sum(하차총승객수))

# left_join(df1, df2, by=키변수) : 키변수를 기준으로 df1과 df2의 변수를 합친 
# 새로운 데이터프레임 생성

df_join <- left_join(df1, df2, by="노선명") 
df_join

###
library(readxl)
df_accdata1 <- read_excel("data/20200423_2014-2016년_강남구accidentInfoList.xlsx")
df_accdata2 <- read_excel("data/20200423_2014-2016년_구리시accidentInfoList.xlsx")
head(df_accdata1)
head(df_accdata2)

# bind_rows(df1, df2) : df1과 df2의 변수를 합친 새로운 데이터프레임 생성
df_accdata <- bind_rows(df_accdata1, df_accdata2)
df_accdata
### 결측치, 이상치 처리
df_ghgs <- read.csv("data/20180218_1999-2018년_월간_온실가스.csv")

df_ghgs_new <- df_ghgs[, 2:9]
names(df_ghgs_new)
names(df_ghgs_new) <- c("관측일", "CO2_ppm", "CH4_ppm", "N2O_ppm", 
                        "CFC11_ppm", "CFC12_ppm","CFC113_ppm", "SF6_ppm")
names(df_ghgs_new)

head(df_ghgs_new)
tail(df_ghgs_new)
dim(df_ghgs_new)
str(df_ghgs_new)
summary(df_ghgs_new)

table(is.na(df_ghgs_new))

df_ch4 <- df_ghgs_new %>% select(관측일, CH4_ppm)
table(is.na(df_ch4["CH4_ppm"]))

df_ch4 %>% filter(!is.na(CH4_ppm))
summary(df_ch4)

df_ch4_m1 <- df_ch4
table(is.na(df_ch4_m1["CH4_ppm"]))
df_ch4_m1$CH4_ppm[is.na(df_ch4_m1$CH4_ppm)] = median(df_ch4_m1$CH4_ppm, na.rm=T)
table(is.na(df_ch4_m1["CH4_ppm"]))

head(df_ch4_m1)
summary(df_ch4_m1)

# 정상치 범위: 1810~1990
df_ch4_m1 <- ifelse(df_ch4_m1$CH4_ppm >= 1810 &  df_ch4_m1$CH4_ppm <= 1990,
                    df_ch4_m1$CH4_ppm, median(df_ch4_m1$CH4_ppm, na.rm=T))
summary(df_ch4_m1)

### 3.시각화 ###
library(dplyr) 
library(ggplot2)

install.packages("tidyverse")
library(tidyverse)
install.packages("gridExtra")
library(gridExtra)
install.packages("gapminder")
library(gapminder)

# ggplot2제공 데이터 - 설명  https://ggplot2.tidyverse.org/reference/ 참조
# ggplot2제공 주요 데이터
diamonds
economics
txhousing
mpg
presidential

# gapminder 제공 데이터
gapminder
df_gap <- gapminder

head(df_gap)
tail(df_gap)
glimpse(df_gap)  # str(df_gap)
summary(df_gap)

df_gap$lifeExp  # df_gap에서 lifeExp
df_gap["lifeExp"]  # df_gap에서 lifeExp
df_gap %>% select(lifeExp)

df_gap[c('lifeExp', 'gdpPercap')]
df_gap %>% select(lifeExp, gdpPercap)

# 요약통계량과 상관관계
summary(df_gap$lifeExp)  # summary(df_gap["lifeExp"])
summary(df_gap$gdpPercap)  # summary(df_gap["gdpPercap"])
cor(df_gap$lifeExp, df_gap$gdpPercap)  # cor(x, y), 기대수명과 1인당gdp
cor(df_ghgs_new$CO2_ppm, df_ghgs_new$CH4_ppm, use="complete.obs")
target <- c("lifeExp", "pop", "gdpPercap")
pairs(df_gap[,target])  # 산점도 행렬

df_eco <- economics
head(df_eco)
tail(df_eco)
glimpse(df_eco)
summary(df_eco)
cor(df_eco$pce, df_eco$psavert)  # 소비지출과 저축율
cor(df_eco$pce, df_eco$uempmed)  # 소비지출과 주당실업기간중위수
cor(df_eco$pce, df_eco$unemploy)  # 소비지출과 실업자수
pairs(df_eco[,2:6])  # 산점도 행렬

# 기본 플롯 파일로 저장
png("plots/eco_pairs.png", 5.5, 4, units='in', pointsize=9, res=600)
pairs(df_eco[,2:6])
dev.off()

df_mpg <- mpg
head(df_mpg)
tail(df_mpg)
glimpse(df_mpg)
summary(df_mpg)
cor(df_mpg$displ, df_mpg$cty)  # 배기량과 도시연비
cor(df_mpg$hwy, df_mpg$cty)  # 고속도로연비와 도시연비
# cor(df_ghgs_new$CO2_ppm, df_ghgs_new$CH4_ppm, use="complete.obs")

library(ggplot2)
library(dplyr)
# ggplot()함수  사용 시각화 방법1
#ggplot(data = 작업데이터, aes(x=x축에사용할변수, y=y축에사용할변수)) + 그래프추가
ggplot(data = df_mpg, aes(x=displ, y=cty)) + geom_point()

# ggplot()함수  사용 시각화 방법2
# 작업데이터 %>% ggplot(aes(x축에사용할변수,y축에사용할변수)) + 그래프추가
df_mpg %>% ggplot(aes(drv, hwy)) + geom_point(col='gray')
df_mpg %>% ggplot(aes(drv, hwy)) + geom_jitter(col='gray')
set.seed(1903)
df_mpg %>% ggplot(aes(drv, hwy)) + geom_jitter(col='gray') + geom_boxplot(alpha=.5)

# 수량형 변수 1개 : 히스토그램 geom_histogram()
df_gap %>% ggplot(aes(x=gdpPercap)) + geom_histogram()
df_gap %>% ggplot(aes(x=gdpPercap)) + geom_histogram(bins=50)
df_gap %>% ggplot(aes(x=gdpPercap)) + geom_histogram() + scale_x_log10()
df_gap %>% ggplot(aes(x=gdpPercap)) + geom_freqpoly() + scale_x_log10()
df_gap %>% ggplot(aes(x=gdpPercap)) + geom_density() + scale_x_log10()

library(gridExtra)
g1 <- df_gap %>% ggplot(aes(x=gdpPercap)) + geom_histogram()
g2 <- df_gap %>% ggplot(aes(x=gdpPercap)) + geom_histogram() + scale_x_log10()
g <- arrangeGrob(g1, g2, ncol=2)
ggsave("plots/gdpPercap_hist.png", g, width=6, height=2, units='in', dpi=600)


# 범주형 변수 1개 : 막대그래프 geom_bar()
df_mpg %>% ggplot(aes(x = class)) + geom_bar()

# 수량형 변수 2개 : 산점도 geom_point(), geom_jitter()
df_eco %>% ggplot(aes(uempmed, psavert)) + geom_point()
df_ghgs_new
names(df_ghgs_new)

df_ghgs_new %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_point() + geom_smooth(method='lm', formula=y~x)



df_ghgs_new %>% ggplot(aes(CO2_ppm, CH4_ppm)) + geom_point() +
  geom_smooth(method='lm', formula=y~x)

set.seed(1903)
df_eco %>% ggplot(aes(uempmed, psavert)) + geom_jitter()

df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point()
df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() + scale_x_log10()
df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() +
  scale_x_log10() + geom_smooth()
df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() +
  scale_x_log10() + geom_smooth(method='lm', formula=y~x)

g1 <- df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point()
g2 <- df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() + scale_x_log10()
g3 <- df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() +
  scale_x_log10() + geom_smooth()
g4 <- df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() +
  scale_x_log10() + geom_smooth(method='lm', formula=y~x)
g <- arrangeGrob(g1, g2, g3, g4, ncol=2)
ggsave("plots/gdpPercap_point.png", g, width=6, height=4, units='in', dpi=600)

# 수량형 변수 2개 : geom_hex()
install.packages("hexbin")
library(hexbin)
df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_hex() +
  scale_fill_gradient(name = "count", trans = "log")

df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_hex() + scale_x_log10() +
  scale_fill_gradient(name = "count", trans = "log", low="red", high="yellow")

# 수량형 변수 2개(x축 날짜데이터) : 시계열그래프 geom_line()
str(df_eco)
df_eco %>% ggplot(aes(date, psavert)) + geom_line()

# 시계열 그래프 여러개 그리기
gg_mul <- df_eco %>% ggplot(aes(date, psavert))
gg_mul + geom_line(color="blue") + geom_line(aes(date, uempmed), color="red")

df_rw <- read.csv("data/20180813_2016년 원전 방사성폐기물 발생현황_연도형식수정.csv")
df_rw
str(df_rw)
df_rw$연도 <- as.Date(df_rw$연도)
str(df_rw)

df_rw_vol <- df_rw %>% filter(구분 == "저장용량")
df_rw_vol
df_rw_st <- df_rw %>% filter(구분 == "저장실적")
df_rw_st
date_breaks <- seq(as.Date("2016-01-01"), as.Date("2016-11-01"), by="1 month")
date_breaks
date_breaks2 <- df_rw_st$연도
date_breaks2
df_rw_st %>% ggplot(aes(x = 연도, y = 고리)) + geom_line() + 
  scale_x_date(breaks=date_breaks2) +
  theme(axis.text.x = element_text(angle=30, hjust=1))

df_rw_st %>% ggplot(aes(x = 연도, y = 고리)) + geom_line() + 
  scale_x_date(breaks=date_breaks2) +
  theme(axis.text.x = element_text(angle=30, hjust=1)) +
  geom_smooth(method='lm', formula=y~x)

# 범주형변수 1개, 수량형 변수 1개 : 병렬상자그림 geom_boxplot()
df_mpg %>% ggplot(aes(drv, hwy)) + geom_boxplot()
df_mpg %>% ggplot(aes(class, cty)) + geom_boxplot() + geom_boxplot()
set.seed(1903)
df_mpg %>% ggplot(aes(class, cty)) + geom_jitter() + geom_boxplot(alpha=.5)

# 범주형변수 2개 : 모자익플롯 mosicplot()
mosaicplot(Titanic, main = "타이타닉 생존 데이터", color=TRUE)

xtabs(Freq ~ Class + Sex + Age + Survived, data.frame(Titanic))

# 상관행렬 히트맵 : corrplot
install.packages("corrplot")
library(corrplot)

df_eco_num <- df_eco[,c("pce","pop", "psavert", "uempmed", "unemploy")]
cor(df_eco_num)

df_eco_cor <- cor(df_eco_num)
round(df_eco_cor, 2)

corrplot(df_eco_cor)
corrplot(df_eco_cor, method="number")
