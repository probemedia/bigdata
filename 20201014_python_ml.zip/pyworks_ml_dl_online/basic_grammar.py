# -*- coding: utf-8 -*-
"""
Created on Sat May  2 11:06:06 2020

@author: KEO
"""

'''Basic Grammar'''

# %%
'''(1(.) 스크립트 구성순서'''
'''
# -*- coding: utf-8 -*-
"""
x + y + math.pow(x, y) 계산
"""

import math


def my_fun(x, y):  # my_fun()함수 정의
    return x + y + math.pow(x, y)


if __name__ == '__main__':
    x, y = 5.0, 3.0
    print("my_fun(x, y) = %d" % my_fun(x, y))

'''
# %%
'''(2) 변수'''
user_age = 0  # 숫자 변수 선언
user_name = '김씨'  # 문자 변수 선언
user_age = 22  # 변수값 변경
mylist = [1, 2, 'a']  # 리스트변수 선언
mytuple = (1, 2, 'a')  # 튜플변수 선언
mydic = {"id": "abcd", "jum": 80}  # 딕셔너리변수 선언
afunc = (lambda x, y: x * x + y)  # 함수

user_age, user_name = 30, "김씨"

5 > 9

# %%
'''(3) 파이썬의 데이터 타입과 포맷팅'''
user_age = 30
pi = 3.14
user_name = '철수'

a = 5
a = "test"

print("김" + "철수")
print(a * 3)

str(100) + "점"

# 포맷팅
"%d" % (123)
print("%d" % (123))
"%5d" % (123)
print("%5d" % (123))

"%f" % (1234.123)
print("%f" % (1234.123))
"%.2f" % (1234.123)
print("%.2f" % (1234.123))

"%s" % ("aaa하하하하")
print("%s" % ("aaa하하하하"))
"%5s" % ("aaa하하하하")
print("%5s" % ("aaa하하하하"))

'{0}'.format(123)
print('{0}'.format(123))
'{0:d}'.format(123)
print('{0:d}'.format(123))
'{0:d}, {1:.1f}'.format(123, 123.45)
print('{0:d}, {1:.1f}'.format(123, 123.45))

'이 %s 노트북 가격은 %d' % ("awesome", 200)
print('이 %s 노트북 가격은 %d' % ("awesome", 200))
'이 {0:s} 노트북 가격은 {1:d}'.format("awesome", 200)
print('이 {0:s} 노트북 가격은 {1:d}'.format("awesome", 200))

# 형변환 함수
int("123")
int(123.5)

float(123)
float("123")

str(123)
str(123.5)

zip(['Sunday', 'Monday', 'Tuesday'], range(3))

list(zip(['Sunday', 'Monday', 'Tuesday'], range(3)))
dict(zip(['Sunday', 'Monday', 'Tuesday'], range(3)))
tuple(zip(['Sunday', 'Monday', 'Tuesday'], range(3)))

# 타입확인 함수
a = 90
type(a)

alist = list(zip(['Sunday', 'Monday', 'Tuesday'], range(3)))
type(alist)

# %%
# (5) 리스트
data1 = [20, 22, 30]


# 함수목록을 값으로 갖는 리스트
def my_add(x, y):  # my_add()함수 정의
    return x + y


def a():
    return 1


x, y = 5.0, 6.0
fun_list = [my_add, a]  # 함수를 내용으로 갖는 리스트
fun_list[0](x, y)
fun_list[1]()


data1 = [20, 22, 30]
data1[2]
data1[2] = 25

mylist = [1, 99, 'name', [3, 4]]
mylist[-1]

data2 = [20, 22, 30, 25, 28]
print(data2[1:3])
print(data2[2:])
print(data2[:3])

data2.append(99)

data2.insert(3, 99)

del data2[1]

a = [1, 1, 2, 2, 3]
a.remove(3)
a.remove(1)

range(10)

mylist = [2*x*x for x in range(5)]
print(mylist)

data_list = [1, 2, 3, 4, 5, 6]
data2_list = [x*2 for x in data_list if x % 2 == 0]
print(data2_list)

a = [x * y + x for x, y in zip(range(10), range(1, 20, 2))]
print(a)

dates3 = [5, 15, 90]

for idx, val in enumerate(dates3):
    print(idx, val)
# %%
# (6) 튜플
weekdays = ("월", "화", "수", "목", "금", "토", "일")
print(weekdays[1])
# %%
# (7) 딕셔너리(사전)

users = {"id": "aaaa", "pass": "1234", "name": "홍길동"}
jum = {1: 100, 2: 200}

sys_dat = {'id': ('admin', 'root', 'dba'),
           'pass': ('1111', '2222', '3333'),
           'roll': (1, 2, 3)}

print(users["id"])
print(jum[1])
print(sys_dat['roll'])

users["id"] = "abcd"
print(users)

jum[1] = 300
print(jum)

users["jum"] = 100
print(users)

dict3 = {5: 100, 15: 50, 90: 300}

for key, val in dict3.items():
    print(key, val)

dict3_keys = dict3.keys()
type(dict3_keys)

dict3[100] = 500
dict3_keys
tuple(dict3_keys)

# keys()함수 응용
admins = {'admin': '1111', 'root': '3333', 'dba': '2222'}
admins.keys()
admins_key = tuple(admins.keys())
admins_key
admins['abcd'] = '1234'
admins.keys()
# %%
# (8) 제어문
# 1) 조건문
jum = 90
if jum >= 90:
    result = "지옥훈련"
else:
    result = ""

print(result)

rank_jum = 79
if rank_jum >= 90:
    rank = "골드"
elif rank_jum >= 70:
    rank = "실버"
else:
    rank = "브론즈"

print(rank)

data_int = int(input("값 입력:"))
num = 12 if data_int == 10 else 13
print(num)

# 2) for
list_leagues = ['LCK', 'LPL', 'LEC', 'LCS']

for my_league in list_leagues:
    print(my_league)

sys_dat = {'id': ('admin', 'root', 'dba'),
           'pass': ('1111', '2222', '3333'),
           'roll': (1, 2, 3)}
for key, val in sys_dat.items():
    print(key, val)

for i in range(1, 10):
    print(i, end=' ')  # 1줄에 모든 항목이 출력

# while
c = 5

while c > 0:
    print("c = ", c)
    c -= 1

j = 1
for i in range(5):
    j = j * 2
    if j == 8:
        break
    print('i = ', i, ', j = ', j)

j = 1
for i in range(5):
    j = j * 2
    if j == 8:
        continue
    print('i = ', i, ', j = ', j)

# try-except
try:
    answer = 1 / 0
    print(answer)
except ZeroDivisionError:
    print("오류발생")
    
# 4) with
with open('Khalani.txt', 'r') as f:
    print(f.readlines())

with open('bearlist.txt', 'w') as f:
    f.write("4 o'clock\nscenery\nwinter bear\nsweet night\n")

# %%
# (9) 함수와 모듈


def my_add(a, b):
    return a + b


x = int(input("정수값 입력1 :"))
y = int(input("정수값 입2 :"))
ans = my_add(x, y)
print(ans)


def func_varg(x, y, *args, **kwargs):
    print(x, y, args, kwargs)


func_varg(7, 'key', 5, 31.4, v=2, h='test')


var1 = 10


def test():
    var1 = 20
    print(var1)


test()
print(var1)

mylamf = (lambda x, y: x * x + y)
mylamf(10, 5)

# %%
import random
print(random.randrange(1,10))

import random as r
print(r.randrange(1,10))

from random import randrange
print(randrange(1,10))

# %%
from lib_test import my_mul, my_val
val1 = int(input("값1 입력 :"))
val2 = int(input("값2 입력 :"))
print(my_mul(val1, val2) + my_val())

# %%
# (10) 클래스


class Member(object):
    def __init__(self, id, passd, name):
        self.id = id
        self.passd = passd
        self.name = name

    def getMember(self):
        return self.id + ', ' + self.passd + ', ' + self.name


my_member = Member('kingdora', '123456', '김대붕')
my_member.getMember()
my_member.id
# %%


class Car():
    def __init__(self, displ, drv):
        self.__displ = displ
        self.__drv = drv

    def move(self, speed):
        print("자동차 이동 속도 : 시속 {0}km".format(speed))

    def info(self):
        print("자동차 정보 : ({0}, {1}구동)".format(self.__displ, self.__drv))


car1 = Car(3000, '4륜')
car1.info()
# car1.__displ

# %%
# %timeit i=1;i+=1
# %timeit i=1;i=i+1

# %%
# 입출력
with open('bearlist.txt', 'r') as f:
    for line in f:           
        print(line)  # print(line, end='')

with open('data/ozone_data.csv', 'r') as f:  
    for line in f:           
        print(line)  # print(line, end='')

import pandas as pd
df = pd.read_csv("data/ozone_data.csv", encoding="cp949")
print(df)
# %%
with open('cover_s.png', 'rb') as f1, open('cover_s_copy.png', 'wb') as f2:
    for line in f1:
        f2.write(line)
# %%
with open('cover_s.png', 'rb') as f:
    for line in f:
        print(line)
# %%