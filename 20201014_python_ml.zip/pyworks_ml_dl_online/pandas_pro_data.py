# -*- coding: utf-8 -*-
"""
Created on Tue May 12 09:39:42 2020

@author: KEO
"""
import pandas as pd
# %%
# (1) 변수(필드)추출
df1 = pd.read_excel('data/20200426_excel_test.xlsx', sheet_name=0)
df1
df1.columns
df1.values

df1['자치구']
df1[['자치구', '인구수']]

df1.loc[:, :]
df1.loc[:, '자치구']
df1.loc[:, ['자치구', '인구수']]
df1.loc[:, '자치구':'인구수']

df1.iloc[:, :]
df1.iloc[:, 0]
df1.iloc[:, 0:2]
df1.iloc[:, [0, 2]]
# %%
# (2)값 1개 추출
df1
df1.at[5, '인구수']

df1_1 = df1.set_index('자치구')
df1_1
df1_1.at['동대문구', '인구수']

df1_1 = df1_1.reset_index()
df1_1
# %%
# (3) 인덱스 지정과 복귀

df_oz = pd.read_csv('data/ozone_data.csv', encoding="cp949")
df_oz.columns
df_oz1 = df_oz[['일시', '평균오존전량(DU)']]
df_oz1 = df_oz1.set_index('일시')
df_oz1 = df_oz1.reset_index()
df_oz1
# %%
# (4)새 필드 추가 : 파생변수 생성
df1_pop = df1
df1_pop.head()
df1_pop['세대당인구수'] = df1_pop['인구수'] / df1_pop['세대수']
df1_pop.head()
df1_pop['여자인구수_대비_남자인구수비율'] = \
  df1_pop['남자인구수'] / df1_pop['여자인구수']
df1_pop.head()


# %%
# (5) 필터링 - 데이터추출
df_ol = pd.read_excel('data/20180217_2017년서울시구별노령화지수.xlsx')
df_ol
df_ol2 = df_ol.iloc[1:, 1:]
df_ol2
df_ol2[df_ol2['노령화지수'] < 100]
df_ol2[df_ol2['노령화지수'] >= 150]

df_ol_new = pd.read_excel('data/20191006_2018_서울시_자치구별_노령화지수.xlsx')
df_ol_new
df_ol_new2 = df_ol_new.iloc[1:, :]
df_ol_new2

df_ol_joined = df_ol2.set_index('자치구').join(df_ol_new2.set_index('구분'))
df_ol_joined.reset_index(inplace=True)
# %%
# (7) 변수명 변경 : rename()
df_ol_joined.rename(
        columns={'합계': '노령화지수_2018평균', '남자': '남자노령화지수_2018',
                 '여자': '여자노령화지수_2018'}, inplace=True)
df_ol_joined
# %%
# (8) 바인딩: append()함수, concat()함수
df_subway2 = pd.read_csv("data/20200423_202002_서울지하철승하차인원수.csv",
                         encoding='cp949', engine="python")
df_subway2.shape

df_subway3 = pd.read_csv("data/20200423_202003_서울지하철승하차인원수.csv",
                         encoding='cp949', engine="python")
df_subway3.shape

# append()함수
df_subway_new = df_subway2.append(df_subway3, ignore_index=True)
df_subway_new.shape

# concat()함수 - 데이터 결합
df_subway_new2 = pd.concat([df_subway2, df_subway3], ignore_index=True)
df_subway_new2.shape

# concat()함수 - 변수 결합
df_subway_joined2 = pd.concat([df_ol2, df_ol_new2], axis=1, join='inner')
df_subway_joined2

df_subway2['노선명'].value_counts()
df_subway2.노선명.value_counts()
pd.crosstab(df_subway2['노선명'], df_subway2['역명'])
# %%
# (9) 그룹화 : groupby()
df_subway_new.columns
df_subway_new['하차총승객수'].sum()
df_subway_groupby = df_subway_new.groupby('노선명').sum()
df_subway_groupby
df_subway_groupby.shape

df_subway_groupby['하차총승객수'].plot(kind='bar', rot=45, figsize=(12, 7))
df_subway_groupby['하차총승객수'].plot(kind='pie', figsize=(10, 10))

# %%
# 7. pandas 결측치 처리
# (1) NaN을 처리하는 메소드
df = pd.read_csv("data/20200511_ghg.csv", encoding='cp949')

df.columns
df.info()
df["CH4_ppm"].count()
df["CH4_ppm"].dropna()

df["CH4_ppm"].fillna(0)
df["CH4_ppm"].fillna(method='ffill')
df["CH4_ppm"].fillna(method='bfill')

df["CH4_ppm"].isnull().sum()
df["CH4_ppm"].notnull().sum()

# (2) 결측치 처리
df_air = df[['시간', 'CO2_ppm', 'CH4_ppm']]
df_air[df_air['CH4_ppm'].notnull()]


df.describe()
df_air2 = df.fillna(method='bfill')
df_air2.describe()

# (3) 이상치 처리
df_air2["CO2_ppm"]
co2_q1 = df_air2["CO2_ppm"].quantile(0.25)
co2_q3 = df_air2["CO2_ppm"].quantile(0.75)

co2_nm_min = co2_q1 - (co2_q3 - co2_q1) * 1.5
co2_nm_max = co2_q3 + (co2_q3 - co2_q1) * 1.5

df[df["CO2_ppm"] >= co2_nm_min]
df[df["CO2_ppm"] <= co2_nm_max]
df[(df["CO2_ppm"] >= co2_nm_min) & (df["CO2_ppm"] <= co2_nm_max)]
