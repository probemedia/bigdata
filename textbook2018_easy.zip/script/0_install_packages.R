#내부망에서 package설치 
##1.install.packages. 업데이트 항목.
install.packages("packages/git2r_0.22.1.zip", repos = NULL)
install.packages("packages/httpuv_1.4.4.2.zip", repos = NULL)
install.packages("packages/stringi_1.1.7.zip", repos = NULL)
install.packages("packages/xfun_0.3.zip", repos = NULL)
install.packages("packages/survival_2.42-4.zip", repos = NULL)
install.packages("packages/tinytex_0.6.zip", repos = NULL)
install.packages("packages/dygraphs_1.1.1.6.tar.gz", repos = NULL)

##2. install.packages("ggplot2")
install.packages("packages/ggplot2_3.0.0.tar.gz", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/glue_1.2.0.zip", repos = NULL)
install.packages("packages/magrittr_1.5.zip", repos = NULL)
install.packages("packages/stringi_1.1.7.zip", repos = NULL)
install.packages("packages/colorspace_1.3-2.zip", repos = NULL)
install.packages("packages/assertthat_0.2.0.zip", repos = NULL)
install.packages("packages/utf8_1.1.4.zip", repos = NULL)
install.packages("packages/Rcpp_0.12.17.zip", repos = NULL)
install.packages("packages/stringr_1.3.1.zip", repos = NULL)
install.packages("packages/RColorBrewer_1.1-2.zip", repos = NULL)
install.packages("packages/dichromat_2.0-0.zip", repos = NULL)
install.packages("packages/munsell_0.5.0.zip", repos = NULL)
install.packages("packages/labeling_0.3.zip", repos = NULL)
install.packages("packages/R6_2.2.2.zip", repos = NULL)
install.packages("packages/cli_1.0.0.zip", repos = NULL)
install.packages("packages/crayon_1.3.4.zip", repos = NULL)
install.packages("packages/pillar_1.2.3.zip", repos = NULL)
install.packages("packages/digest_0.6.15.zip", repos = NULL)
install.packages("packages/gtable_0.2.0.zip", repos = NULL)
install.packages("packages/lazyeval_0.2.1.zip", repos = NULL)
install.packages("packages/plyr_1.8.4.zip", repos = NULL)
install.packages("packages/reshape2_1.4.3.zip", repos = NULL)
install.packages("packages/rlang_0.2.1.zip", repos = NULL)
install.packages("packages/scales_0.5.0.zip", repos = NULL)
install.packages("packages/tibble_1.4.2.zip", repos = NULL)
install.packages("packages/viridisLite_0.3.0.zip", repos = NULL)
install.packages("packages/withr_2.1.2.zip", repos = NULL)

##3.install.packages("readxl") # readxl 설치
install.packages("packages/readxl_1.1.0.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/rematch_1.0.1.zip", repos = NULL)
install.packages("packages/cellranger_1.1.0.zip", repos = NULL)

##4.install.packages("dplyr")  # dplyr 설치
install.packages("packages/dplyr_0.7.6.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/bindr_0.1.1.zip", repos = NULL)
install.packages("packages/purrr_0.2.5.zip", repos = NULL)
install.packages("packages/bindrcpp_0.2.2.zip", repos = NULL)
install.packages("packages/pkgconfig_2.0.1.zip", repos = NULL)
install.packages("packages/tidyselect_0.2.4.zip", repos = NULL)
install.packages("packages/BH_1.66.0-1.zip", repos = NULL)
install.packages("packages/plogr_0.2.0.zip", repos = NULL)

##5.install.packages("KoNLP")  # KoNLP 설치
install.packages("packages/KoNLP_0.80.1.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/bit_1.1-14.zip", repos = NULL)
install.packages("packages/prettyunits_1.0.2.zip", repos = NULL)
install.packages("packages/mime_0.5.zip", repos = NULL)
install.packages("packages/curl_3.2.zip", repos = NULL)
install.packages("packages/openssl_1.0.1.zip", repos = NULL)
install.packages("packages/bit64_0.9-7.zip", repos = NULL)
install.packages("packages/blob_1.1.1.zip", repos = NULL)
install.packages("packages/DBI_1.0.0.zip", repos = NULL)
install.packages("packages/memoise_1.1.0.zip", repos = NULL)
install.packages("packages/httr_1.3.1.zip", repos = NULL)
install.packages("packages/whisker_0.3-2.zip", repos = NULL)
install.packages("packages/rstudioapi_0.7.zip", repos = NULL)
install.packages("packages/jsonlite_1.5.zip", repos = NULL)
install.packages("packages/git2r_0.21.0.zip", repos = NULL)
install.packages("packages/rJava_0.9-10.zip", repos = NULL)
install.packages("packages/hash_2.2.6.zip", repos = NULL)
install.packages("packages/tau_0.0-20.zip", repos = NULL)
install.packages("packages/Sejong_0.01.zip", repos = NULL)
install.packages("packages/RSQLite_2.1.1.zip", repos = NULL)
install.packages("packages/devtools_1.13.6.zip", repos = NULL)

##6.useNIADic()

#dependecy packages - 선수설치
install.packages("packages/data.table_1.11.4.zip", repos = NULL)
install.packages("packages/evaluate_0.10.1.zip", repos = NULL)
install.packages("packages/highr_0.7.zip", repos = NULL)
install.packages("packages/markdown_0.8.zip", repos = NULL)
install.packages("packages/yaml_2.1.19.zip", repos = NULL)
install.packages("packages/knitr_1.20.zip", repos = NULL)
install.packages("packages/backports_1.1.2.zip", repos = NULL)
install.packages("packages/htmltools_0.3.6.zip", repos = NULL)
install.packages("packages/base64enc_0.1-3.zip", repos = NULL)
install.packages("packages/tinytex_0.5.zip", repos = NULL)
install.packages("packages/rmarkdown_1.10.zip", repos = NULL)

##6-2.install.packages("wordcloud") 
install.packages("packages/wordcloud_2.5.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/slam_0.1-43.zip", repos = NULL)

##7.install.packages("ggiraphExtra")  # ggiraphExtra 설치
install.packages("packages/ggiraphExtra_0.1.0.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/zip_1.0.0.zip", repos = NULL)
install.packages("packages/uuid_0.1-2.zip", repos = NULL)
install.packages("packages/officer_0.3.1.zip", repos = NULL)
install.packages("packages/gdtools_0.1.7.zip", repos = NULL)
install.packages("packages/htmlwidgets_1.2.zip", repos = NULL)
install.packages("packages/rvg_0.1.9.zip", repos = NULL)
install.packages("packages/xml2_1.2.0.zip", repos = NULL)
install.packages("packages/maps_3.3.0.zip", repos = NULL)
install.packages("packages/nortest_1.0-4.zip", repos = NULL)
install.packages("packages/ggiraph_0.4.3.zip", repos = NULL)
install.packages("packages/mycor_0.1.1.zip", repos = NULL)
install.packages("packages/XML_3.98-1.11.zip", repos = NULL)
install.packages("packages/mapproj_1.2.6.zip", repos = NULL)
install.packages("packages/moonBook_0.1.8.zip", repos = NULL)

##8.install.packages("plotly")  # plotly 설치
install.packages("packages/plotly_4.7.1.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/httpuv_1.4.4.1.zip", repos = NULL)
install.packages("packages/xtable_1.8-2.zip", repos = NULL)
install.packages("packages/sourcetools_0.1.7.zip", repos = NULL)
install.packages("packages/later_0.7.3.zip", repos = NULL)
install.packages("packages/promises_1.0.1.zip", repos = NULL)
install.packages("packages/shiny_1.1.0.zip", repos = NULL)
install.packages("packages/tidyr_0.8.1.zip", repos = NULL)
install.packages("packages/hexbin_1.27.2.zip", repos = NULL)
install.packages("packages/crosstalk_1.0.0.zip", repos = NULL)

##9. install.packages("dygraphs")  # dygraphs 설치
install.packages("packages/dygraphs_1.1.1.5.zip", repos = NULL)
#dependecy packages - 선수설치
install.packages("packages/zoo_1.8-2.zip", repos = NULL)
install.packages("packages/xts_0.10-2.zip", repos = NULL)

##10. install.packages("corrplot") # corrplot 설치
install.packages("packages/corrplot_0.84.zip", repos = NULL)


