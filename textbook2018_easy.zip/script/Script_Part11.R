#### 11-1 ####

## -------------------------------------------------------------------- ##
install.packages("ggiraphExtra")
#cran제공 ggiraphExtra패키지의 ggChoropleth()함수에서 에러발생시 github패키지 사용 
#devtools::install_github("cardiomoon/ggiraphExtra")
library(ggiraphExtra)
#library(ggiraph)
#library(maps)
#library(mapproj)

#USArrests:This data set contains statistics, in arrests per 100,000 residents for assault, murder, and rape in each of the 50 US states in 1973. Also given is the percent of the population living in urban areas.
#http://stat.ethz.ch/R-manual/R-devel/library/datasets/html/USArrests.html
str(USArrests)
head(USArrests)
summary(USArrests)
library(tibble)

crime <- rownames_to_column(USArrests, var = "state")
crime


crime$state <- tolower(crime$state)

str(crime)

library(ggplot2)
states_map <- map_data("state")
states_map
str(states_map)

ggChoropleth(data = crime,         # 지도에 표현할 데이터
             aes(fill = Murder,    # 색깔로 표현할 변수
                 map_id = state),  # 지역 기준 변수
             map = states_map)     # 지도 데이터

ggChoropleth(data = crime,         # 지도에 표현할 데이터
             aes(fill = Murder,    # 색깔로 표현할 변수
                 map_id = state),  # 지역 기준 변수
             map = states_map,     # 지도 데이터
             interactive = T)      # 인터랙티브


#### 11-2 ####안함

install.packages("stringi")

install.packages("devtools")
#raw.githubusercontent.com이 네트워크 차단된 경우, 허용하고 설치 후 다시 차단 
devtools::install_github("cardiomoon/kormaps2014")
library(kormaps2014)

options(encoding = "utf-8")

str(changeCode(korpop1))

library(dplyr)

korpop1 <- rename(korpop1,
                  pop = 총인구_명,
                  name = 행정구역별_읍면동)

str(changeCode(kormap1))

ggChoropleth(data = korpop1,       # 지도에 표현할 데이터
             aes(fill = pop,       # 색깔로 표현할 변수
                 map_id = code,    # 지역 기준 변수
                 tooltip = name),  # 지도 위에 표시할 지역명
             map = kormap1,        # 지도 데이터
           interactive = T)        # 인터랙티브

#devtools::install_github("cardiomoon/ggiraphExtra")를 설치한 경우 사용 
ggChoropleth(data = korpop1,       # 지도에 표현할 데이터
             aes(fill = pop,       # 색깔로 표현할 변수
                 map_id = code,    # 지역 기준 변수
                 tooltip = name),  # 지도 위에 표시할 지역명
             map = kormap1) # 지도 데이터
             

## -------------------------------------------------------------------- ##
str(changeCode(tbc))

ggChoropleth(data = tbc,           # 지도에 표현할 데이터
             aes(fill = NewPts,    # 색깔로 표현할 변수
                 map_id = code,    # 지역 기준 변수
                 tooltip = name),  # 지도 위에 표시할 지역명
             map = kormap1,        # 지도 데이터
             interactive = T)      # 인터랙티브

#devtools::install_github("cardiomoon/ggiraphExtra")를 설치한 경우 사용 
ggChoropleth(data = tbc,           # 지도에 표현할 데이터
             aes(fill = NewPts,    # 색깔로 표현할 변수
                 map_id = code,    # 지역 기준 변수
                 tooltip = name),  # 지도 위에 표시할 지역명
             map = kormap1)        # 지도 데이터
