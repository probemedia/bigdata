#rm_sample.Rmd 파일에서 [Kint]시 오류발생하면 사용 
install.packages("stringi")
library(stringi)

#rm_sample.Rmd 파일의 17라인 다음의 18~19라인에 추가
library(ggplot2)
qplot(data = mpg, x = drv, fill = drv)