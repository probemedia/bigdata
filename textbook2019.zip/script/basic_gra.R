#R 기본 문법

#가) 변수 선언
#문법:  변수 = 값
#변수 <- 값  :권장 문법
x <- 5  #숫자변수 선언과 값할당
data <- "aaa" #문자변수 선언과 값할당

#참고: R의 상수
#-상수목록: LETTERS, letters, month.abb, month.name, pi
#LETTERS(대문자로표현)
#letters(소문자로표현)
#month.abb(월이름 약어)
#month.name(월이름)
#pi(원주율)
LETTERS[1:5] #"A" "B" "C" "D" "E"

# 대입 : 변수 <- 값
# 2) 벡터 : 같은 타입의 여러개 값을 저장
#-> 1개이상의 값을 저장(하는 변수)
#-> 같은 타입의 값을 나열

#가) 벡터를 만드는 방법
#□ c(값1,값2,...)함수 사용
c(1,2,3,4,5)
#□ 시작값:끝값
1:5
#□ seq(시작값, 끝값)함수 사용
seq(1,5)

#나) 벡터변수 : 벡터값을 갖는 변수
datas <- c("a","b","c") #문자벡터를 datas변수에저장 
values <- 1:3 #숫자벡터를 values변수에 저장

#다) 벡터의 값
#- 벡터는 문자, 정수, 실수, 복소수(complex), 인자(factor), 날짜(date), 논리 타입을 값으로 가질 수 있음

#라) 벡터원소의 값 : 벡터명[원소번호]
#원소번호: 1   2   3   4   5
  d <- c("a","b","c","d","e")
d[2]  #=> "b"

#벡터명[시작원소번호:끝원소번호]
d <- c("a","b","c","d","e")
d[1:3]  #=> "a","b","c"

#3) 여러 개의 값 저장
#가) 벡터 : c()
#- 같은 타입의 값이 나열된 1차원 데이터
c(1,2,3,4,5)

#나) 리스트 : list()
#- 다른 타입의 값이 나열된 1차원 데이터
list(12.345,"sun", c(2,3),mean(seq(1:5)))

#다) 행렬 : matrix()
#- 같은 타입의 값이 나열된 2차원 데이터
matrix(1:20, nrow = 4, ncol = 5)

#라) 배열 : array()
#- 같은 타입의 값이 나열된 다차원 데이터
array(1:20, dim=c(4,5))
array(1:20, dim=c(4,4,3))

#마 )데이터프레임 : data.frame()
#-여러 타입의 값이 나열된 2차원 데이터. 필드(라벨)를 가짐
a <- data.frame(x=c(1,3,5), y=c(2,4,6))

#x y <=라벨
#1 2
#3 4
#5 6

#파일 경로
#0.현재 작업폴더(디렉터리)의 위치 확인
getwd()
#1. 절대경로
mydata <-read.table("c:/project/textbook2017/data/data01.txt",  header=TRUE, sep = "")
mydata
#2. 상대경로 
mydata <-read.table("data/data01.txt",  header=TRUE, sep = "")
mydata

#4) 데이터 타입
#가) 데이터 타입

#5) 함수 정의 및 사용
#가)사용자 정의
#방법:
#  함수명 <- function(인수리스트){
#    #함수내용
#  }
  
#  예:
myfun01 <- function(){
      return(1)
}
    
myfun02 <- function(x, y){
     return(x*y)
}
    
#방법: 함수명(인수리스트)
#예:
myfun01()
myfun02(5,6)

#6) 흐름제어
#- 프로그램의 흐름을 제어하는 구문으로 분기문과 반복문이 있음.
#가) if문 : 조건비교 분기문
#예시)
if(x>5){
  y <- 5
}else{
  y <- 10
}

#나) for문 : 조건비교 반복문
#예시)
for( i in 1:5){
  s <- s + i
}

#예) 여러 개의 텍스트문서에서 불필요한 단어를 공백("")으로 변환하는 작업을 반복처리(for문)
for(j in seq(docs)){ 
  docs[[j]] <- gsub("/", "", docs[[j]]) 
  docs[[j]] <- gsub("@", "", docs[[j]]) 
  docs[[j]] <- gsub("\\|", "", docs[[j]]) 
  docs[[j]] <- gsub("http", "", docs[[j]]) 
  ...
}

#7) 데이터 로드 및 저장
#가) 파일 로드: read.xxx()메소드 사용
#(1) txt파일 로드
#1)txt파일 로드 : 정형데이터 - 데이터프레임 형식으로 읽어오
mydata2 <-read.table("data/2014구별소계인구수.txt", header=TRUE, sep = "")
mydata2
#2)txt파일 로드 : 비정형데이터
mydata3 <- readLines("text/news2.txt", encoding = "UTF-8")
mydata3

#(2) csv파일 로드
x2 <-read.csv("data/data01.csv", head = T)
x2
#(3) xls파일 로드 - read.table()로 읽을 수 없음.
# 엑셀파일 로드 -책 353p(32bit), 354p(64bit)

install.packages("RODBC")#32bit
library(RODBC)
xlsData <- odbcConnectExcel("data/2014구별소계인구수.xls")
sqlTables(xlsData)
xlsSheet <- sqlQuery(xlsData, "select * from [구별인구수$]")   #구별인구수$A1:B4
odbcClose(xlsData)
xlsSheet

#나) 파일 저장 : write.xxx()메소드 사용옴
#정형데이터일때는 데이터프레임형식을 파일로 저장
oildata = read.table("http://people.stat.sc.edu/habing/courses/data/oildata.txt", header = TRUE)
oildata

#(1) txt파일로 저장
#1)txt파일로 저장 : 정형데이터
write.table(oildata,"data/oildata.txt", quote = FALSE, append = FALSE)

#2)txt파일로 저장 : 비정형데이터
write(mydata3,"text/datas.txt")

#(2) csv파일로 저장
write.csv(oildata,"data/data.csv", row.names = TRUE)

#(3) xls파일로 저장 : 엑셀파일로 저장 - 단, oildata2.xlsx는 안 됨.
write.table(oildata,"data/oildata2.xls", sep="\t")

#8) 그래픽스 - 플롯(plot, 작도)
#가) 그래프 작도 순서
#(1) 고수준 작도 함수 사용 : plot(), hist(), curve(), pie()..
#- 그래프를 작도하는 함수 : plot(x,y)
#(2) 저수준 작도 함수 사용 : 레이블, 타이틀 추가함수
#- 그래프의 모양을 꾸미는 함수
#예)
x <- 1:10 
y <- 1:10
plot(x,y)