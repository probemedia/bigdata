##R을 사용한 웹 데이터 수집
#read.table()을 사용한 웹 데이터 검색
oildata =
  read.table("http://people.stat.sc.edu/habing/courses/data/oildata.txt", header = TRUE)
oildata

#XML패키지를 사용한 검색 데이터 수집
#http://www.columbia.edu/~cjd11/charles_dimaggio/DIRE/styled-4/styled-6/code-13/
#Web Scraping
install.packages("XML")
library(XML)
srts<-htmlParse("http://apps.saferoutesinfo.org/legislation_funding/state_apportionment.cfm")
class(srts)

srts.table<- readHTMLTable(srts,stringsAsFactors = FALSE)

money <- sapply(srts.table[[1]][,-1], FUN= function(x) 
  as.character(gsub(",", "", as.character(x), fixed = TRUE) ))
money<-as.data.frame(substring(money,2), stringsAsFactors=FALSE)

names(money)<-c("Actual.05","Actual.06","Actual.07","Actual.08",
                "Actual.09","Actual.10","Actual.11", "Actual.12", "total")
money$state<-srts.table[[1]][,1]
money<-money[,c(10,1:9)]
money

top5<-money[rev(order(as.numeric(money$total))),]
top5[2:6, c(1,10)]

plot(money$total[1:51], type="h")

##R 기본 문법

# 변수 선언
#변수 <- 값  : 권장 문법
#예)
x <- 5  # 숫자변수 선언과 값할당
data <- "aaa" #문자변수 선언과 값할당
# 변수 제거
#문법: remove(변수)  
remove(data)


# 대입 : 변수 <- 값
x <- 5

# 데이터 타입과 형변환

# 벡터 : 같은 타입의 여러개 값을 저장
# 1개 이상의 값을 저장(하는 변수). 같은 타입의 값을 나열

# 벡터를 만드는 방법 - c()함수 사용
# c(인수리스트)함수의 인수는 ,를 사용해서 나영 
# c(값1,값2,...)함수 사용 - 
c(1,2,3,4,5)
# 시작값:끝값 - 
1:5 
# seq(시작값, 끝값)함수 사용 - 
seq(1,5) 
#seq(시작값, 끝값,증분)함수 사용 - 
seq(1,5,2)

#벡터변수 : 벡터 값을 갖는 변수
datas <- c("a","b","c") #문자벡터를 datas변수에저장 
values <- 1:3 #숫자벡터를 values변수에 저장

# 벡터 원소 값 추출 : 벡터명[원소번호]
d <- c("a","b","c","d","e")

#벡터명[시작원소번호:끝원소번호]
d[1:3]

#벡터명[c(원소번호1, 원소번호2, ...)]
d[c(1,3)] 

#데이터프레임 : data.frame()
#여러 타입의 값이 나열된 2차원 데이터

#직접만들기
#문법: 변수명 <- data.frame(변수1=값목록1, 변수2=값목록2, ...)
a <- data.frame(x=c(1,3,5), y=c(2,4,6))

#외부데이터(정형데이터)파일을 읽으면(read) => 데이터프레임이 만들어짐
# 텍스트파일로부터 데이터프레임 작성:read.table()
mydata <-read.table("data/data01.txt",  header=TRUE, sep = "")

# csv파일로부터 데이터프레임 작성: read.csv()
mydata2 <-read.csv("data/data01.csv",head=T)

# 엑셀파일로부터 데이터프레임 작성: read_excel()
#선수: 
install.packages("readxl")
library(readxl)
mydata3 <-read_excel("data/20180218_2016년_범죄분류별건수.xlsx")
mydata3

#데이터 로드 및 저장
#파일 로드: read.xxx()메소드 사용
#txt파일 로드 : 정형데이터 - 데이터프레임 형식으로 읽어옴
mydata2 <-read.table("data/2014구별소계인구수.txt", header=TRUE, sep = "")
mydata2
# txt파일 로드 : 비정형데이터
mydata3 <- readLines("text/news2.txt", encoding = "UTF-8")
mydata3

#csv파일 로드 :정형데이터 - 데이터프레임 형식으로 읽어옴
x2 <- read.csv("data/data01.csv", head = T)
x2

#참고: 용량이 큰 CSV파일 읽기 - fread()함수 사용
library(data.table) #경우에따라 생략가능
DT <- fread("data/20190309_very_big.csv") #읽은 파일을 data.table형식으로 저장
#읽은 파일을 데이터프레임(data.frame)형식으로 저장. data.table=FALSE 옵션사용
DT <- fread("data/20190309_very_big.csv", data.table=FALSE) #데이터프레임
head(DT)

#xls파일 로드 - read.table()로 읽을 수 없음.
#엑셀파일 로드 : xlsx패키지의 read_excel()메소드 사용
mydata4 <-read_excel("data/20180218_2016년_범죄분류별건수.xlsx")
mydata4

#파일 저장 : write.xxx()메소드 사용
oildata <- read.table("http://people.stat.sc.edu/habing/courses/data/oildata.txt", header = TRUE)
oildata

# txt파일로 저장 : 정형데이터
#정형데이터일때는 데이터프레임형식을 파일로 저장
write.table(oildata,"data/oildata.txt", quote = FALSE, append = FALSE)

#txt파일로 저장 : 비정형데이터
write(mydata3,"text/datas.txt")

# csv파일로 저장
#oildata변수의 내용을 data폴더안에 data.csv파일로 저장
write.csv(oildata,"data/data.csv", row.names = TRUE)

#xls파일로 저장 : 엑셀파일로 저장 - 단, oildata2.xlsx는 안 됨.
#sep="\t"이 옵션을 사용해야만 각 셀에 값이 들어감
write.table(oildata,"data/oildata2.xls", sep="\t")

#그래픽스 - 플롯(plot, 작도)
x <- 1:10 
y <- 1:10
plot(x,y)

# 전처리, 시각화 
install.packages("dplyr")
install.packages("ggplot2")

library(dplyr) 
library(ggplot2)

head(mpg)     # Raw 데이터 앞부분
tail(mpg)     # Raw 데이터 뒷부분
View(mpg)     # Raw 데이터 뷰어창에서 확인
dim(mpg)      # 차원
str(mpg)      # 속성
summary(mpg)  # 요약 통계량

glimpse(mpg)
tbl_df(mpg)

mpg %>% head

set.seed(1903)
mpg %>% ggplot(aes(drv, hwy)) + geom_jitter(col='gray') +geom_boxplot(alpha=.5)

#차종이 "compact" 이거나 class == "suv"
mpg %>% 
  filter(class == "compact" | class == "suv")

mpg %>% 
  filter(class == "compact" | class == "suv") %>%
  head

# drv, cty, hwy변수 추출
mpg %>% 
  select(drv, cty, hwy) 

# cty 오름차순 정렬
mpg %>% arrange(cty)  #cty 오름차순 정렬 
mpg %>% arrange(desc(cty)) # cty 내림차순 정렬
mpg %>% arrange(-cty) # cty 내림차순 정렬
mpg %>% arrange(drv, cty) #drv별 cty 오름차순 정렬

#
install.packages("gapminder")
library(gapminder)
gapminder %>%
  mutate(total_gdp = pop * gdpPercap,
         le_gdp_ratio = lifeExp / gdpPercap,
         lgrk = le_gdp_ratio * 100) %>%
  head

gapminder %>%
  summarize(n_obs = n(),
            n_countries = n_distinct(country),
            n_years = n_distinct(year),
            med_gdpc = median(gdpPercap),
            mean_gdpc = mean(gdpPercap),
            max_gdppc = max(gdpPercap))

gapminder %>%
  summarize(n_obs = n(),
            n_countries = n_distinct(country),
            n_years = n_distinct(year),
            med_gdpc = median(gdpPercap),
            max_gdppc = max(gdpPercap))

mpg %>%
  group_by(manufacturer, drv) %>%       # 회사별, 구동방식별 분리
  summarise(mean_cty = mean(cty)) %>%   # cty 평균 산출
  head(10)                              # 일부 출력


test1 <- data.frame(id = c(1, 2, 3, 4, 5),           
                    midterm = c(60, 80, 70, 90, 85))

# 기말고사 데이터 생성
test2 <- data.frame(id = c(1, 2, 3, 4, 5),           
                    final = c(70, 83, 65, 95, 80))

test1  # test1 출력
test2  # test2 출력

total <- left_join(test1, test2, by = "id")  # id 기준으로 합쳐서 total에 할당
total

group_a <- data.frame(id = c(1, 2, 3, 4, 5),
                      test = c(60, 80, 70, 90, 85))

# 학생 6~10번 시험 데이터 생성
group_b <- data.frame(id = c(6, 7, 8, 9, 10),
                      test = c(70, 83, 65, 95, 80))

group_a  # group_a 출력
group_b  # group_b 출력

group_all <- bind_rows(group_a, group_b)  # 데이터 합쳐서 group_all에 할당
group_all

#II. 1

#II. 2
install.packages("tidyverse")
library(tidyverse)
install.packages("gridExtra")
library(gridExtra)
install.packages("gapminder")
library(gapminder)

#install.packages("gapminder")
help(package = "gapminder")
library(gapminder)
?gapminder
gapminder

head(gapminder)

tail(gapminder)

library(dplyr)
glimpse(gapminder)


gapminder$lifeExp
gapminder$gdpPercap
gapminder[, c('lifeExp', 'gdpPercap')]
gapminder %>% select(gdpPercap, lifeExp)

# 요약통계량과 상관관계
summary(gapminder$lifeExp)
summary(gapminder$gdpPercap)
cor(gapminder$lifeExp, gapminder$gdpPercap)


# 베이스 패키지 시각화
#@ 4.1
png("plots/4-1.png", 5.5, 4, units='in', pointsize=9, res=600)
opar = par(mfrow=c(2,2))
hist(gapminder$lifeExp)
hist(gapminder$gdpPercap, nclass=50)
# hist(sqrt(gapminder$gdpPercap), nclass=50)
hist(log10(gapminder$gdpPercap), nclass=50)
plot(log10(gapminder$gdpPercap), gapminder$lifeExp, cex=.5)
par(opar)
dev.off()


cor(gapminder$lifeExp, log10(gapminder$gdpPercap))

# 앤스콤의 사인방(Anscombe's quartet)
# https://en.wikipedia.org/wiki/Anscombe%27s_quartet
# https://commons.wikimedia.org/wiki/File:Anscombe%27s_quartet_3.svg
svg("plots/Anscombe's quartet 3.svg", width=11, height=8)
op <- par(las=1, mfrow=c(2,2), mar=1.5+c(4,4,1,1), oma=c(0,0,0,0),
          lab=c(6,6,7), cex.lab=2.0, cex.axis=1.3, mgp=c(3,1,0))
ff <- y ~ x
for(i in 1:4) {
  ff[[2]] <- as.name(paste("y", i, sep=""))
  ff[[3]] <- as.name(paste("x", i, sep=""))
  lmi <- lm(ff, data= anscombe)
  xl <- substitute(expression(x[i]), list(i=i))
  yl <- substitute(expression(y[i]), list(i=i))
  plot(ff, data=anscombe, col="red", pch=21, cex=2.4, bg = "orange",
       xlim=c(3,19), ylim=c(3,13)
       , xlab=eval(xl), ylab=yl  # for version 3
  )
  abline(lmi, col="blue")
}
par(op)
dev.off()

# gapminder 예제의 시각화를 ggplot2로 해보자
library(ggplot2)
library(dplyr)
gapminder %>% ggplot(aes(x=lifeExp)) + geom_histogram()
gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram()
gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram() +
  scale_x_log10()
gapminder %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() +
  scale_x_log10() + geom_smooth()

library(gridExtra)
p1 <- gapminder %>% ggplot(aes(x=lifeExp)) + geom_histogram()
p2 <- gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram()
p3 <- gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram() +
  scale_x_log10()
p4 <- gapminder %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() +
  scale_x_log10() + geom_smooth()
g <- arrangeGrob(p1, p2, p3, p4, ncol=2)
ggsave("plots/4-3.png", g, width=5.5, height=4, units='in', dpi=600)



library(ggplot2)
?ggplot
example(ggplot)

df <- data.frame(gp = factor(rep(letters[1:3], each = 10)),
                 y = rnorm(30))
glimpse(df)

ds <- df %>% group_by(gp) %>% summarize(mean = mean(y), sd = sd(y))
ds


ggplot(df, aes(x = gp, y = y)) +
  geom_point() +
  geom_point(data = ds, aes(y = mean),
             colour = 'red', size = 3)


ggplot(df) +
  geom_point(aes(x = gp, y = y)) +
  geom_point(data = ds, aes(x = gp, y = mean),
             colour = 'red', size = 3)


ggplot() +
  geom_point(data = df, aes(x = gp, y = y)) +
  geom_point(data = ds, aes(x = gp, y = mean),
             colour = 'red', size = 3) +
  geom_errorbar(data = ds, aes(x = gp,
                               ymin = mean - sd, ymax = mean + sd),
                colour = 'red', width = 0.4)


ggplot(gapminder, aes(lifeExp)) + geom_histogram()
gapminder %>% ggplot(aes(lifeExp)) + geom_histogram()

#
gdp2007 <- gapminder %>%
  filter(year == 2007) %>%
  select(country,gdpPercap)
gdp2007
sd(gdp2007$gdpPercap)
summary(gdp2007$gdpPercap)

gdp2007 %>%
  arrange(-gdpPercap) %>%
  head(20)

?diamonds
?mpg
glimpse(diamonds)
glimpse(mpg)

# 1. 한 수량형 변수

library(gapminder)
library(ggplot2)
library(dplyr)
gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram()
gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram() +
  scale_x_log10()
gapminder %>% ggplot(aes(x=gdpPercap)) + geom_freqpoly() +
  scale_x_log10()
gapminder %>% ggplot(aes(x=gdpPercap)) + geom_density() +
  scale_x_log10()


#@ 4.4
p1 <- gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram()
p2 <- gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram() +
  scale_x_log10()
p3 <- gapminder %>% ggplot(aes(x=gdpPercap)) + geom_freqpoly() +
  scale_x_log10()
p4 <- gapminder %>% ggplot(aes(x=gdpPercap)) + geom_density() +
  scale_x_log10()
g <- arrangeGrob(p1, p2, p3, p4, ncol=2)
ggsave("plots/4-4.png", g, width=6, height=4, units='in', dpi=600)

summary(gapminder)


# 2. 한 범주형 변수
ggplot(data = mpg, aes(x = drv)) + geom_bar()
#@ 4.5
diamonds %>% ggplot(aes(cut)) + geom_bar()
ggsave("plots/4-5.png", width=5.5, height=4, units='in', dpi=600)

table(diamonds$cut)

prop.table(table(diamonds$cut))

round(prop.table(table(diamonds$cut))*100, 1)

diamonds %>%
  group_by(cut) %>%
  tally() %>%
  mutate(pct = round(n / sum(n) * 100, 1))


# 3. 두 수량형 변수

diamonds %>% ggplot(aes(carat, price)) + geom_point()
diamonds %>% ggplot(aes(carat, price)) + geom_point(alpha=.01)
mpg %>% ggplot(aes(cyl, hwy)) + geom_point()
mpg %>% ggplot(aes(cyl, hwy)) + geom_jitter()
ggplot(data = mpg, aes(x = displ, y = hwy)) + geom_point()

set.seed(1704)
p1 <- diamonds %>% ggplot(aes(carat, price)) + geom_point()
p2 <- diamonds %>% ggplot(aes(carat, price)) + geom_point(alpha=.01)
p3 <- mpg %>% ggplot(aes(cyl, hwy)) + geom_point()
p4 <- mpg %>% ggplot(aes(cyl, hwy)) + geom_jitter()
ggsave("plots/4-6.png", arrangeGrob(p1, p2, p3, p4, ncol=2),
       width=5.5, height=4, units='in', dpi=600)

#시계열 : geom_line() 
ggplot(data = economics, aes(x = date, y = uempmed)) + geom_line()

pairs(diamonds %>% sample_n(1000))

png("plots/4-7.png", 5.5*1.2, 4*1.2, units='in', pointsize=9, res=400)
set.seed(1704)
pairs(diamonds %>% sample_n(1000))
dev.off()

# 4. 수량형 변수와 범주형 변수
ggplot(data = mpg, aes(x = drv, y = hwy)) + geom_boxplot()

mpg %>% ggplot(aes(class, hwy)) + geom_boxplot()
ggsave("plots/4-8.png", width=5.5, height=4, units='in', dpi=600)


mpg %>% ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5)

mpg %>% mutate(class=reorder(class, hwy, median)) %>%
  ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5)

mpg %>%
  mutate(class=factor(class, levels=
                        c("2seater", "subcompact", "compact", "midsize",
                          "minivan", "suv", "pickup"))) %>%
  ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5)

mpg %>%
  mutate(class=factor(class, levels=
                        c("2seater", "subcompact", "compact", "midsize",
                          "minivan", "suv", "pickup"))) %>%
  ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5) + coord_flip()


set.seed(1704)
p1 <- mpg %>% ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5)
p2 <- mpg %>% mutate(class=reorder(class, hwy, median)) %>%
  ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5)
p3 <- mpg %>%
  mutate(class=factor(class, levels=
                        c("2seater", "subcompact", "compact", "midsize",
                          "minivan", "suv", "pickup"))) %>%
  ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5)
p4 <- mpg %>%
  mutate(class=factor(class, levels=
                        c("2seater", "subcompact", "compact", "midsize",
                          "minivan", "suv", "pickup"))) %>%
  ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5) + coord_flip()
ggsave("plots/4-9.png", arrangeGrob(p1, p2, p3, p4, ncol=2),
       width=5.5*2, height=4*1.5, units='in', dpi=400)



# 5. 두 범주형 변수

glimpse(data.frame(Titanic))

xtabs(Freq ~ Class + Sex + Age + Survived, data.frame(Titanic))


?Titanic
Titanic


mosaicplot(Titanic, main = "Survival on the Titanic")

mosaicplot(Titanic, main = "Survival on the Titanic", color=TRUE)

png("plots/4-10.png", 5.5, 4, units='in', pointsize=9, res=600)
mosaicplot(Titanic, main = "Survival on the Titanic", color=TRUE)
dev.off()
