#"dplyr"과 "hflights" 패키지 설치
install.packages("dplyr")
install.packages("hflights")
library(dplyr) #데이터 마이닝 - 데이터 마트 생성

#미국휴스턴발 비행기의 2011년 이착륙 기록 데이터
#227,496건의 데이터에 대해서 21개항목을 수집한 데이터
library(hflights) 

dim(hflights) #hflights 를 조사

#관측된 데이터가 많은 경우 tbl_df 를 사용해서 함
hflights_df <- tbl_df(hflights)
hflights_df

#1월1일 데이터만 검색
filter(hflights_df, Month == 1, DayofMonth == 1)

#정렬 : 작은 값에서 큰값순
arrange(hflights_df, ArrDelay, Month, Year)

#지정한 컬럼만 추출
select(hflights_df, Year, Month, DayOfWeek)

#평균 출발지연 시간 계산
summarise(hflights_df, delay = mean(DepDelay, na.rm = "TRUE"))

#비행편수20편이상, 평균비행거리 2,000마일 이하인 
#항공사별 평균 연착시간을 계산하여 그림으로 표현
planes <- group_by(hflights_df, TailNum)
delay <- summarise(planes, count = n(), dist = mean(Distance, na.rm = TRUE), delay = mean(ArrDelay, na.rm = TRUE))
delay <- filter(delay,count>=20, dist<=2000)
delay

install.packages("ggplot2")
library(ggplot2)

ggplot(delay, aes(dist,delay)) + geom_point(aes(size=count),alpha=1/2) + geom_smooth() + scale_size_area()
