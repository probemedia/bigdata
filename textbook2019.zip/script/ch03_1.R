#part3 297p~

getwd()

setwd("c:/project/textbook2017/data") #setwd("작업폴더경로")

getwd()

print(1+2)
"a"

class("1")

class(1)

sum(1,2,NA)

sum(1,2,NA, na.rm =T) 

#305p
txt1 <- read.table("data/factor_test.txt", header = T, sep=",")
txt1

factor1 <- factor(txt1$blood)
factor1

#306
Sys.Date()

#vector 312~322
var1 <- "aaa"
var1
var2 <- 111
var2
var3 <- Sys.Date()
var3
var4 <- c("a","b","c")
var4

seq1 <- 1:5
seq1
seq2 <- seq(1,5)
seq2
seq(1,1000,len=62)

vec1 <- c(1,2,3,4,5)
vec1
vec1[3]

var1 <- c(1,2,3)
var2 <- c(3,4,5)
setdiff(var1,var2)
intersect(var1,var2)

length(var1)

var7 <- seq(1,10, by=2)
var7
3 %in% var7
4 %in% var7

#matrix
mat1 <- matrix(c(1,2,3,4))
mat1
mat2 <- matrix(c(1,2,3,4),nrow = 2)
mat2
mat3 <- matrix(c(1,2,3,4),nrow = 2, byrow = T)
mat3

#array
array1 <- array(c(1:12), dim=c(4,3))
array1

array2 <- array(c(1:12), dim=c(2,2,3))
array2

#list
list1 <- list(1, "aaa", 100)
list1
list2  <- list(no=1, name="aaa", score=100)
list2
list2$no
class(list2)

#data.frame
#1.벡터로부터 데이터프레임 생성 
no <- c(1,2,3,4)
name <- c("Apple","Peach","Banana","Grape")
price <- c(500,200,100,50)
qty <- c(5,2,4,7)
sales <- data.frame(NO=no, NAME=name, PRICE=price, QTY=qty)
sales

#2.행렬로부터 데이터프레임 생성 
sales2 <- matrix(c(1,"Apple",500,5,
                   2,"Peach",200,2,
                   3,"Banana",100,4,
                   4,"Grape",50,7),nrow=4, byrow =T) 
sales2

df1 <- data.frame(sales2)
df1
names(df1) <- c("NO","NAME","PRICE", "QTY")
df1
#3.파일로부터 데이터프레임 생성
#3-1.텍스트파일 -> 데이터프레임
fruits = read.table("data/fruits.txt", header = T)
fruits

#3-2.csv파일 -> 데이터프레임
fruits3 = read.csv("data/fruits_3.csv")
fruits3

list.files()

input5 <- readLines("data/scan_4.txt")
input5
