#Part 2 - 예제 5-1 -소스코드

install.packages("googleVis")
library(googleVis)
#demo(WorldBank)

