install.packages("tm") #영문텍스트마이닝, 부정어분석 

library(tm)
library(RColorBrewer) 
library(wordcloud)

data1 <- readLines("text/steve.txt")
data1

corp1 <- Corpus(VectorSource(data1))
corp1

inspect(corp1)

corp2 <- tm_map(corp1, tolower)
inspect(corp2)

corp2 <- tm_map(corp2, removeNumbers)
inspect(corp2)

corp2 <- tm_map(corp2, removePunctuation)
inspect(corp2)

corp2 <- tm_map(corp2, removeWords,stopwords("english"))
inspect(corp2)

install.packages("SnowballC") #동적어근 추출
library(SnowballC)

#corp2 <- tm_map(corp2, stemDocument) #어근만 추출 : apple ---> appl
inspect(corp2)
corp2 <- tm_map(corp2, stripWhitespace)
inspect(corp2)
corp2 <- tm_map(corp2, PlainTextDocument) 


corp2 <- Corpus(VectorSource(corp2)) #require
corp2
corp3 <- TermDocumentMatrix(corp2, control = list(wordLengths=c(2,Inf)))   
corp3

findFreqTerms(corp3, 10)

findAssocs(corp3, "apple", 0.5)

corp4 <- as.matrix(corp3)
corp4

freq1 <- sort(rowSums(corp4), decreasing = T)
freq1

freq2 <- sort(colSums(corp4), decreasing = T)
head(freq2,20)

dim(corp4)

palete <- brewer.pal(7,"Set3") 
wordcloud(names(freq1),freq=freq1,scale=c(5,1),min.freq=5, 
          random.order=F,random.color=T,colors=palete)
legend(0.3,1 ,"스티브 잡스 연설문 분석",cex=1,fill=NA,border=NA,bg="white" ,
       text.col="red",text.font=2,box.col="red")