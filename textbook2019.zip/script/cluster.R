install.packages("cluster")

library(cluster)

votes.repub # 1856~1976년까지 31개 선거에서 공화당 후보에 대한 각 주별 투표율에 대한 통계

votes.repub[1:10, 1:3]

data(votes.repub)

agnl <- agnes(votes.repub, metric = "manhattan", stand = "TRUE")
agnl

plot(agnl)

data1 <- read.csv("data/2014년_범죄발생지별_범죄현황.csv")
data1
data1[1:3, 1:5]
data(data1)

agnl2 <- agnes(data1, metric = "manhattan", stand = "TRUE")
agnl2

plot(agnl2)

