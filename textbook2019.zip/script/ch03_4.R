#406p dplyr package
install.packages("dplyr")
library(dplyr)

data1 <- read.csv("data/2013년_프로야구선수_성적.csv")
data1

data2 <- filter(data1, 경기>=20)
data2

data3 <- filter(data1, 경기>=20 & 득점>=80)
data3

data4 <- filter(data1, 포지션 %in% c('1루수','3루수'))
data4

select(data1, 선수명, 포지션, 팀)
select(data1, 순위:타수)
select(data1, -홈런,-타점,-도루)

data1 %>%
  select(선수명,팀,경기,타수) %>%
  filter(타수>=400)

data1 %>%
  select(선수명,팀,경기,타수) %>%
  filter(타수>=400) %>%
  arrange(타수)

data1 %>%
  select(선수명,팀,경기,타수) %>%
  mutate(경기X타수=경기*타수) %>%
  arrange(경기X타수)

data1 %>%
  group_by(팀) %>%
  summarise(average = mean(경기,na.rm=T)) 

data1 %>%
  group_by(팀) %>%
  summarise_each(funs(mean),경기,타수) 

data1 %>%
  group_by(팀) %>%
  summarise_each(funs(mean,n()),경기,타수) 