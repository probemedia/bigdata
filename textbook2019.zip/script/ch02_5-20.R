#Part 2 - 예제 5-20 -소스코드

#install.packages("httr")
install.packages("XML")
#install.packages("googleVis")  
library(XML)
#library(googleVis)
#library(httr)

install.packages("RCurl")
library(RCurl)


url<-getURL("https://en.wikipedia.org/wiki/World_population",.opts = list(ssl.verifypeer = FALSE) )
tbls <- readHTMLTable(url)
length(tbls)

#pop <- 'http://en.wikipedia.org/wiki/World_population'
#pop
#pop_table <- readHTMLTable(pop)
#length(pop_table)

pop_table <- readHTMLTable(url,which = 3)  # 3번째 테이블입니다.
pop_table
#pop_table[c(1:28),]
pop2 <- pop_table[c(1:3)]
pop2
write.csv(pop2,'data/pop.csv')

#pop.csv 직접수정 => pop1.csv
pop3 <- read.csv('data/pop1.csv',header=T, sep=',')
pop3
pop4 <- gvisColumnChart(pop3,xvar="Continent",
                        options=list(title="population",
                                     height=400,weight=600))
plot(pop4)

pop5 <- pop3[,c(1,3)]
pop5
pie_1 <- gvisPieChart(pop5,options=list(width=500,height=500))
plot(pie_1)
