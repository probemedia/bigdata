#--선수작업: 설치되지 않은 경우 설치
#install.packages("devtools") 
#windows의 경우 필요시 Rtools34.exe 설치 

#CRAN에 등록되지 않은 패키지 설치
#library(devtools)
#devtools::install_github("Bart6114/simmer") #실행시 Rtools34.exe 미설치시 알아서 설치함 
#devtools::install_github("Enchufa2/simmer")
install.packages("simmer")
library(simmer)

t0 <- trajectory("my trajectory") %>%
  ## add an intake activity 
  seize("nurse", 1) %>%
  timeout(function() rnorm(1, 15)) %>% #간호사:환자 1명당 평균 15분 소요
  release("nurse", 1) %>%
  ## add a consultation activity
  seize("doctor", 1) %>%
  timeout(function() rnorm(1, 20)) %>% #의사:환자 1명당 평균 20분 소요
  release("doctor", 1) %>%
  ## add a planning activity
  seize("administration", 1) %>%
  timeout(function() rnorm(1, 5)) %>% #수납처:환자 1명당 평균 5분 소요
  release("administration", 1)

#1회 실시 : 간호사:1명, 의사:2명,수납처: 1명으로 시뮬레이션 1회실시
env <- simmer("SuperDuperSim") %>%
  add_resource("nurse", 1) %>% 
  add_resource("doctor", 2) %>% 
  add_resource("administration", 1) %>% 
  add_generator("patient", t0, function() rnorm(1, 10, 2))

env %>% run(until=80) #한번에 80분 실행

env %>% now() #지금 시뮬레이션

env %>% peek() # 다음 시뮬레이션

#최대 100회 실시 : 간호사:1명, 의사:2명,수납처: 1명으로 시뮬레이션100회실시
#환자는 평균 10분, 표준편차2로 1명씩 발생
#한번에 80분 실행
envs <- lapply(1:100, function(i) { 
  simmer("SuperDuperSim") %>% 
    add_resource("nurse", 1) %>% 
    add_resource("doctor", 2) %>%  
    add_resource("administration", 1) %>%
    add_generator("patient", t0, function() rnorm(1, 10, 2)) %>%
    run(80)
})

#병렬처리수행 
#install.packages("parallel") 
library(parallel)

#최대 100회 실시 : 간호사:1명, 의사:2명,수납처: 1명으로 시뮬레이션100회실시
#환자는 평균 10분, 표준편차2로 1명씩 발생
#한번에 80분 실행
envs <- mclapply(1:100, function(i) {
  simmer("SuperDuperSim") %>%
    add_resource("nurse", 1) %>%
    add_resource("doctor", 2) %>%
    add_resource("administration", 1) %>%
    add_generator("patient", t0, function() rnorm(1, 10, 2)) %>%
    run(80) %>%
    wrap()
})

envs

envs[[1]] %>% get_n_generated("patient")

envs[[1]] %>% get_capacity("doctor")

envs[[1]] %>% get_queue_size("doctor")

head(
  envs %>% get_mon_resources()
)


#plot
#작도에 "dplyr", "tidyr", "ggplot2", "scales" 패키지가 필요함. 없는 것은 인스톨하고 로드
#install.packages("dplyr")
#library(dplyr)
#install.packages("ggplot2")
#library(ggplot2)
#install.packages("tidyr")
#install.packages("scales") 
#library(tidyr)
#library(scales)

#리소스 가동률 확인(resource utilization)
# nurse는 83%정도로 가동률이 매우 높아서 환자의 수가 많거나 진료시간이 긴환자가 올 경우 노동강도가 높아짐. 
#plot_resource_utilization(envs, c("nurse", "doctor","administration"))

#리소스 사용량(resource usage) : doctor의 server사용률
#plot_resource_usage(envs, "doctor", items="server", steps=T)

#리소스 사용량(resource usage) : 6번째 시뮬레이션에서 doctor의 server사용률
#plot_resource_usage(envs[[6]], "doctor", items="server", steps=T)

#80분 시뮬레이션 시간동안 뒤로 갈수록 flow_time이 길어짐(처음에는 38분정도이나 후반에는 50분정도)을 알 수 있다
#plot_evolution_arrival_times(envs, type = "flow_time") 

#80분 시뮬레이션 시간동안 activity_time(치료시간)은 37~40분 사이
#plot_evolution_arrival_times(envs, type = "activity_time")

#80분 시뮬레이션 시간동안 waiting_time(대기시간)은 52분까지는 거의 대기 시간이 없으나 55분 경과부터는 기하급수적으로 늘어남
#plot_evolution_arrival_times(envs, type = "waiting_time")

#새 문법
install.packages("simmer.plot")
library(simmer.plot)

#리소스 사용량(resource usage) : doctor의 server사용률
plot(envs, what="resources", metric="usage", "doctor", items = "server", steps = TRUE)

# nurse는 83%정도로 가동률이 매우 높아서 환자의 수가 많거나 진료시간이 긴환자가 올 경우 노동강도가 높아짐. 
plot(envs, what="resources", metric="utilization", c("nurse", "doctor", "administration"))

#80분 시뮬레이션 시간동안 activity_time(치료시간)은 37~40분 사이
plot(envs, what="arrivals", metric="flow_time")

#80분 시뮬레이션 시간동안 activity_time(치료시간)은 37~40분 사이
plot(envs, what="arrivals", metric="activity_time")

#80분 시뮬레이션 시간동안 waiting_time(대기시간)은 52분까지는 거의 대기 시간이 없으나 55분 경과부터는 기하급수적으로 늘어남
plot(envs, what="arrivals", metric="waiting_time")