install.packages("KoNLP")
install.packages("RColorBrewer")
install.packages("wordcloud")
install.packages("ps")
install.packages("backports")

library(ps)
library(backports)
library(KoNLP)
library(RColorBrewer)
library(wordcloud)

useSejongDic()
#useNIADic()

#SejongDic에서 제공하지 않는 단어 추가
buildDictionary(ext_dic = c('sejong', 'woorimalsam'),user_dic = data.frame(term="아웃사이더", tag='ncn'), category_dic_nms=c('society'))
buildDictionary(ext_dic = c('sejong', 'woorimalsam'),user_dic = data.frame(term="혼밥", tag='ncn'), category_dic_nms=c('society'))
buildDictionary(ext_dic = c('sejong', 'woorimalsam'),user_dic = data.frame(term="관태기", tag='ncn'), category_dic_nms=c('society'))

out <- file("text/news2.txt", encoding = "UTF-8")
speech <- readLines(out)
close(out)

head(speech,5)
tail(speech,5)

pword <- sapply(speech, extractNoun, USE.NAMES = F)
pword

text <- unlist(pword)
head(text,20)

text2 <- Filter(function(x){nchar(x) >= 2}, text)
text2


#text3 <- Filter(function(x){nchar(x) >=3}, text)
#head(text,20)

text2 <- gsub("도","",text2)
text2 <- gsub("명","",text2)
text2 <- gsub("개","",text2)
text2 <- gsub("정","",text2)
text2 <- gsub("등","",text2)
text2 <- gsub("수","",text2)
#text2 <- gsub("20","20대",text2)


text2 <- gsub("안돼…인맥","인맥",text2)
text2 <- gsub("인맥이","인맥",text2)
text2 <- gsub("힘’이라는","",text2)

text2 <- gsub("\\n","",text2)
text2 <- gsub("\\d+","",text2)
text2 <- gsub("\\.","",text2)
text2 <- gsub("\\‘","",text2)
text2 <- gsub("\\’","",text2)
text2 <- gsub("\\(","",text2)
text2 <- gsub("\\)","",text2)
text2 <- gsub("\\“","",text2)
text2 <- gsub("\\”","",text2)
text2 <- gsub("\\·","",text2)
text2

#text2 <- gsub("20대대","20대",text2)

text2 <- Filter(function(x){nchar(x) >= 2}, text2)
text2

write(unlist(text2),"text/mytext.txt")
myword <- read.table("text/mytext.txt")
nrow(myword)

wordcount <- table(myword)
head(sort(wordcount, decreasing = T), 20)

set.seed(1903)
wordcloud(names(wordcount), wordcount, min.freq=3, scale=c(5, .1), colors=brewer.pal(9, "Set1")) 

set.seed(1903)
wordcloud(names(wordcount), wordcount, min.freq=2, scale = c(4, 0.3), 
          random.order = F, colors=brewer.pal(8, "Dark2")) 
