#해수부 교재
#
install.packages("dplyr")
install.packages("ggplot2")

library(dplyr) 
library(ggplot2)
#I. 1

#I. 2

#I. 3
#가 
#1)txt파일 로드
# 정형데이터
mydata2 <- read.table("data/2017년3분기_서울시구별인구수.txt", header=TRUE, sep = "")
mydata2
# 비정형데이터
mydata3 <- readLines("text/news2.txt", encoding = "UTF-8")
mydata3
#기본적인 csv파일 로드 : read.csv()함수 사용
x2 <-read.csv("data/data01.csv", head = T)
x2
#대용량 CSV파일 읽기 - fread()함수 사용
library(data.table)
DT <- fread("data/data01.csv", data.table=FALSE)
DT
#xls파일 로드
install.packages("readxl")
library(readxl) 
df_data <- read_excel("data/업무.xlsx")
df_data

#저장
oildata = read.table("http://people.stat.sc.edu/habing/courses/data/oildata.txt", header = TRUE)
oildata
#txt파일로 저장 : 정형데이터
write.table(oildata,"data/oildata.txt", quote = FALSE, append = FALSE)

#txt파일로 저장 : 비정형데이터
write(mydata3,"text/datas.txt")

#csv파일로 저장
write.csv(oildata,"data/data.csv", row.names = TRUE)

# xls파일로 저장 : 엑셀파일로 저장 - 단, oildata2.xlsx는 안 됨.
write.table(oildata,"data/oildata2.xls", sep="\t")

#
install.packages("sqldf")
library(sqldf)
sqldf("select * from iris")

#나
head(mpg)     # Raw 데이터 앞부분
tail(mpg)     # Raw 데이터 뒷부분
View(mpg)     # Raw 데이터 뷰어창에서 확인
dim(mpg)      # 차원
str(mpg)      # 속성
summary(mpg)  # 요약 통계량

glimpse(mpg)
tbl_df(mpg)

mpg %>% head

mpg %>% ggplot(aes(drv, hwy)) + geom_jitter(col='gray') +geom_boxplot(alpha=.5)

#차종이 "compact" 이거나 class == "suv"
mpg %>% 
  filter(class == "compact" | class == "suv")

mpg %>% 
  filter(class == "compact" | class == "suv") %>%
  head

# drv, cty, hwy변수 추출
mpg %>% 
  select(drv, cty, hwy) 

# cty 오름차순 정렬
mpg %>% arrange(cty)  #cty 오름차순 정렬 
mpg %>% arrange(desc(cty)) # cty 내림차순 정렬
mpg %>% arrange(-cty) # cty 내림차순 정렬
mpg %>% arrange(drv, cty) #drv별 cty 오름차순 정렬

#
install.packages("gapminder")
library(gapminder)
gapminder %>%
  mutate(total_gdp = pop * gdpPercap,
         le_gdp_ratio = lifeExp / gdpPercap,
         lgrk = le_gdp_ratio * 100) %>%
  head

gapminder %>%
  summarize(n_obs = n(),
            n_countries = n_distinct(country),
            n_years = n_distinct(year),
            med_gdpc = median(gdpPercap),
            max_gdppc = max(gdpPercap))

mpg %>%
  group_by(manufacturer, drv) %>%       # 회사별, 구동방식별 분리
  summarise(mean_cty = mean(cty)) %>%   # cty 평균 산출
  head(10)                              # 일부 출력


test1 <- data.frame(id = c(1, 2, 3, 4, 5),           
                    midterm = c(60, 80, 70, 90, 85))

# 기말고사 데이터 생성
test2 <- data.frame(id = c(1, 2, 3, 4, 5),           
                    final = c(70, 83, 65, 95, 80))

test1  # test1 출력
test2  # test2 출력

total <- left_join(test1, test2, by = "id")  # id 기준으로 합쳐서 total에 할당
total

group_a <- data.frame(id = c(1, 2, 3, 4, 5),
                      test = c(60, 80, 70, 90, 85))

# 학생 6~10번 시험 데이터 생성
group_b <- data.frame(id = c(6, 7, 8, 9, 10),
                      test = c(70, 83, 65, 95, 80))

group_a  # group_a 출력
group_b  # group_b 출력

group_all <- bind_rows(group_a, group_b)  # 데이터 합쳐서 group_all에 할당
group_all

#II. 1

#II. 2
install.packages("tidyverse")
library(tidyverse)
install.packages("gridExtra")
library(gridExtra)
install.packages("gapminder")
library(gapminder)

#install.packages("gapminder")
help(package = "gapminder")
library(gapminder)
?gapminder
gapminder

head(gapminder)

tail(gapminder)

library(dplyr)
glimpse(gapminder)


gapminder$lifeExp
gapminder$gdpPercap
gapminder[, c('lifeExp', 'gdpPercap')]
gapminder %>% select(gdpPercap, lifeExp)

# 요약통계량과 상관관계
summary(gapminder$lifeExp)
summary(gapminder$gdpPercap)
cor(gapminder$lifeExp, gapminder$gdpPercap)


# 베이스 패키지 시각화
#@ 4.1
png("plots/4-1.png", 5.5, 4, units='in', pointsize=9, res=600)
opar = par(mfrow=c(2,2))
hist(gapminder$lifeExp)
hist(gapminder$gdpPercap, nclass=50)
# hist(sqrt(gapminder$gdpPercap), nclass=50)
hist(log10(gapminder$gdpPercap), nclass=50)
plot(log10(gapminder$gdpPercap), gapminder$lifeExp, cex=.5)
par(opar)
dev.off()


cor(gapminder$lifeExp, log10(gapminder$gdpPercap))

# 앤스콤의 사인방(Anscombe's quartet)
# https://en.wikipedia.org/wiki/Anscombe%27s_quartet
# https://commons.wikimedia.org/wiki/File:Anscombe%27s_quartet_3.svg
svg("plots/Anscombe's quartet 3.svg", width=11, height=8)
op <- par(las=1, mfrow=c(2,2), mar=1.5+c(4,4,1,1), oma=c(0,0,0,0),
          lab=c(6,6,7), cex.lab=2.0, cex.axis=1.3, mgp=c(3,1,0))
ff <- y ~ x
for(i in 1:4) {
  ff[[2]] <- as.name(paste("y", i, sep=""))
  ff[[3]] <- as.name(paste("x", i, sep=""))
  lmi <- lm(ff, data= anscombe)
  xl <- substitute(expression(x[i]), list(i=i))
  yl <- substitute(expression(y[i]), list(i=i))
  plot(ff, data=anscombe, col="red", pch=21, cex=2.4, bg = "orange",
       xlim=c(3,19), ylim=c(3,13)
       , xlab=eval(xl), ylab=yl  # for version 3
  )
  abline(lmi, col="blue")
}
par(op)
dev.off()

# gapminder 예제의 시각화를 ggplot2로 해보자
library(ggplot2)
library(dplyr)
gapminder %>% ggplot(aes(x=lifeExp)) + geom_histogram()
gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram()
gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram() +
  scale_x_log10()
gapminder %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() +
  scale_x_log10() + geom_smooth()

library(gridExtra)
p1 <- gapminder %>% ggplot(aes(x=lifeExp)) + geom_histogram()
p2 <- gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram()
p3 <- gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram() +
  scale_x_log10()
p4 <- gapminder %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() +
  scale_x_log10() + geom_smooth()
g <- arrangeGrob(p1, p2, p3, p4, ncol=2)
ggsave("plots/4-3.png", g, width=5.5, height=4, units='in', dpi=600)





library(ggplot2)
?ggplot
example(ggplot)

df <- data.frame(gp = factor(rep(letters[1:3], each = 10)),
                 y = rnorm(30))
glimpse(df)

ds <- df %>% group_by(gp) %>% summarize(mean = mean(y), sd = sd(y))
ds


ggplot(df, aes(x = gp, y = y)) +
  geom_point() +
  geom_point(data = ds, aes(y = mean),
             colour = 'red', size = 3)


ggplot(df) +
  geom_point(aes(x = gp, y = y)) +
  geom_point(data = ds, aes(x = gp, y = mean),
             colour = 'red', size = 3)


ggplot() +
  geom_point(data = df, aes(x = gp, y = y)) +
  geom_point(data = ds, aes(x = gp, y = mean),
             colour = 'red', size = 3) +
  geom_errorbar(data = ds, aes(x = gp,
                               ymin = mean - sd, ymax = mean + sd),
                colour = 'red', width = 0.4)


ggplot(gapminder, aes(lifeExp)) + geom_histogram()
gapminder %>% ggplot(aes(lifeExp)) + geom_histogram()

#
gdp2007 <- gapminder %>%
  filter(year == 2007) %>%
  select(country,gdpPercap)
gdp2007
sd(gdp2007$gdpPercap)
summary(gdp2007$gdpPercap)

gdp2007 %>%
  arrange(-gdpPercap) %>%
  head(20)

?diamonds
?mpg
glimpse(diamonds)
glimpse(mpg)

# 1. 한 수량형 변수

library(gapminder)
library(ggplot2)
library(dplyr)
gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram()
gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram() +
  scale_x_log10()
gapminder %>% ggplot(aes(x=gdpPercap)) + geom_freqpoly() +
  scale_x_log10()
gapminder %>% ggplot(aes(x=gdpPercap)) + geom_density() +
  scale_x_log10()


#@ 4.4
p1 <- gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram()
p2 <- gapminder %>% ggplot(aes(x=gdpPercap)) + geom_histogram() +
  scale_x_log10()
p3 <- gapminder %>% ggplot(aes(x=gdpPercap)) + geom_freqpoly() +
  scale_x_log10()
p4 <- gapminder %>% ggplot(aes(x=gdpPercap)) + geom_density() +
  scale_x_log10()
g <- arrangeGrob(p1, p2, p3, p4, ncol=2)
ggsave("plots/4-4.png", g, width=6, height=4, units='in', dpi=600)

summary(gapminder)


# 2. 한 범주형 변수

#@ 4.5
diamonds %>% ggplot(aes(cut)) + geom_bar()
ggsave("plots/4-5.png", width=5.5, height=4, units='in', dpi=600)

table(diamonds$cut)

prop.table(table(diamonds$cut))

round(prop.table(table(diamonds$cut))*100, 1)

diamonds %>%
  group_by(cut) %>%
  tally() %>%
  mutate(pct = round(n / sum(n) * 100, 1))


# 3. 두 수량형 변수

diamonds %>% ggplot(aes(carat, price)) + geom_point()
diamonds %>% ggplot(aes(carat, price)) + geom_point(alpha=.01)
mpg %>% ggplot(aes(cyl, hwy)) + geom_point()
mpg %>% ggplot(aes(cyl, hwy)) + geom_jitter()


set.seed(1704)
p1 <- diamonds %>% ggplot(aes(carat, price)) + geom_point()
p2 <- diamonds %>% ggplot(aes(carat, price)) + geom_point(alpha=.01)
p3 <- mpg %>% ggplot(aes(cyl, hwy)) + geom_point()
p4 <- mpg %>% ggplot(aes(cyl, hwy)) + geom_jitter()
ggsave("plots/4-6.png", arrangeGrob(p1, p2, p3, p4, ncol=2),
       width=5.5, height=4, units='in', dpi=600)


pairs(diamonds %>% sample_n(1000))

png("plots/4-7.png", 5.5*1.2, 4*1.2, units='in', pointsize=9, res=400)
set.seed(1704)
pairs(diamonds %>% sample_n(1000))
dev.off()

# 4. 수량형 변수와 범주형 변수

mpg %>% ggplot(aes(class, hwy)) + geom_boxplot()
ggsave("plots/4-8.png", width=5.5, height=4, units='in', dpi=600)


mpg %>% ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5)

mpg %>% mutate(class=reorder(class, hwy, median)) %>%
  ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5)

mpg %>%
  mutate(class=factor(class, levels=
                        c("2seater", "subcompact", "compact", "midsize",
                          "minivan", "suv", "pickup"))) %>%
  ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5)

mpg %>%
  mutate(class=factor(class, levels=
                        c("2seater", "subcompact", "compact", "midsize",
                          "minivan", "suv", "pickup"))) %>%
  ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5) + coord_flip()


set.seed(1704)
p1 <- mpg %>% ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5)
p2 <- mpg %>% mutate(class=reorder(class, hwy, median)) %>%
  ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5)
p3 <- mpg %>%
  mutate(class=factor(class, levels=
                        c("2seater", "subcompact", "compact", "midsize",
                          "minivan", "suv", "pickup"))) %>%
  ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5)
p4 <- mpg %>%
  mutate(class=factor(class, levels=
                        c("2seater", "subcompact", "compact", "midsize",
                          "minivan", "suv", "pickup"))) %>%
  ggplot(aes(class, hwy)) + geom_jitter(col='gray') +
  geom_boxplot(alpha=.5) + coord_flip()
ggsave("plots/4-9.png", arrangeGrob(p1, p2, p3, p4, ncol=2),
       width=5.5*2, height=4*1.5, units='in', dpi=400)



# 5. 두 범주형 변수

glimpse(data.frame(Titanic))

xtabs(Freq ~ Class + Sex + Age + Survived, data.frame(Titanic))


?Titanic
Titanic


mosaicplot(Titanic, main = "Survival on the Titanic")

mosaicplot(Titanic, main = "Survival on the Titanic", color=TRUE)

png("plots/4-10.png", 5.5, 4, units='in', pointsize=9, res=600)
mosaicplot(Titanic, main = "Survival on the Titanic", color=TRUE)
dev.off()

# 아이들-성인 생존률의 비교
apply(Titanic, c(3, 4), sum)

round(prop.table(apply(Titanic, c(3, 4), sum), margin = 1),3)

# 남-녀 생존률의 비교
apply(Titanic, c(2, 4), sum)

round(prop.table(apply(Titanic, c(2, 4), sum), margin = 1),3)


t2 = data.frame(Titanic)

t2 %>% group_by(Sex) %>%
  summarize(n = sum(Freq),
            survivors=sum(ifelse(Survived=="Yes", Freq, 0))) %>%
  mutate(rate_survival=survivors/n)


# 6. 더 많은 변수를 보여주는 기술 (1): 각 geom 의 다른 속성들을 사용한다.

gapminder %>% filter(year==2007) %>%
  ggplot(aes(gdpPercap, lifeExp)) +
  geom_point() + scale_x_log10() +
  ggtitle("Gapminder data for 2007")


gapminder %>% filter(year==2002) %>%
  ggplot(aes(gdpPercap, lifeExp)) +
  geom_point(aes(size=pop, col=continent)) + scale_x_log10() +
  ggtitle("Gapminder data for 2007")

p1 <- gapminder %>% filter(year==2007) %>%
  ggplot(aes(gdpPercap, lifeExp)) +
  geom_point() + scale_x_log10() +
  ggtitle("Gapminder data for 2007")
p2 <- gapminder %>% filter(year==2002) %>%
  ggplot(aes(gdpPercap, lifeExp)) +
  geom_point(aes(size=pop, col=continent)) + scale_x_log10() +
  ggtitle("Gapminder data for 2007")
ggsave("plots/4-11.png", arrangeGrob(p1, p2, ncol=2),
       width=5.5*1.7, height=4, units='in', dpi=600)

# 7. 더 많은 변수를 보여주는 기술 (2). facet_* 함수를 사용한다.

gapminder %>%
  ggplot(aes(year, lifeExp, group=country)) +
  geom_line()


gapminder %>%
  ggplot(aes(year, lifeExp, group=country, col=continent)) +
  geom_line()


gapminder %>%
  ggplot(aes(year, lifeExp, group=country)) +
  geom_line() +
  facet_wrap(~ continent)

p1 <- gapminder %>%
  ggplot(aes(year, lifeExp, group=country)) +
  geom_line()
p2 <- gapminder %>%
  ggplot(aes(year, lifeExp, group=country, col=continent)) +
  geom_line()
p3 <- gapminder %>%
  ggplot(aes(year, lifeExp, group=country)) +
  geom_line() +
  facet_wrap(~ continent)
ggsave("plots/4-12.png", arrangeGrob(p1, p2, p3, ncol=2),
       width=5.5*2, height=4*2, units='in', dpi=150)



#III. 1
mpg <- as.data.frame(ggplot2::mpg)

library(dplyr)
mpg_diff <- mpg %>% 
  select(class, cty) %>% 
  filter(class %in% c("compact", "suv"))

head(mpg_diff)
table(mpg_diff$class)

t.test(data = mpg_diff, cty ~ class, var.equal = T)
#III. 2

#III. 3