#352p

install.packages("googleVis")
library(googleVis)

install.packages("sqldf")
library(sqldf)

Fruits

#383~384p
getwd()

fr1 <- Fruits
write.table(fr1, "data/f1.txt")
write.csv(fr1, "data/f1.csv")

#388p
vec1 <- c(1,2,3,3,5,6)
vec2 <- c('a','b','c','d','e')
mean(vec1)
median(vec1)

fr1 
aggregate(Sales~Year, fr1, sum)
aggregate(Sales~Fruit, fr1, sum)
aggregate(Sales~Fruit, fr1, max)

#391
list1 <- list(fr1$Sales)
list1
list2 <- list(fr1$Profit)
list2
lapply(c(list1,list2),max)

sapply(c(list1,list2),max)

attach(Fruits)
tapply(Sales, Fruit, sum)