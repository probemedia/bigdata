# 10. 통계 분석에 필요한 기본개념

#-----
# 10-001. 필요패키지 설치 및 로드

# 주요 패키지 로드
library(readxl)
library(dplyr)
library(ggplot2)
library(tidyverse)
library(gridExtra)


#-----
# 10-002. 코로나19사태 전과 후의 지하철 이용객수 차이 대응표본 t-test
# 데이터 로드
df_users <- read.csv("data/2019-2020_m_subway_diff.csv")
df_users

# diff_2020_2019변수만 벡터로 추출해서 sub_users에 저장
sub_users <- df_users$diff_2020_2019
sub_users

# 수량형데이터 - 통계치 파악
summary(sub_users)

sd(sub_users)  # 표준편차

# 데이터 파악을 위한 시각화
par(mfrow=c(2, 2))  # 4개의 서브플롯
hist(sub_users)  # 히스토그램
boxplot(sub_users)  # 상자그림
qqnorm(sub_users); qqline(sub_users) # 정규분포의 Q-Q plot
hist(sub_users, prob=TRUE)  # 백분율 히스토그램
lines(density(sub_users), lty=3)  # 히스토그램에 추정선 분포 추가
dev.off()  # 그래프제거

# 파일로 저장시 사용
png("plots/c19_ds.png", 5.5, 4, units="in", pointsize=9, res=600)
par(mfrow=c(2, 2))  # 4개의 서브플롯
hist(sub_users)  # 히스토그램
boxplot(sub_users)
qqnorm(sub_users); qqline(sub_users)
hist(sub_users, prob=TRUE)
lines(density(sub_users), lty=3)
dev.off()

# 가설검정 
t.test(sub_users)


#-----
# 10-003. 전륜구동차와 4륜구동차 간의 도시주행 연비차이 비교 독립표본 t-test 
# 데이터 로드
library(ggplot2)
df_mpg <- mpg

# 데이터 탐색
head(df_mpg)
tail(df_mpg)
str(df_mpg)

# 구동방식이 f, 4인 데이터 중 구동방식과 도시주행연비 변수를 가진 df_s_c 생성
df_s_c <- df_mpg %>%
  filter(drv %in% c("f", "4")) %>%
  select(drv, cty)

df_s_c

# 구동방식(drv)이 전륜(f)과 4륜(4)인 데이터수 파악
table(df_s_c$drv)

# 전륜(f)데이터 도시주행연비(cty) 요약통계량
df_s_c %>% filter(drv=='f') %>% select(cty) %>% summary()

# 4륜(4)데이터 도시주행연비(cty) 요약통계량
df_s_c %>% filter(drv=='4') %>% select(cty) %>% summary()

# 구동방식(drv)별 도시주행연비(cty)비교 병렬상자그림
df_s_c %>% ggplot(aes(drv, cty)) + geom_boxplot()

# 파일로 저장시 사용
g <- df_s_c %>% ggplot(aes(drv, cty)) + geom_boxplot()
ggsave("plots/mpg_drv_cty_boxplot.png", g, width=6,
       height=4, units="in", dpi=600)

# 가설검정
t.test(data=df_s_c, cty ~ drv, var.equal=T)


#-----
# 10-004.지하철 2호선역별일별 하차승객수와 지하철 평균역별일별 하차승객수 비교
# 단일 표본 t-test

# 데이터 로드
df_sub <- read.csv("data/202002_seoul_subway.csv")

# 데이터 탐색
head(df_sub)
tail(df_sub)
str(df_sub)

# 지하철 역별 일별 하차승객수 평균
tm_p <- (df_sub %>% summarise(mean_p=mean(하차총승객수)))$mean_p
tm_p

# 지하철 2호선 데이터만 추출후 df_sub_2에 저장
df_sub_2 <- df_sub %>% filter(노선명=="2호선")
df_sub_2

# df_sub_2의 하차총승객수 요약통계량
summary(df_sub_2$하차총승객수)

# 지하철 2호선 하차총승객수 상자그림
df_sub_2 %>% ggplot(aes(노선명, 하차총승객수)) + geom_boxplot()

# 가설검증
t.test(df_sub_2$하차총승객수, mu=tm_p)

# -------------
# 페스티벌 유입인구 가설검정
df_fs <- read_excel("data/fs_data.xlsx")

# 9월평균 토요일 유입인구수와 페스티벌 토요일 유입인구수 비교 가설검정
t.test(df_fs$토_유입인구수, mu=df_fs$토_유입인구수[3])

# 9월평균 일요일 유입인구수와 페스티벌 일요일 유입인구수 비교 가설검정
t.test(df_fs$일_유입인구수, mu=df_fs$일_유입인구수[3])

# -------
# 세출비중과부양인구분석
df_dp = read_excel("data/20240407_2020-2024년_세출비중_부양인구.xlsx")
str(df_dp)

df_dp$년도 = as.Date(df_dp$년도)
str(df_dp)

df_dp_cor = round(cor(df_dp[2:17]), 2)
corrplot(df_dp_cor, method="number")

png("plots/2020-2024년_세출비중_부양인구_corrplot.png", 8, 8, units="in",
    pointsize=9, res=600)
corrplot(df_dp_cor, method="number")
dev.off()

pairs(df_dp[2:17])

pairs(df_dp[c(7, 15, 16, 17)])

png("plots/2020-2024년_세출비중_부양인구_pairs.png", 6, 6, units="in",
    pointsize=9, res=600)
pairs(df_dp[c(7, 15, 16, 17)])
dev.off()

# ---
# 하수처리장 코로나 바이러스 농도
df_stp = read_excel("data/2024년서울시_하수처리장_코로나바이러스농도.xlsx",
                    sheet="2024_하수처리장_코로나바이러스농도_분석2")
str(df_stp)

df_stp$샘플_채취_날짜 = as.Date(df_stp$샘플_채취_날짜)
str(df_stp)
head(df_stp)

df_stp_cor <- round(cor(df_stp[3:7]), 2)
corrplot(df_stp_cor, method="number")

# 각 재생센터에 가장 많은 영향을 미친 재생센터
library(MASS)  # lqs() 제공

# 난수시드 고정
set.seed(2110)

names(df_stp)

# 로버스트 선형회귀분석: 서남_물_재생센터의 코로나 농도에 가장 큰 영향을 미친곳
lqs(서남_물_재생센터_코로나19농도 ~ ., data=df_stp[3:7])

# 로버스트 선형회귀분석: 탄천천_물_재생센터의 코로나 농도에 가장 큰 영향을 미친곳
lqs(탄천_물_재생센터_코로나19_농도 ~ ., data=df_stp[3:7])

# ----
# 부동산 실거래가 분석
df_hu = read_excel("data/20240504일_서초구 부동산 실거래가.xlsx")
names(df_hu)
df_hu2 = df_hu[, c(5, 10, 11, 12, 13, 14, 18, 19, 20)]
names(df_hu2) <- c("법정동명", "건물명", "계약일", "물건금액_만원", "건물면적", 
                   "토지면적", "건축년도", "건물용도", "신고구분")

df_hu3 = df_hu[, c(4, 5, 10, 11, 12, 13, 14, 18, 19, 20)]
names(df_hu3) <- c("법정동코드", "법정동명", "건물명", "계약일", "물건금액_만원", "건물면적", 
                   "토지면적", "건축년도", "건물용도", "신고구분")
names(df_hu3)

df_hu2 %>% ggplot(aes(x=건물용도, y=물건금액_만원)) + geom_boxplot()
df_hu2 %>% 
  filter(건물용도=="아파트") %>%
  ggplot(aes(x=건물용도, y=물건금액_만원)) + geom_boxplot()



df_hu2 %>% 
  filter(계약년도=="2023") %>%
  ggplot(aes(x=건물용도, y=물건금액_만원)) + geom_boxplot()

str(df_hu2)
df_hu2$계약일 <- as.character(df_hu2$계약일)
str(df_hu2)
df_hu2 %>% 
  filter(계약년도=="2023" & 건물용도=="아파트") %>% summary(df_hu2)

df_hu2$계약년도 <- substr(as.character(df_hu2$계약일), 1, 4)
str(df_hu2)

df_hu2 <- df_hu2 %>% arrange(계약일)

df_hu2_sy <- df_hu2 %>%
  group_by(계약년도, 건물용도) %>%
  summarise(sum_물건금액_만원=sum(물건금액_만원),
            mean_물건금액_만원=mean(물건금액_만원),
            median_물건금액_만원=median(물건금액_만원))

df_hu2_sy %>% ggplot(aes(x=건물용도, y=sum_물건금액_만원)) + geom_boxplot()

df_hu2_sy2 <- df_hu2 %>%
  group_by(계약년도) %>%
  summarise(sum_물건금액_만원=sum(물건금액_만원)) 

df_hu2_sy2$계약년도 = as.Date(paste(df_hu2_sy2$계약년도, "-01-01", sep=""))
df_hu2_sy2 %>%
  ggplot(aes(x=계약년도, y=sum_물건금액_만원)) + geom_line() + 
  geom_smooth(method='lm', formula='y ~ x')

df_hu2_apt <- df_hu2 %>%
  filter(건물용도=="아파트") %>%
  group_by(계약년도) %>%
  summarise(sum_물건금액_만원=sum(물건금액_만원),
            mean_물건금액_만원=mean(물건금액_만원),
            median_물건금액_만원=median(물건금액_만원))

df_hu2_apt$계약년도 = as.Date(paste(df_hu2_apt$계약년도, "-01-01", sep=""))
df_hu2_apt %>%
  ggplot(aes(x=계약년도, y=sum_물건금액_만원)) + geom_line() + 
  geom_smooth(method='lm', formula='y ~ x')

names(df_hu2)
str(df_hu2)
df_hu2$계약년도 <- as.integer(df_hu2$계약년도)

# 로버스트 회귀분석 : 부동산 실거래가에 가장큰 영향을 준 변수
lqs(물건금액_만원 ~ ., data=df_hu2[c(4, 5, 6, 7, 10)])

# 동별 아파트 실거래가 비교
df_secho_dong = as.data.frame(table(df_hu2$법정동명))
names(df_secho_dong) = c("동", "거래건수")

df_secho_dong = df_secho_dong %>% filter(동 != "상도동") %>% arrange(거래건수)


df_hu2 %>%
  filter(건물용도=="아파트" & 계약년도=="2023") %>%
  ggplot(aes(x=법정동명, y=물건금액_만원)) + geom_boxplot()

df_hu2 %>%
  filter(계약년도=="2023") %>%
  ggplot(aes(x=법정동명, y=물건금액_만원)) + geom_boxplot()

df_hu2 %>%
  filter(건물용도=="아파트" & 계약년도=="2024") %>%
  ggplot(aes(x=법정동명, y=물건금액_만원)) + geom_boxplot()

df_hu2 %>%
  filter(계약년도=="2024") %>%
  ggplot(aes(x=법정동명, y=물건금액_만원)) + geom_boxplot()


df_hu22 = df_hu2

df_hu22_split = split(df_hu22, df_hu22$법정동명)
df_hu22_split


df_hu3
str(df_hu3)
df_hu3$계약일 <- as.character(df_hu3$계약일)
str(df_hu3)


df_hu3$계약년도 <- substr(as.character(df_hu3$계약일), 1, 4)
str(df_hu3)

df_hu3$계약년도 <- as.integer(df_hu3$계약년도)
str(df_hu3)

df_hu3$동명_숫자 = 0
df_hu3$동명_숫자 = ifelse(df_hu3$법정동명=="원지동", 15, 
                      ifelse(df_hu3$법정동명=="염곡동", 63,
                      ifelse(df_hu3$법정동명=="내곡동", 781,
                      ifelse(df_hu3$법정동명=="신원동", 901,
                      ifelse(df_hu3$법정동명=="우면동", 3572,
                      ifelse(df_hu3$법정동명=="양재동", 10198,
                      ifelse(df_hu3$법정동명=="잠원동", 13480,
                      ifelse(df_hu3$법정동명=="반포동", 16996,
                      ifelse(df_hu3$법정동명=="방배동", 22859,
                      ifelse(df_hu3$법정동명=="서초동", 33292,0))))))))))





# 로버스트 회귀분석 : 부동산 실거래가에 가장큰 영향을 준 변수
lqs(물건금액_만원 ~ ., data=df_hu3[c(5, 6, 7, 8, 11, 12)])


df_hu3_apt = df_hu3 %>% filter(건물용도=="아파트")

# 로버스트 회귀분석 : 부동산 아파트 실거래가에 가장큰 영향을 준 변수
lqs(물건금액_만원 ~ ., data=df_hu3_apt[c(5, 6, 8, 11)])

# ---

df_hu3 %>%
  group_by(신고구분) %>%
  summarise(count_건수=n()) %>%
  ggplot(aes(x=신고구분, y=count_건수)) + geom_col()
  

df_hu3 %>%
  filter(!is.na(신고구분)) %>%
  group_by(신고구분) %>%
  summarise(count_건수=n()) %>%
  ggplot(aes(x=신고구분, y=count_건수)) + geom_col()

df_hu33 = df_hu3 %>%
  filter(!is.na(신고구분)) %>%
  group_by(계약년도, 신고구분) %>%
  summarise(count_건수=n())

write.csv(df_hu33,"data/부동산실거래가_신고구분.csv", row.names=FALSE, fileEncoding="cp949")

df_hu33 %>% filter(신고구분=="직거래") %>%
  ggplot(aes(x=계약년도, y=count_건수)) + geom_col()

df_hu33 %>% filter(신고구분=="중개거래") %>%
  ggplot(aes(x=계약년도, y=count_건수)) + geom_col()